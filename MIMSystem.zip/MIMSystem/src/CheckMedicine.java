﻿import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.ActionEvent;
import javax.swing.JList;
import java.awt.Font;

public class CheckMedicine extends JFrame implements ItemListener{
	//看能不能固定住
	/*private String[] coldata={"全選","成份","規格","規格單位","劑型","健保核價單位","包裝","藥品代碼","商品名","管制藥等級","成癮性麻醉藥品","藥品或藥材","ATCcode","藥理分類",
			"藥品適應症","藥理作用備註","備註","兒科水劑","用藥指導單張編碼","廠牌","藥品許可證字號",//Medicine
			"何時通過新藥","何時刪除及倂項或分項列標",//TypeOfPurchase
			"案號項次","決標分項","決標折讓X%","決標折讓Y%","決標折讓Y%備註","決標淨額",//TenderResult
			"標案狀況","履約起日","履約迄日","歷次廠商投標價","預算單價",//TenderDetail
			"缺停藥類型","替代藥類型","缺停藥狀況說明",//ReLackMedicineRecord
			"健保碼","健保價",//Price
			"廠商名稱","電話","傳真","聯絡人","聯絡人電話","聯絡信箱","廠商備註",//FirmData
			"管證登記證字號","管證登記證生效起始日","管證登記證生效終止日"//Certificate
			//49
			};
			*/
	private String[] coldata= {
			"全選","藥品唯一碼","成份","規格","規格單位","劑型","健保核價單位","包裝","藥品代碼","商品名","管制藥等級","成癮性麻醉藥品","藥品或藥材","ATCcode","藥理分類",
			"藥品適應症","藥理作用備註","備註","兒科水劑","用藥指導單張編碼","廠牌","藥品許可證字號",//Medicine 0_21
			"得知日期","缺停藥類型","訊息來源","回收批號","缺停藥狀況說明","替代藥藥品唯一碼","替代藥類型","備註","恢復供貨日期",//ReLackMedicineRecord 22_30
			"藥品採購類型","藥品採購類型起日","藥品採購類型迄日","何時通過新藥","何時刪除及倂項或分項列標",//TypeOfPurchase 31_35
			"上傳日期","健保碼","健保價","生效起日","生效迄日",//Price 36_40
			"流水號","中文案名","總務室承辦人","案號","管理費模式",//Tender 41_45
			"案號項次","成份規格含量","標註用藥品或藥材","廠牌或同等品","品質需求","招標藥品單位","招標藥品包裝","預算單價","預估用量","預估總價","履約起日","履約迄日","履約期限",
			"標案狀況","後續擴充期限","後續擴充模式","後續擴充金額","後擴契約迄日","後擴契約起日","標購方式","歷次廠商報價","歷次廠商投標價","強制結案",//TenderDetail 46_68
			"決標分項","決標健保碼","決標健保價","決標折讓X%","決標折讓Y%","決標折讓Y%備註","決標淨額","決標日期","健保調價承諾A%","履約起日",//TenderResult 69_78
			"廠商統一編號","廠商名稱","電話","傳真","聯絡人","聯絡人電話","聯絡信箱","廠商備註",//FirmData 79_86
			"管證登記證字號","管證登記證生效起始日","管證登記證生效終止日"//Certificate 87_89
			//98
		};
	static JPanel contentPane;
    static JCheckBox Check[] = new JCheckBox[90];
    static String cAFrom[] = new String[14];
    private String cSelect;
	static String cFrom;
	static String cWhere;
	static String want;
	static String wwant;
//	static String []want=new String[1];
	static int location;
	static int llocation;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CheckMedicine frame = new CheckMedicine(null,"","","");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CheckMedicine(SearchMedicine SM,String cs,String cf,String cw) throws ClassNotFoundException {
		setTitle("查詢藥品品項");
		setResizable(false);
		final CheckMedicine clone = this;
		final SearchMedicine Hidding = SM;
		//cSelect = cs;
		//cFrom = cf;
		//cWhere = cw;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1430, 900);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		System.out.println(cWhere);
		
		JLabel lblNewLabel = new JLabel("");
		java.net.URL imgURL = CheckMedicine.class.getResource("image/MIM.png");
		lblNewLabel.setIcon(new ImageIcon(imgURL));
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		contentPane.add(lblNewLabel, BorderLayout.NORTH);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(0, 0, 1384, 40);
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("-藥品品項-");
		lblNewLabel_1.setFont(new Font("標楷體", Font.BOLD, 15));
		lblNewLabel_1.setBounds(29, 13, 110, 19);
		panel_2.add(lblNewLabel_1);
		
		JLabel label = new JLabel("-缺停藥品項-");
		label.setFont(new Font("標楷體", Font.BOLD, 15));
		label.setBounds(169, 13, 110, 19);
		panel_2.add(label);
		
		JLabel label_1 = new JLabel("-藥品採購類型-");
		label_1.setFont(new Font("標楷體", Font.BOLD, 15));
		label_1.setBounds(340, 13, 144, 19);
		panel_2.add(label_1);
		
		JLabel label_3 = new JLabel("-招標-");
		label_3.setFont(new Font("標楷體", Font.BOLD, 15));
		label_3.setBounds(698, 13, 55, 19);
		panel_2.add(label_3);
		
		JLabel label_4 = new JLabel("-招標明細-");
		label_4.setFont(new Font("標楷體", Font.BOLD, 15));
		label_4.setBounds(814, 13, 144, 19);
		panel_2.add(label_4);
		
		JLabel label_5 = new JLabel("-招標結果-");
		label_5.setFont(new Font("標楷體", Font.BOLD, 15));
		label_5.setBounds(961, 13, 144, 19);
		panel_2.add(label_5);
		
		JLabel label_6 = new JLabel("-廠商資料-");
		label_6.setFont(new Font("標楷體", Font.BOLD, 15));
		label_6.setBounds(1104, 13, 144, 19);
		panel_2.add(label_6);
		
		JLabel label_7 = new JLabel("-廠商管證登記證-");
		label_7.setFont(new Font("標楷體", Font.BOLD, 15));
		label_7.setBounds(1240, 13, 144, 19);
		panel_2.add(label_7);
		
		JLabel label_2 = new JLabel("-健保價-");
		label_2.setBounds(558, 13, 144, 19);
		panel_2.add(label_2);
		label_2.setFont(new Font("標楷體", Font.BOLD, 15));
		
		JPanel panel_1 = new JPanel();
		contentPane.add(panel_1, BorderLayout.SOUTH);
		
		JButton btnNewButton = new JButton("重新輸入查詢條件");
		btnNewButton.setFont(new Font("標楷體", Font.PLAIN, 20));
		panel_1.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Hidding.setVisible(true);
				dispose();
			}
		});
		

		
		int a=0;		
		for(int i = 0;i < 1;i++){			
			for(int j = 0;j< 22;j++){
				if(a==22){
					break;
				}

				Check[a] = new JCheckBox(coldata[a]);
				Check[a].setBounds(15, 38+(25*j), 145, 21);
				Check[a].setFont(new Font("標楷體", Font.PLAIN, 15));
				Check[a].addItemListener(this);
				panel.add(Check[a]);
			
				a++;
			
			}
		}
		int b=22;		
		for(int i = 1;i < 2;i++){			
			for(int j = 0;j< 31;j++){
				if(b==31){
					break;
				}

				Check[b] = new JCheckBox(coldata[b]);
				Check[b].setBounds(165, 38+(25*j), 145, 21);
				Check[b].setFont(new Font("標楷體", Font.PLAIN, 15));
				Check[b].addItemListener(this);
				panel.add(Check[b]);
			
				b++;
			
			}
		}
		int c=31;		
		for(int i = 2;i < 3;i++){			
			for(int j = 0;j< 36;j++){
				if(c==36){
					break;
				}

				Check[c] = new JCheckBox(coldata[c]);
				Check[c].setBounds(330, 38+(25*j), 210, 21);
				Check[c].setFont(new Font("標楷體", Font.PLAIN, 15));
				Check[c].addItemListener(this);
				panel.add(Check[c]);
			
				c++;
			
			}
		}
		int d=36;		
		for(int i = 3;i < 4;i++){			
			for(int j = 0;j< 41;j++){
				if(d==41){
					break;
				}

				Check[d] = new JCheckBox(coldata[d]);
				Check[d].setBounds(550, 38+(25*j), 130, 21);
				Check[d].setFont(new Font("標楷體", Font.PLAIN, 15));
				Check[d].addItemListener(this);
				panel.add(Check[d]);
			
				d++;
			
			}
		}
		int e=41;		
		for(int i = 4;i < 5;i++){			
			for(int j = 0;j< 46;j++){
				if(e==46){
					break;
				}

				Check[e] = new JCheckBox(coldata[e]);
				Check[e].setBounds(685, 38+(25*j), 125, 21);
				Check[e].setFont(new Font("標楷體", Font.PLAIN, 15));
				Check[e].addItemListener(this);
				panel.add(Check[e]);
			
				e++;
			
			}
		}
		int f=46;		
		for(int i = 5;i < 6;i++){			
			for(int j = 0;j< 69;j++){
				if(f==69){
					break;
				}

				Check[f] = new JCheckBox(coldata[f]);
				Check[f].setBounds(810, 38+(25*j), 150, 21);
				Check[f].setFont(new Font("標楷體", Font.PLAIN, 15));
				Check[f].addItemListener(this);
				panel.add(Check[f]);
			
				f++;
			
			}
		}
		int g=69;		
		for(int i = 6;i < 7;i++){			
			for(int j = 0;j< 79;j++){
				if(g==79){
					break;
				}

				Check[g] = new JCheckBox(coldata[g]);
				Check[g].setBounds(960, 38+(25*j), 140, 21);
				Check[g].setFont(new Font("標楷體", Font.PLAIN, 15));
				Check[g].addItemListener(this);
				panel.add(Check[g]);
			
				g++;
			
			}
		}
		int h=79;		
		for(int i = 7;i < 8;i++){			
			for(int j = 0;j< 87;j++){
				if(h==87){
					break;
				}

				Check[h] = new JCheckBox(coldata[h]);
				Check[h].setBounds(1100, 38+(25*j), 120, 21);
				Check[h].setFont(new Font("標楷體", Font.PLAIN, 15));
				Check[h].addItemListener(this);
				panel.add(Check[h]);
			
				h++;
			
			}
		}
		int k=87;		
		for(int i = 8;i < 9;i++){			
			for(int j = 0;j< 89;j++){
				if(k==89){
					break;
				}

				Check[k] = new JCheckBox(coldata[k]);
				Check[k].setBounds(1230, 38+(25*j), 190, 21);
				Check[k].setFont(new Font("標楷體", Font.PLAIN, 15));
				Check[k].addItemListener(this);
				panel.add(Check[k]);
			
				k++;
			
			}
		}

		JButton btnNewButton_1 = new JButton("查詢");
		btnNewButton_1.setFont(new Font("標楷體", Font.PLAIN, 20));
		panel_1.add(btnNewButton_1);
		btnNewButton_1.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				
				
				cSelect = cs;
				for(int a=1;a<89;a++){
					for(int b=1;b<89;b++){
						if(a==89){
							break;
						}
						if(Check[a].isSelected()){
							want = Check[a].getLabel();
							
							if(want.equals(coldata[b])){
								location = b;
								
								if(location>= 1 && location <= 21){
									cSelect = cSelect + (",Medicine.`"+want+"`");
								}else if(location >= 22 && location <= 30){
									cSelect = cSelect + (",ReLackMedicineRecord.`"+want+"`");
								}else if(location >= 31 && location <= 35){
									cSelect = cSelect + (",TypeOfPurchase.`"+want+"`");
								}else if(location >= 36 && location <= 40){
									cSelect = cSelect + (",Price.`"+want+"`");
								}else if(location >= 41 && location <= 45){
									cSelect = cSelect + (",Tender.`"+want+"`");
								}else if(location >= 46 && location <= 68){
									cSelect = cSelect + (",TenderDetail.`"+want+"`");
								}else if(location >= 69 && location <= 78){
									cSelect = cSelect + (",TenderResult.`"+want+"`");
								}else if(location >= 79 && location <= 86){
									cSelect = cSelect + (",FirmData.`"+want+"`");
								}else if(location >= 87 && location <= 89){
									cSelect = cSelect + (",Certificate.`"+want+"`");
								}
							}				
							
						}
					}
				}
				
				
				cWhere = cw;
				cFrom = cf;
				int count1 = 0,count2 = 0,count3 = 0,count4 = 0,count5 = 0,count6 = 0,count7 = 0,count8 = 0,count9 = 0;
				for(int x=1;x<89;x++){
					for(int y=1;y<89;y++){
						if(x==89){
							break;
						}
						if(Check[x].isSelected()){
							wwant = Check[x].getLabel();
							
							if(wwant.equals(coldata[y])){
								llocation = y;
								
								if(llocation>= 1 && llocation <= 21){
									count1++;
								}else if(llocation >= 22 && llocation <= 30){
									count2++;
								}else if(llocation >= 31 && llocation <= 35){
									count3++;
								}else if(llocation >= 36 && llocation <= 40){
									count4++;
								}else if(llocation >= 41 && llocation <= 45){
									count5++;
								}else if(llocation >= 46 && llocation <= 68){
									count6++;
								}else if(llocation >= 69 && llocation <= 78){
									count7++;
								}else if(llocation >= 79 && llocation <= 86){
									count8++;
								}else if(llocation >= 87 && llocation <= 89){
									count9++;
								}
							}				
							
						}
					}
				}
				
				System.out.println(count1);	
				
				
				
					if(count2 > 0){
						cWhere = cWhere + " AND Medicine.`藥品唯一碼` = ReLackMedicineRecord.`藥品唯一碼`";
						cFrom = cFrom + ",`ReLackMedicineRecord`" ;
					}if(count3 > 0){
						cWhere = cWhere + " AND Medicine.`藥品唯一碼` = TypeOfPurchase.`藥品唯一碼`";
						cFrom = cFrom + ",`TypeOfPurchase`" ;
					}if(count4 > 0){
						cWhere = cWhere + " AND Medicine.`藥品唯一碼` = Price.`藥品唯一碼`";
						cFrom = cFrom + ",`Price`" ;
					}
				if(count5 > 0 || count6 > 0){
					cWhere = cWhere + " AND Tender.`流水號` = TenderResult.`流水號`";
					cFrom = cFrom + ",`Tender`" ;
				}if(count6 > 0){
					cWhere = cWhere + " AND Tender.`流水號` = TenderDetail.`流水號`";
					cFrom = cFrom + ",`TenderDetail`" ;
				}
				if(count9 > 0){
						cWhere = cWhere + " AND FirmData.`廠商統一編號` = Certificate.`廠商統一編號`";
						cFrom = cFrom + ",`Certificate`" ;
				}
				

        		try {
        			SearchMResult smr = new SearchMResult(clone,cSelect,cFrom,cWhere);
					smr.setVisible(true);
					dispose();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		/*
		int a=0;		
		for(int i = 0;i < 4;i++){			
			for(int j = 0;j< 13;j++){
				if(a==48){
					break;
				}

				Check[a] = new JCheckBox(coldata[a]);
				Check[a].setBounds(19+(i*222), 12+(25*j), 190, 21);
				Check[a].setFont(new Font("標楷體", Font.PLAIN, 15));
				Check[a].addItemListener(this);
				panel.add(Check[a]);
			
				a++;
			
			}
		}

		JPanel panel_1 = new JPanel();
		contentPane.add(panel_1, BorderLayout.SOUTH);
		panel_1.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JButton btnReCondition = new JButton("重新輸入查詢條件");
		btnReCondition.setFont(new Font("標楷體", Font.PLAIN, 15));
		btnReCondition.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Hidding.setVisible(true);
				dispose();
			}
		});
		
		panel_1.add(btnReCondition);
		
		JButton btnSearch = new JButton("查詢");
		btnSearch.setFont(new Font("標楷體", Font.PLAIN, 15));
		btnSearch.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				
				
				cSelect = cs;
				for(int a=1;a<49;a++){
					for(int b=1;b<49;b++){
						if(a==48){
							break;
						}
						if(Check[a].isSelected()){
							want = Check[a].getLabel();
							
							if(want.equals(coldata[b])){
								location = b;
								
								if(location>= 1 && location <= 20){
									cSelect = cSelect + (",Medicine.`"+want+"`");
								}else if(location == 21 || location == 22){
									cSelect = cSelect + (",TypeOfPurchase.`"+want+"`");
								}else if(location >= 23 && location <= 28){
									cSelect = cSelect + (",TenderResult.`"+want+"`");
								}else if(location >= 29 && location <= 33){
									cSelect = cSelect + (",TenderDetail.`"+want+"`");
								}else if(location >= 34 && location <= 36){
									cSelect = cSelect + (",ReLackMedicineRecord.`"+want+"`");
								}else if(location == 37 || location == 38){
									cSelect = cSelect + (",Price.`"+want+"`");
								}else if(location >= 39 && location <= 45){
									cSelect = cSelect + (",FirmData.`"+want+"`");
								}else if(location >= 46 && location <= 48){
									cSelect = cSelect + (",Certificate.`"+want+"`");
								}
							}				
							
						}
					}
				}

        		try {
        			SearchMResult smr = new SearchMResult(clone,cSelect,cFrom,cWhere);
					smr.setVisible(true);
					dispose();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		panel_1.add(btnSearch);
		*/
	}

	@Override
	public void itemStateChanged(ItemEvent event) {
		// TODO Auto-generated method stub     
			 if(event.getItem()==Check[0])
			 {
				 if(Check[0].isSelected()){
						for(int i=1;i<90;i++){
							Check[i].setSelected(true);
						}					 
				 }else{
						for(int i=1;i<90;i++){
							Check[i].setSelected(false);
						}
				 }
		 }		
	}
}
