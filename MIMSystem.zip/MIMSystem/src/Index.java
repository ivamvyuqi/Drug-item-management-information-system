﻿

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;



import java.awt.Container;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.FlowLayout;
import javax.swing.UIManager;


public class Index extends JFrame {

	private JPanel contentPane;
	
	
	static final String DRIVER_NAME = "org.mariadb.jdbc.Driver";
	static final String DB_URL = "jdbc:odbc:GradesData";
	static final String url = "jdbc:mysql://120.105.161.89/MIMSystem";
	static final String username = "MIMSystem";
	static final String password = "MIMSystem";

	static int numberOfRows = 0;
	static int numberOfColumns = 0;
	static Object[][] data = new Object[1][];
	private JTextField chinNameText;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {

					UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
					Index frame = new Index();
					frame.setVisible(true);
					/*String lookAndFeel = UIManager.getCrossPlatformLookAndFeelClassName();
					UIManager.setLookAndFeel(lookAndFeel);
					*/
					/*UIManager.setLookAndFeel(  
					        "com.sun.java.swing.plaf.windows.WindowsLookAndFeel"); */

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */

	public Index() {
		setResizable(false);
		setTitle("MIMSystem臺北市立聯合醫院藥品品項管理資訊系統");
		final Index clone = this;
		setBak(); //調用背景方法
		Container c = getContentPane(); //獲取JFrame面板
		JPanel jp = new JPanel(); //創建個JPanel
		jp.setOpaque(false); //把JPanel設置為透明 這樣就不會遮住後面的背景 這樣你就能在JPanel隨意加元件了
		c.add(jp);
		setSize(960, 760);
		setVisible(true);		
		java.net.URL imgURL = Index.class.getResource("image/MIM.png");
		GridBagLayout gbl_jp = new GridBagLayout();
		gbl_jp.columnWidths = new int[]{1064, 0};
		gbl_jp.rowHeights = new int[]{125, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_jp.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_jp.rowWeights = new double[]{0.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, Double.MIN_VALUE};
		jp.setLayout(gbl_jp);
		
		/****MIM.png****/
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(imgURL));
		lblNewLabel.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);		
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel.anchor = GridBagConstraints.NORTH;
		gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
		gbc_lblNewLabel.gridx = 0;
		gbc_lblNewLabel.gridy = 0;
		jp.add(lblNewLabel, gbc_lblNewLabel);
		/********/

		/****招標buy.png****/
		JLabel lblNewLabel_1 = new JLabel("招標");
		java.net.URL imgbuy1 = Index.class.getResource("image/buy.png");
		lblNewLabel_1.setIcon(new ImageIcon(imgbuy1));
		lblNewLabel_1.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.TRAILING);
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel_1.gridx = 0;
		gbc_lblNewLabel_1.gridy = 1;
		jp.add(lblNewLabel_1, gbc_lblNewLabel_1);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setLayout(null);
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.insets = new Insets(0, 0, 5, 0);
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 2;
		jp.add(panel, gbc_panel);

		
		JButton btnPrroductTender = new JButton("產生招標品項表");
		btnPrroductTender.setBounds(66, 21, 159, 33);
		btnPrroductTender.setFont(new Font("微軟正黑體", Font.PLAIN, 15));
		panel.add(btnPrroductTender);
		btnPrroductTender.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				final String DRIVER_NAME = "org.mariadb.jdbc.Driver";
				final String DB_URL = "jdbc:odbc:GradesData";
				final String url = "jdbc:mysql://120.105.161.89/MIMSystem";
				final String username = "MIMSystem";
				final String password = "MIMSystem";

				int numberOfRows = 0;
				int numberOfColumns = 0;
			    Object[][] data = new Object[1][];
				JTextField chinNameText;
				
				Calendar calendar = Calendar.getInstance();
				calendar.add(Calendar.MONTH, +3);// 得到前3个月
				Date formNow3Month = calendar.getTime();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				sdf.format(formNow3Month);
				// System.out.println("時間就是金錢"+formNow3Month);
				System.out.println("時間就是金錢" + sdf.format(formNow3Month));

				// int time = Integer.parseInt(sdf.format(formNow3Month));

				//EventQueue.invokeLater(new Runnable() {
					//public void run() {
						// calendar.add(Calendar.MONTH, -3);// 得到前3个月
						Connection con = null;
						Statement statement;
						ResultSet rs;
						ResultSetMetaData rsMetaData;
						String strDate = sdf.format(formNow3Month);
						try {
							con = DriverManager.getConnection(url, username, password); // 呼叫Connection物件，進行資料庫連線
							System.out.println("資料庫連結成功");
							statement = con.createStatement();
							System.out.println("連接成功");

							// DB取欄位名稱
							rs = statement.executeQuery(
									"SELECT `Tender`.`案號`, `TenderDetail`.`案號項次`, `TenderDetail`.`成份規格含量`,`TenderDetail`.`標註用藥品或藥材`, "
											+ "`TenderDetail`.`廠牌或同等品`,`TenderDetail`.`品質需求`,`TenderDetail`.`招標藥品單位`,`TenderDetail`.`招標藥品包裝`,  "
											+ "`TenderDetail`.`預算單價`,`TenderDetail`.`預估用量`, `TenderDetail`.`預估總價`,`TenderDetail`.`履約起日`, `TenderDetail`.`履約迄日`, `TenderDetail`.`履約期限`, "
											+ "`TenderDetail`.`標案狀況`,`TenderDetail`.`後續擴充期限`,`TenderDetail`.`後續擴充模式`,`TenderDetail`.`後續擴充金額`, `TenderDetail`.`後擴契約起日`, "
											+ "`TenderDetail`.`後擴契約迄日`,`TenderDetail`.`標購方式`,`TenderDetail`.`歷次廠商報價`,`TenderDetail`.`歷次廠商投標價`, `TenderDetail`.`強制結案` "
											+ "FROM `Tender`, `TenderDetail` WHERE `TenderDetail`.`履約迄日` < '" + strDate
											+ "' AND `Tender`.`流水號` = `TenderDetail`.`流水號`");// 欄位資料

							rsMetaData = rs.getMetaData();
							numberOfColumns = rsMetaData.getColumnCount();

							boolean nodata = true;
							while (rs.next()) {
								nodata = false;
								for (int i = 1; i <= numberOfColumns; i++) {
									System.out.printf("%s\t", rs.getObject(i));
								}
								numberOfRows++;
							}
							System.out.println("筆數:" + numberOfRows);

							/*
							 * String sql =
							 * "SELECT `Tender`.`案號`, `TenderDetail`.`案號項次`, `TenderDetail`.`成份規格含量`,`TenderDetail`.`標註用藥品或藥材`, "
							 * +
							 * "`TenderDetail`.`廠牌或同等品`,`TenderDetail`.`品質需求`,`TenderDetail`.`招標藥品單位`,`TenderDetail`.`招標藥品包裝`,  "
							 * +
							 * "`TenderDetail`.`預算單價`,`TenderDetail`.`預估用量`, `TenderDetail`.`預估總價`,`TenderDetail`.`履約起日`, `TenderDetail`.`履約迄日`, `TenderDetail`.`履約期限`, "
							 * +
							 * "`TenderDetail`.`標案狀況`,`TenderDetail`.`後續擴充期限`,`TenderDetail`.`後續擴充模式`,`TenderDetail`.`後續擴充金額`, `TenderDetail`.`後擴契約起日`, "
							 * +
							 * "`TenderDetail`.`後擴契約迄日`,`TenderDetail`.`標購方式`,`TenderDetail`.`歷次廠商報價`,`TenderDetail`.`歷次廠商投標價`, `TenderDetail`.`強制結案` "
							 * +
							 * "FROM `Tender`, `TenderDetail` WHERE `TenderDetail`.`履約迄日` < '"
							 * + strDate + "' AND `Tender`.`流水號` = `TenderDetail`.`流水號`"
							 * ; System.out.println(sql);
							 */

							System.out.println("test1");
							rs = statement.executeQuery(
									"SELECT `Tender`.`案號`, `TenderDetail`.`案號項次`, `TenderDetail`.`成份規格含量`,`TenderDetail`.`標註用藥品或藥材`, "
											+ "`TenderDetail`.`廠牌或同等品`,`TenderDetail`.`品質需求`,`TenderDetail`.`招標藥品單位`,`TenderDetail`.`招標藥品包裝`,  "
											+ "`TenderDetail`.`預算單價`,`TenderDetail`.`預估用量`, `TenderDetail`.`預估總價`,`TenderDetail`.`履約起日`, `TenderDetail`.`履約迄日`, `TenderDetail`.`履約期限`, "
											+ "`TenderDetail`.`標案狀況`,`TenderDetail`.`後續擴充期限`,`TenderDetail`.`後續擴充模式`,`TenderDetail`.`後續擴充金額`, `TenderDetail`.`後擴契約起日`, "
											+ "`TenderDetail`.`後擴契約迄日`,`TenderDetail`.`標購方式`,`TenderDetail`.`歷次廠商報價`,`TenderDetail`.`歷次廠商投標價`, `TenderDetail`.`強制結案` "
											+ "FROM `Tender`, `TenderDetail` WHERE `TenderDetail`.`履約迄日` < '" + strDate
											+ "' AND `Tender`.`流水號` = `TenderDetail`.`流水號`");// 欄位資料
							data = new Object[numberOfRows][numberOfColumns + 1];
							System.out.println("ROW:" + numberOfRows + ";cOL:" + numberOfColumns);
							int order = 0;
							while (rs.next()) {

								for (int i = 1; i <= numberOfColumns; i++) {
									if (rs.getObject(i) == null) {
										data[order][i - 1] = "";
									} else {
										data[order][i - 1] = rs.getObject(i);
										System.out.println(rs.getObject(i));
									}
								}
								order++;

							}

							System.out.println("test2");

							if (order == 0) {
								
		    		    	    int result=JOptionPane.showConfirmDialog(null,
		   		    	               "目前沒有欲到期藥品 ",
		   		    	               "失敗",
		   		    	               JOptionPane.DEFAULT_OPTION,
		   		    	               JOptionPane.PLAIN_MESSAGE);
		      		    	    if (result==0) {
						    		Index ID;
									ID = new Index();
									ID.setVisible(true);
									dispose();
		      		    	    }
							}

							/*deadLineItem frame = new deadLineItem(data);
							frame.setVisible(true);*/
							deadLineItem dli = new deadLineItem(data,clone);
        					dli.setVisible(true);
							dispose();

						} catch (SQLException sqlException) {
							sqlException.printStackTrace();
						}

					//}
				//});



			}
		});

		
		JButton btnSearchTender = new JButton("查詢(修改)招標品項表");
		btnSearchTender.setFont(new Font("微軟正黑體", Font.PLAIN, 15));
		btnSearchTender.setBounds(298, 22, 189, 32);
		panel.add(btnSearchTender);
		btnSearchTender.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
        			SearchTender st = new SearchTender(clone);
					st.setVisible(true);
					dispose();
			}
		});

		
		JButton btnNewTenderResult = new JButton("記錄招標結果");
		btnNewTenderResult.setFont(new Font("微軟正黑體", Font.PLAIN, 15));
		btnNewTenderResult.setBounds(796, 22, 131, 32);
		panel.add(btnNewTenderResult);
		btnNewTenderResult.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

					
	        		try {
	        			searchTenderR str = new searchTenderR(clone);
						str.setVisible(true);
						dispose();
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
			}
		});

		JButton btnSearchTenderResult = new JButton("查詢(修改)招標結果");
		btnSearchTenderResult.setFont(new Font("微軟正黑體", Font.PLAIN, 15));
		btnSearchTenderResult.setBounds(553, 22, 177, 32);
		panel.add(btnSearchTenderResult);
		btnSearchTenderResult.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
        		try {
        			searchItem si = new searchItem(clone);
					si.setVisible(true);
					dispose();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		/********/
		
		/****藥品品項drugs.png****/
		JLabel lblNewLabel_2 = new JLabel("藥品品項");
		java.net.URL imgdrugs1 = Index.class.getResource("image/drugs.png");
		lblNewLabel_2.setIcon(new ImageIcon(imgdrugs1));
		lblNewLabel_2.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.TRAILING);
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel_2.gridx = 0;
		gbc_lblNewLabel_2.gridy = 3;
		jp.add(lblNewLabel_2, gbc_lblNewLabel_2);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setLayout(null);
		GridBagConstraints gbc_panel_1 = new GridBagConstraints();
		gbc_panel_1.insets = new Insets(0, 0, 5, 0);
		gbc_panel_1.fill = GridBagConstraints.BOTH;
		gbc_panel_1.gridx = 0;
		gbc_panel_1.gridy = 4;
		jp.add(panel_1, gbc_panel_1);

		
		JButton btnNewmed = new JButton("新增藥品品項");
		btnNewmed.setBounds(122, 23, 144, 33);
		panel_1.add(btnNewmed);
		btnNewmed.setFont(new Font("微軟正黑體", Font.PLAIN, 15));
		btnNewmed.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {	
        		try {
        			NewMedicine nm = new NewMedicine(clone);
					nm.setVisible(true);
					dispose();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	    	}
	   });

		
		JButton btnSearchmed = new JButton("查詢(修改)藥品品項");
		btnSearchmed.setBounds(397, 23, 201, 32);
		panel_1.add(btnSearchmed);
		btnSearchmed.setFont(new Font("微軟正黑體", Font.PLAIN, 15));
		btnSearchmed.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {	
        		try {
        			SearchMedicine sm = new SearchMedicine(clone);
					sm.setVisible(true);
					dispose();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	    	}
	   });

		
		JButton btnNewButton_6 = new JButton("產生西藥品項表");
		btnNewButton_6.setBounds(742, 23, 151, 32);
		panel_1.add(btnNewButton_6);
		btnNewButton_6.setFont(new Font("微軟正黑體", Font.PLAIN, 15));	
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

        			chooseOutPMD copmd = new chooseOutPMD(clone);
        			copmd.setVisible(true);
					dispose();

			}
		});	
		/********/

		/****廠商factories.png****/
		JLabel lblNewLabel_3 = new JLabel("廠商");
		java.net.URL imgfactories1 = Index.class.getResource("image/factories.png");
		lblNewLabel_3.setIcon(new ImageIcon(imgfactories1));
		lblNewLabel_3.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_3 = new GridBagConstraints();
		gbc_lblNewLabel_3.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel_3.gridx = 0;
		gbc_lblNewLabel_3.gridy = 5;
		jp.add(lblNewLabel_3, gbc_lblNewLabel_3);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.WHITE);
		panel_2.setLayout(null);
		GridBagConstraints gbc_panel_2 = new GridBagConstraints();
		gbc_panel_2.insets = new Insets(0, 0, 5, 0);
		gbc_panel_2.fill = GridBagConstraints.BOTH;
		gbc_panel_2.gridx = 0;
		gbc_panel_2.gridy = 6;
		jp.add(panel_2, gbc_panel_2);

		
		JButton btnNewFirm = new JButton("新增廠商資料");
		btnNewFirm.setBounds(412, 27, 157, 33);
		panel_2.add(btnNewFirm);
		btnNewFirm.setFont(new Font("微軟正黑體", Font.PLAIN, 15));	
		btnNewFirm.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {	
        			NewFirm nf = new NewFirm(clone);
					nf.setVisible(true);
					dispose();
	    	}
	   });		
		/********/

		/****健保價budget.png****/
		JLabel lblNewLabel_4 = new JLabel("健保價");
		java.net.URL imgbudget1 = Index.class.getResource("image/budget.png");
		lblNewLabel_4.setIcon(new ImageIcon(imgbudget1));
		lblNewLabel_4.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_4 = new GridBagConstraints();
		gbc_lblNewLabel_4.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel_4.gridx = 0;
		gbc_lblNewLabel_4.gridy = 7;
		jp.add(lblNewLabel_4, gbc_lblNewLabel_4);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(Color.WHITE);
		panel_3.setLayout(null);
		GridBagConstraints gbc_panel_3 = new GridBagConstraints();
		gbc_panel_3.insets = new Insets(0, 0, 5, 0);
		gbc_panel_3.fill = GridBagConstraints.BOTH;
		gbc_panel_3.gridx = 0;
		gbc_panel_3.gridy = 8;
		jp.add(panel_3, gbc_panel_3);

				
		JButton btnSearchPrice = new JButton("查詢健保價");
		btnSearchPrice.setBounds(601, 25, 234, 32);
		panel_3.add(btnSearchPrice);
		btnSearchPrice.setFont(new Font("微軟正黑體", Font.PLAIN, 15));		
		btnSearchPrice.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {

    			SearchPrice sp = new SearchPrice(clone);
				sp.setVisible(true);
				dispose();

		}
		});

		JButton btnNewPrice = new JButton("上傳健保價");
		btnNewPrice.setBounds(205, 24, 174, 33);
		panel_3.add(btnNewPrice);
		btnNewPrice.setFont(new Font("微軟正黑體", Font.PLAIN, 15));
		btnNewPrice.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
        		try {
        			UpdatePrice2 up2 = new UpdatePrice2(clone);
					up2.setVisible(true);
					dispose();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		/********/

		/****缺藥pills.png****/
		JLabel lblNewLabel_5 = new JLabel("缺藥");
		java.net.URL imgpills1 = Index.class.getResource("image/pills.png");
		lblNewLabel_5.setIcon(new ImageIcon(imgpills1));
		lblNewLabel_5.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel_5 = new GridBagConstraints();
		gbc_lblNewLabel_5.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel_5.gridx = 0;
		gbc_lblNewLabel_5.gridy = 9;
		jp.add(lblNewLabel_5, gbc_lblNewLabel_5);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(Color.WHITE);
		panel_4.setLayout(null);
		GridBagConstraints gbc_panel_4 = new GridBagConstraints();
		gbc_panel_4.fill = GridBagConstraints.BOTH;
		gbc_panel_4.gridx = 0;
		gbc_panel_4.gridy = 10;
		jp.add(panel_4, gbc_panel_4);

		
		JButton btnNewButton_10 = new JButton("新增缺藥紀錄");
		btnNewButton_10.setBounds(110, 25, 174, 33);
		panel_4.add(btnNewButton_10);
		btnNewButton_10.setFont(new Font("微軟正黑體", Font.PLAIN, 15));
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

        		try {
        			NewLackOfMedicineRecord nlomr = new NewLackOfMedicineRecord(clone);
        			nlomr.setVisible(true);
					dispose();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			
			}
		});
		
		JButton btnNewButton_11 = new JButton("新增恢復供藥紀錄");
		btnNewButton_11.setBounds(387, 25, 198, 32);
		panel_4.add(btnNewButton_11);
		btnNewButton_11.setFont(new Font("微軟正黑體", Font.PLAIN, 15));
		btnNewButton_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

        			SearchRestoreMedicine srm = new SearchRestoreMedicine(clone);
        			srm.setVisible(true);
					dispose();
				
			}
		});

				
		JButton btnNewButton_12 = new JButton("查詢(修改)缺藥歷程");
		btnNewButton_12.setBounds(695, 25, 183, 32);
		panel_4.add(btnNewButton_12);
		btnNewButton_12.setFont(new Font("微軟正黑體", Font.PLAIN, 15));
		btnNewButton_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
        		try {
        			SearchLackMedicine slm = new SearchLackMedicine(clone);
					slm.setVisible(true);
					dispose();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});		
		/********/
		
	
	}
	public void setBak(){
		((JPanel)this.getContentPane()).setOpaque(false);
		java.net.URL imgURL = Index.class.getResource("image/057 Dirty Beauty.png");
		ImageIcon img = new ImageIcon(imgURL);
		JLabel background = new JLabel(img);this.getLayeredPane().add(background, new Integer(Integer.MIN_VALUE));
		background.setBounds(0, 0, img.getIconWidth(), img.getIconHeight());
	}
}
