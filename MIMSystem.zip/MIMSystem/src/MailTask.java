﻿import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimerTask;

import javax.mail.Message;
import javax.mail.internet.MimeMessage;

public class MailTask extends TimerTask{
	
	Calendar now = Calendar.getInstance();
	int maturity=0;
	
	@ Override
	public void run() {
	  //System.out.println("Task 執行時間：" + new Date());
        Connection conn = null;  
    	Statement statement;
    	ResultSet rs;
    	ResultSetMetaData rsMetaData;
    	

  		try{
  			 now.add(Calendar.MONTH, 3); //現在時間的三個月後
			 Date formNow3Month = now.getTime();
			 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			 sdf.format(formNow3Month);
			 String strNow = sdf.format(formNow3Month);
  	         Class.forName("org.mariadb.jdbc.Driver");
  	         System.out.println("資料庫連結成功");
             conn = DriverManager.getConnection("jdbc:mariadb://lots.im.nuu.edu.tw/MIMSystem", "MIMSystem", "MIMSystem");
             System.out.println("連接成功MySQL");
             statement = conn.createStatement();
	           rs = statement.executeQuery("SELECT * FROM `TenderDetail` WHERE `履約迄日` < '"+strNow+"'");				
  			    while (rs.next()){
  			    	maturity++;
  				 }
  		  	  statement.close();
  		      conn.close();
		}catch(ClassNotFoundException classNotFound){//找不到JDBC Driver
  	        classNotFound.printStackTrace();	
  		}catch(SQLException sqlException){//資料庫操作發生錯誤
  	        sqlException.printStackTrace();
  		}
  		
  		if(maturity>0){
  			SendMail sendmail = new SendMail();
  		}else{
  			System.out.println("無低於三個月之需招標作業！");
  		}
  		

	}
	
}
