﻿import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class ModifyMedicine extends JFrame {
	private String[] str =  {"藥品唯一碼","成份","規格","規格單位","劑型","健保核價單位","包裝","藥品代碼","商品名","管制藥等級","成癮性麻醉藥品","藥品或藥材","ATCcode","藥理分類",
			"藥品適應症","藥理作用備註","備註","兒科水劑","用藥指導單張編碼","廠牌","藥品許可證字號",//Medicine
			"何時通過新藥","何時刪除及倂項或分項列標",//TypeOfPurchase
			"廠商統一編號","廠商名稱","電話","傳真","聯絡人","聯絡人電話","聯絡信箱","廠商備註",//FirmData
			"管證登記證字號","管證登記證生效起始日","管證登記證生效終止日"//Certificate 34
	};
	private JPanel contentPane;
	private JTable aTableMedicine;
	private JTable mTableMedicine;
	private DefaultTableModel model;
	private String[] alldata = new String[34];
	private JTextField field[] = new JTextField[34];
	private String getmodify;
	private String [] getModify = new String[40];
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ModifyMedicine frame = new ModifyMedicine(null,0,null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ModifyMedicine(final String[] data,final int EST,SearchMResult SMR){//throws ClassNotFoundException {
		
		
		setTitle("修改藥品品項");
		final ModifyMedicine clone = this;
		final SearchMResult Hidding = SMR;
		String [] mdfmdonly = data;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JLabel pic1 = new JLabel("");
		java.net.URL imgURL = ModifyMedicine.class.getResource("image/MIM.png");
		pic1.setIcon(new ImageIcon(imgURL));
		pic1.setHorizontalAlignment(SwingConstants.RIGHT);
		contentPane.add(pic1, BorderLayout.NORTH);
		
		JPanel panel_1 = new JPanel();
		panel_1.setPreferredSize(new Dimension(1200,700));
		JScrollPane scrollPane = new JScrollPane(panel_1);
		contentPane.add(scrollPane, BorderLayout.CENTER);
        panel_1.setAutoscrolls(true);
        GridBagLayout gbl_panel_1 = new GridBagLayout();
        gbl_panel_1.columnWidths = new int[]{0, 0};
        gbl_panel_1.rowHeights = new int[]{0, 0, 0};
        gbl_panel_1.columnWeights = new double[]{0.0, Double.MIN_VALUE};
        gbl_panel_1.rowWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
        panel_1.setLayout(gbl_panel_1);
        
        scrollPane.setPreferredSize(new Dimension(900,600));
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        contentPane.add(scrollPane,BorderLayout.CENTER);

        Connection conn = null;  
    	Statement statement;
    	ResultSet rs;
    	PreparedStatement ps = null; 
    	ResultSetMetaData rsMetaData;
    	String k="";
  		//String columnNames[] = {sMedicine,"新增"};
  		try{
  	         Class.forName("org.mariadb.jdbc.Driver");
  	         System.out.println("資料庫連結成功");
             conn = DriverManager.getConnection("jdbc:mariadb://lots.im.nuu.edu.tw/MIMSystem", "MIMSystem", "MIMSystem");
             System.out.println("連接成功MySQL");
             statement = conn.createStatement();
             
             String sql = "SELECT Medicine.`藥品唯一碼`,Medicine.`成份`,Medicine.`規格`,Medicine.`規格單位`,Medicine.`劑型`,Medicine.`健保核價單位`,"
 	           		+"Medicine.`包裝`,Medicine.`藥品代碼`,Medicine.`商品名`,Medicine.`管制藥等級`,Medicine.`成癮性麻醉藥品`,Medicine.`藥品或藥材`,Medicine.`ATCcode`,Medicine.`藥理分類`,"
 	    			+"Medicine.`藥品適應症`,Medicine.`藥理作用備註`,Medicine.`備註`,Medicine.`兒科水劑`,Medicine.`用藥指導單張編碼`,Medicine.`廠牌`,Medicine.`藥品許可證字號`,"
 	    			+"TypeOfPurchase.`何時通過新藥`,TypeOfPurchase.`何時刪除及倂項或分項列標`,"
 	    			+"FirmData.`廠商統一編號`,FirmData.`廠商名稱`,FirmData.`電話`,FirmData.`傳真`,FirmData.`聯絡人`,FirmData.`聯絡人電話`,FirmData.`聯絡信箱`,FirmData.`廠商備註`,"
 	    			+"Certificate.`管證登記證字號`,Certificate.`管證登記證生效起始日`,Certificate.`管證登記證生效終止日` FROM `Medicine`,`Certificate`,`FirmData`,`TypeOfPurchase`,`TenderResult`"
 	    			+" WHERE Medicine.`藥品唯一碼` = '"+mdfmdonly[0]+"' AND FirmData.`廠商統一編號` = '"+mdfmdonly[1]+"' AND Medicine.`藥品唯一碼` = TenderResult.`藥品唯一碼` AND FirmData.`廠商統一編號` = TenderResult.`廠商統一編號` AND "
 	    			+"Medicine.`藥品唯一碼` = TypeOfPurchase.`藥品唯一碼` AND FirmData.`廠商統一編號` = Certificate.`廠商統一編號` AND Certificate.`管證登記證生效終止日` = (SELECT max(管證登記證生效終止日) FROM `Certificate` WHERE Certificate.`廠商統一編號` = '"+mdfmdonly[1]+"')";
             
             System.out.println(sql);
             
             ps = (PreparedStatement) conn.prepareStatement(sql,ResultSet.TYPE_FORWARD_ONLY,  
             ResultSet.CONCUR_READ_ONLY);  
                        
             ps.setFetchSize(Integer.MIN_VALUE);  
              
             ps.setFetchDirection(ResultSet.FETCH_REVERSE);  
  
             rs = ps.executeQuery();  
             
	           /*rs = statement.executeQuery("SELECT Medicine.`藥品唯一碼`,Medicine.`成份`,Medicine.`規格`,Medicine.`規格單位`,Medicine.`劑型`,Medicine.`健保核價單位`,"
	           		+"Medicine.`包裝`,Medicine.`藥品代碼`,Medicine.`商品名`,Medicine.`管制藥等級`,Medicine.`成癮性麻醉藥品`,Medicine.`藥品或藥材`,Medicine.`ATCcode`,Medicine.`藥理分類`,"
	    			+"Medicine.`藥品適應症`,Medicine.`藥理作用備註`,Medicine.`備註`,Medicine.`兒科水劑`,Medicine.`用藥指導單張編碼`,Medicine.`廠牌`,Medicine.`藥品許可證字號`,"
	    			+"TypeOfPurchase.`何時通過新藥`,TypeOfPurchase.`何時刪除及倂項或分項列標`,"
	    			+"FirmData.`廠商統一編號`,FirmData.`廠商名稱`,FirmData.`電話`,FirmData.`傳真`,FirmData.`聯絡人`,FirmData.`聯絡人電話`,FirmData.`聯絡信箱`,FirmData.`廠商備註`,"
	    			+"Certificate.`管證登記證字號`,Certificate.`管證登記證生效起始日`,Certificate.`管證登記證生效終止日` FROM `Medicine`,`Certificate`,`FirmData`,`TypeOfPurchase`,`TenderResult`"
	    			+" WHERE Medicine.`藥品唯一碼` = '"+mdfmdonly[0]+"' AND FirmData.`廠商統一編號` = '"+mdfmdonly[1]+"' AND Medicine.`藥品唯一碼` = TenderResult.`藥品唯一碼` AND FirmData.`廠商統一編號` = TenderResult.`廠商統一編號` AND "
	    			+"Medicine.`藥品唯一碼` = TypeOfPurchase.`藥品唯一碼` AND FirmData.`廠商統一編號` = Certificate.`廠商統一編號` AND Certificate.`管證登記證生效終止日` = (SELECT max(管證登記證生效終止日) FROM `Certificate` WHERE Certificate.`廠商統一編號` = '"+mdfmdonly[1]+"')");
	           */
	           
	           System.out.println(mdfmdonly[0]+"*****"+mdfmdonly[1]);
	           
	           int order=0;
  			    while (rs.next()){
				      for(int i=1; i<=34; i++)
					  {
				    	 /*if(rs.getString(i)==null){
				    		data[i-1]="";
				    	 }
				    	 else{
				    		 	
				    	 }*/
				    	  //System.out.println(rs.getString(i));
				    	 alldata[i-1] = rs.getString(i);
				    	 
				    	 order++;
				      }
  				 }
  		  	  statement.close();
  		      conn.close();
  		      
  		      if(order == 0){
		    	    int result=JOptionPane.showConfirmDialog(null,
		    	               "查無資料相符資料！",
		    	               "查詢藥品品項",
		    	               JOptionPane.DEFAULT_OPTION,
		    	               JOptionPane.PLAIN_MESSAGE);
		    	    if (result==0) {
		    	    	Hidding.setVisible(true);
		    	    	dispose();
		    	    }
		    	    
					/*JButton bt = new JButton("確定"); //點擊後關閉跳出的訊息框
					JButton[] options = {bt};
					JOptionPane.showOptionDialog(null,"查無資料相符藥品廠商！","查詢藥品品項", JOptionPane.DEFAULT_OPTION, JOptionPane.DEFAULT_OPTION , null,null,null);
					bt.addActionListener(
					    new ActionListener() {
					        public void actionPerformed(ActionEvent e) {
					            SwingUtilities.windowForComponent(bt).dispose();
					        }
					    }
					);*/
		    	    
		    	    
		      }
  	        
  		}catch(ClassNotFoundException classNotFound){//找不到JDBC Driver
  	        classNotFound.printStackTrace();	
  		}catch(SQLException sqlException){//資料庫操作發生錯誤
  	        sqlException.printStackTrace();
  		} 


	  
        int a=0;        
		for(int i = 0;i < 3;i+=2){
			for(int j = 0;j< 17;j++){
				if(a==34){
					break;
				}
	        	JLabel field = new JLabel(str[a]);
	        	field.setFont(new Font("標楷體", Font.PLAIN, 15));
	            GridBagConstraints strr = new GridBagConstraints();
	            strr.gridx = i;
	            strr.gridy = j;
	            strr.gridwidth = 1;
	            strr.gridheight = 1;
	            strr.weightx = 0;
	            strr.weighty = 0;
	            strr.fill = GridBagConstraints.BOTH;
	            strr.anchor = GridBagConstraints.NORTHWEST;
	            panel_1.add(field, strr);
	            
	            a++;			
			}			
		}
		
        int b=0;       
		for(int i = 1;i < 4;i+=2){
			for(int j = 0;j< 17;j++){
				if(b==34){
					break;
				}
				field[b] = new JTextField(alldata[b]);
	        	field[b].setFont(new Font("標楷體", Font.PLAIN, 15));
	            GridBagConstraints strr = new GridBagConstraints();
	            strr.gridx = i;
	            strr.gridy = j;
	            strr.gridwidth = 1;
	            strr.gridheight = 1;
	            strr.weightx = 10;
	            strr.weighty = 10;
	            strr.fill = GridBagConstraints.BOTH;
	            strr.anchor = GridBagConstraints.NORTHWEST;
	            panel_1.add(field[b], strr);	           	            
	            
	            if(b==0 || b==23){
	            	field[b].setEditable(false);           
	            }
	            
	            b++;			
			}
		}
		
		

		
		
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);
		
		JButton btnBKReSearch = new JButton("返回查詢結果");
		btnBKReSearch.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(btnBKReSearch);
		
		JButton btnFace = new JButton("顯示預覽畫面");
		btnFace.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(btnFace);
		
		btnBKReSearch.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {	
	    		
	    			Hidding.setVisible(true);
	    			dispose();

	    	}
	        });
		btnFace.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {	
	    		

	            int c=0;       
	    		for(int i = 1;i < 4;i+=2){
	    			for(int j = 0;j< 17;j++){
	    				if(c==34){
	    					break;
	    				}


	    	            GridBagConstraints strr = new GridBagConstraints();
	    	            strr.gridx = i;
	    	            strr.gridy = j;
	    	            strr.gridwidth = 1;
	    	            strr.gridheight = 1;
	    	            strr.weightx = 10;
	    	            strr.weighty = 10;
	    	            System.out.println(c);
	    	        	getmodify = field[c].getText();
	    	        	getModify[c] = getmodify;
	    	            //strr.fill = GridBagConstraints.BOTH;
	    	            //strr.anchor = GridBagConstraints.NORTHWEST;
	    	            //panel_1.add(field, strr);
	    	            
	    	            c++;			
	    			}			
	    		}
	    		
	    		try {
	    			ModifyVMedicine mvm = new ModifyVMedicine(clone,getModify);
	    			mvm.setVisible(true);
	    			dispose();
	    		} catch (ClassNotFoundException e1) {
	    			// TODO Auto-generated catch block
	    			e1.printStackTrace();
	    		}

	    	}
	        });
	}

	

}
