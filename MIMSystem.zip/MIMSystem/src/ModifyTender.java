﻿import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ModifyTender extends JFrame {

	private JPanel contentPane;
	private JTextField Item_textfield;
	private JLabel content;
	private JTextField contedt_textField;
	private JTextField textField;
	private JTextField brand_textField;
	private JTextField quality_textField;
	private JTextField tenderunit_textField;
	private JTextField tenderpackage_textfield;
	private JLabel estimateprice;
	private JTextField estimateprice_textField;
	private JLabel estimateuse;
	private JTextField estimate_textfield;
	private JLabel estimatetotal;
	private JTextField estimatetotal_textfield;
	private JLabel startdate;
	private JTextField startdate_textField;
	private JTextField enddate_textField;
	private JLabel enddate;
	private JLabel situation;
	private JTextField textField_1;
	private JLabel label_1;
	private JTextField textField_2;
	private JLabel label_2;
	private JTextField textField_3;
	private JLabel label_3;
	private JTextField textField_4;
	private JLabel label_4;
	private JTextField textField_5;
	private JLabel label_5;
	private JTextField textField_6;
	private JLabel label_6;
	private JTextField textField_7;
	private JLabel label_7;
	private JTextField textField_8;
	private JLabel label_8;
	private JTextField textField_9;
	private JLabel label_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ModifyTender frame = new ModifyTender(null,null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ModifyTender(ShowTender ST,final String[] data) {
		setTitle("修改招標品項表");
		setResizable(false);
		final ShowTender Hidding=ST;
		final ModifyTender clone = this;
		String [] mdonly = data;//將上頁傳來的陣列放進此陣列
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 654);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		/*JLabel pic = new JLabel("");  //圖片
		pic.setBounds(938, 10, 46, 15);
		pic.setIcon(new ImageIcon("C:\\Users\\user\\workspace\\MIMSystem\\src\\MIM.png"));
		pic.setHorizontalAlignment(SwingConstants.RIGHT);
		contentPane.add(pic, BorderLayout.NORTH);*/
		
		JLabel Number = new JLabel("流水號 :"+mdonly[0]);
		Number.setFont(new Font("標楷體", Font.PLAIN, 18));
		Number.setBounds(10, 23, 218, 27);
		contentPane.add(Number);
		
		JLabel Item = new JLabel("案號項次 :"+mdonly[5]);
		Item.setFont(new Font("標楷體", Font.PLAIN, 18));
		Item.setBounds(238, 25, 223, 27);
		contentPane.add(Item);
				
		content = new JLabel("成份規格含量:");
		content.setFont(new Font("標楷體", Font.PLAIN, 15));
		content.setBounds(10, 115, 120, 27);
		contentPane.add(content);
		
		contedt_textField = new JTextField();
		contedt_textField.setText(mdonly[6]);
		contedt_textField.setFont(new Font("新細明體", Font.PLAIN, 16));
		contedt_textField.setColumns(10);
		contedt_textField.setBounds(121, 117, 273, 21);
		contentPane.add(contedt_textField);
		
		JLabel label = new JLabel("標註用藥品或藥材:");
		label.setFont(new Font("標楷體", Font.PLAIN, 15));
		label.setBounds(10, 152, 143, 27);
		contentPane.add(label);
		
		textField = new JTextField();
		textField.setText(mdonly[7]);
		textField.setFont(new Font("新細明體", Font.PLAIN, 16));
		textField.setColumns(10);
		textField.setBounds(149, 156, 245, 21);
		contentPane.add(textField);
		
		JLabel brand = new JLabel("廠牌或同等品:");
		brand.setFont(new Font("標楷體", Font.PLAIN, 15));
		brand.setBounds(489, 152, 116, 27);
		contentPane.add(brand);
		
		brand_textField = new JTextField();
		brand_textField.setText(mdonly[8]);
		brand_textField.setFont(new Font("新細明體", Font.PLAIN, 16));
		brand_textField.setColumns(10);
		brand_textField.setBounds(600, 156, 273, 21);
		contentPane.add(brand_textField);
		
		JLabel quality = new JLabel("品質需求:");
		quality.setFont(new Font("標楷體", Font.PLAIN, 15));
		quality.setBounds(10, 191, 72, 27);
		contentPane.add(quality);
		
		quality_textField = new JTextField();
		quality_textField.setText(mdonly[9]);
		quality_textField.setFont(new Font("新細明體", Font.PLAIN, 16));
		quality_textField.setColumns(10);
		quality_textField.setBounds(84, 195, 310, 21);
		contentPane.add(quality_textField);
		
		JLabel tenderunit = new JLabel("招標藥品單位:");
		tenderunit.setFont(new Font("標楷體", Font.PLAIN, 15));
		tenderunit.setBounds(489, 191, 116, 27);
		contentPane.add(tenderunit);
		
		tenderunit_textField = new JTextField();
		tenderunit_textField.setText(mdonly[10]);
		tenderunit_textField.setFont(new Font("新細明體", Font.PLAIN, 16));
		tenderunit_textField.setColumns(10);
		tenderunit_textField.setBounds(600, 195, 273, 21);
		contentPane.add(tenderunit_textField);
		
		JLabel tenderpackage = new JLabel("招標藥品包裝:");
		tenderpackage.setFont(new Font("標楷體", Font.PLAIN, 15));
		tenderpackage.setBounds(10, 231, 116, 27);
		contentPane.add(tenderpackage);
		
		tenderpackage_textfield = new JTextField();
		tenderpackage_textfield.setText(mdonly[11]);
		tenderpackage_textfield.setFont(new Font("新細明體", Font.PLAIN, 16));
		tenderpackage_textfield.setColumns(10);
		tenderpackage_textfield.setBounds(121, 235, 273, 21);
		contentPane.add(tenderpackage_textfield);
		
		estimateprice = new JLabel("預算單價:");
		estimateprice.setFont(new Font("標楷體", Font.PLAIN, 15));
		estimateprice.setBounds(489, 231, 77, 27);
		contentPane.add(estimateprice);
		
		estimateprice_textField = new JTextField();
		estimateprice_textField.setText(mdonly[12]);
		estimateprice_textField.setFont(new Font("新細明體", Font.PLAIN, 16));
		estimateprice_textField.setColumns(10);
		estimateprice_textField.setBounds(563, 235, 310, 21);
		contentPane.add(estimateprice_textField);
		
		estimateuse = new JLabel("預估用量:");
		estimateuse.setFont(new Font("標楷體", Font.PLAIN, 15));
		estimateuse.setBounds(10, 268, 72, 27);
		contentPane.add(estimateuse);
		
		estimate_textfield = new JTextField();
		estimate_textfield.setText(mdonly[13]);
		estimate_textfield.setFont(new Font("新細明體", Font.PLAIN, 16));
		estimate_textfield.setColumns(10);
		estimate_textfield.setBounds(84, 272, 310, 21);
		contentPane.add(estimate_textfield);
		
		estimatetotal = new JLabel("預估總價:");
		estimatetotal.setFont(new Font("標楷體", Font.PLAIN, 15));
		estimatetotal.setBounds(489, 268, 72, 27);
		contentPane.add(estimatetotal);
		
		estimatetotal_textfield = new JTextField();
		estimatetotal_textfield.setText(mdonly[14]);
		estimatetotal_textfield.setFont(new Font("新細明體", Font.PLAIN, 16));
		estimatetotal_textfield.setColumns(10);
		estimatetotal_textfield.setBounds(563, 272, 310, 21);
		contentPane.add(estimatetotal_textfield);
		
		startdate = new JLabel("履約起日:");
		startdate.setFont(new Font("標楷體", Font.PLAIN, 15));
		startdate.setBounds(10, 305, 72, 27);
		contentPane.add(startdate);
		
		startdate_textField = new JTextField();
		startdate_textField.setText(mdonly[15]);
		startdate_textField.setFont(new Font("新細明體", Font.PLAIN, 16));
		startdate_textField.setColumns(10);
		startdate_textField.setBounds(84, 309, 310, 21);
		contentPane.add(startdate_textField);
		
		enddate_textField = new JTextField();
		enddate_textField.setText(mdonly[16]);
		enddate_textField.setFont(new Font("新細明體", Font.PLAIN, 16));
		enddate_textField.setColumns(10);
		enddate_textField.setBounds(563, 309, 310, 21);
		contentPane.add(enddate_textField);
		
		enddate = new JLabel("履約迄日:");
		enddate.setFont(new Font("標楷體", Font.PLAIN, 15));
		enddate.setBounds(489, 305, 72, 27);
		contentPane.add(enddate);
		
		situation = new JLabel("標案狀況:");
		situation.setFont(new Font("標楷體", Font.PLAIN, 16));
		situation.setBounds(489, 340, 72, 27);
		contentPane.add(situation);
		
		textField_1 = new JTextField();
		textField_1.setText(mdonly[18]);
		textField_1.setFont(new Font("新細明體", Font.PLAIN, 16));
		textField_1.setColumns(10);
		textField_1.setBounds(563, 344, 310, 21);
		contentPane.add(textField_1);
		
		label_1 = new JLabel("後續擴充期限:");
		label_1.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_1.setBounds(489, 379, 104, 27);
		contentPane.add(label_1);
		
		textField_2 = new JTextField();
		textField_2.setText(mdonly[19]);
		textField_2.setFont(new Font("新細明體", Font.PLAIN, 16));
		textField_2.setColumns(10);
		textField_2.setBounds(600, 383, 273, 21);
		contentPane.add(textField_2);
		
		label_2 = new JLabel("後續擴充模式:");
		label_2.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_2.setBounds(10, 379, 104, 27);
		contentPane.add(label_2);
		
		textField_3 = new JTextField();
		textField_3.setText(mdonly[20]);
		textField_3.setFont(new Font("新細明體", Font.PLAIN, 16));
		textField_3.setColumns(10);
		textField_3.setBounds(121, 383, 273, 21);
		contentPane.add(textField_3);
		
		label_3 = new JLabel("後續擴充金額:");
		label_3.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_3.setBounds(489, 416, 104, 27);
		contentPane.add(label_3);
		
		textField_4 = new JTextField();
		textField_4.setText(mdonly[21]);
		textField_4.setFont(new Font("新細明體", Font.PLAIN, 16));
		textField_4.setColumns(10);
		textField_4.setBounds(600, 420, 273, 21);
		contentPane.add(textField_4);
		
		label_4 = new JLabel("後擴契約起日:");
		label_4.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_4.setBounds(10, 416, 104, 27);
		contentPane.add(label_4);
		
		textField_5 = new JTextField();
		textField_5.setText(mdonly[22]);
		textField_5.setFont(new Font("新細明體", Font.PLAIN, 16));
		textField_5.setColumns(10);
		textField_5.setBounds(121, 420, 273, 21);
		contentPane.add(textField_5);
		
		label_5 = new JLabel("後擴契約迄日:");
		label_5.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_5.setBounds(489, 453, 104, 27);
		contentPane.add(label_5);
		
		textField_6 = new JTextField();
		textField_6.setText(mdonly[23]);
		textField_6.setFont(new Font("新細明體", Font.PLAIN, 16));
		textField_6.setColumns(10);
		textField_6.setBounds(600, 457, 273, 21);
		contentPane.add(textField_6);
		
		label_6 = new JLabel("標購方式:");
		label_6.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_6.setBounds(10, 460, 72, 27);
		contentPane.add(label_6);
		
		textField_7 = new JTextField();
		textField_7.setText(mdonly[24]);
		textField_7.setFont(new Font("新細明體", Font.PLAIN, 16));
		textField_7.setColumns(10);
		textField_7.setBounds(84, 464, 310, 21);
		contentPane.add(textField_7);
		
		label_7 = new JLabel("歷次廠商報價:");
		label_7.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_7.setBounds(489, 495, 104, 27);
		contentPane.add(label_7);
		
		textField_8 = new JTextField();
		textField_8.setText(mdonly[25]);
		textField_8.setFont(new Font("新細明體", Font.PLAIN, 16));
		textField_8.setColumns(10);
		textField_8.setBounds(600, 499, 273, 21);
		contentPane.add(textField_8);
		
		label_8 = new JLabel("歷次廠商投標價:");
		label_8.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_8.setBounds(10, 497, 120, 27);
		contentPane.add(label_8);
		
		textField_9 = new JTextField();
		textField_9.setText(mdonly[26]);
		textField_9.setFont(new Font("新細明體", Font.PLAIN, 16));
		textField_9.setColumns(10);
		textField_9.setBounds(132, 501, 262, 21);
		contentPane.add(textField_9);
		
		label_9 = new JLabel("強制結案:");
		label_9.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_9.setBounds(489, 532, 68, 27);
		contentPane.add(label_9);
		
		textField_10 = new JTextField();
		textField_10.setText(mdonly[27]);
		textField_10.setFont(new Font("新細明體", Font.PLAIN, 16));
		textField_10.setColumns(10);
		textField_10.setBounds(563, 536, 310, 21);
		contentPane.add(textField_10);
		
		
		

		JButton next = new JButton("顯示預覽頁");
		next.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 String[] md= new String[28];
					md[0]=mdonly[0].toString();
					md[1]=textField_11.getText().trim();
					md[2]=textField_12.getText().trim();
					md[3]=textField_13.getText().trim();
					md[4]=textField_14.getText().trim();
					md[5]=mdonly[5].toString();
					md[6]=contedt_textField.getText().trim();
					md[7]=textField.getText().trim();
					md[8]=brand_textField.getText().trim();
					md[9]=quality_textField.getText().trim();
					md[10]=tenderunit_textField.getText().trim();
					md[11]=tenderpackage_textfield.getText().trim();
					md[12]=estimateprice_textField.getText().trim();
					md[13]=estimate_textfield.getText().trim();
					md[14]=estimatetotal_textfield.getText().trim();
					md[15]=startdate_textField.getText().trim();
					md[16]=enddate_textField.getText().trim();
					md[17]=textField_15.getText().trim();
					md[18]=textField_1.getText().trim();
					md[19]=textField_2.getText().trim();
					md[20]=textField_3.getText().trim();
					md[21]=textField_4.getText().trim();
					md[22]=textField_5.getText().trim();
					md[23]=textField_6.getText().trim();
					md[24]=textField_7.getText().trim();
					md[25]=textField_8.getText().trim();
					md[26]=textField_9.getText().trim();
					md[27]=textField_10.getText().trim();
					
				PreviewModifyTender PMT=new PreviewModifyTender(clone,md);
				PMT.setVisible(true);
				dispose();
			}
		});
		
		
		
		next.setFont(new Font("標楷體", Font.PLAIN, 14));
		next.setBounds(452, 581, 114, 34);
		contentPane.add(next);
		
		JButton reutrn = new JButton("返回上一頁");
		reutrn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Hidding.setVisible(true);
				dispose();
			}
		});
		reutrn.setFont(new Font("標楷體", Font.PLAIN, 14));
		reutrn.setBounds(326, 581, 114, 34);
		contentPane.add(reutrn);
		
		JLabel label_10 = new JLabel("中文案名:");
		label_10.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_10.setBounds(489, 78, 72, 27);
		contentPane.add(label_10);
		
		textField_11 = new JTextField();
		textField_11.setText(mdonly[1]);
		textField_11.setFont(new Font("新細明體", Font.PLAIN, 16));
		textField_11.setColumns(10);
		textField_11.setBounds(563, 82, 310, 21);
		contentPane.add(textField_11);
		
		JLabel label_11 = new JLabel("總務室承辦人:");
		label_11.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_11.setBounds(10, 78, 120, 27);
		contentPane.add(label_11);
		
		textField_12 = new JTextField();
		textField_12.setText(mdonly[2]);
		textField_12.setFont(new Font("新細明體", Font.PLAIN, 16));
		textField_12.setColumns(10);
		textField_12.setBounds(121, 82, 273, 21);
		contentPane.add(textField_12);
		
		JLabel label_12 = new JLabel("案號:");
		label_12.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_12.setBounds(489, 115, 45, 27);
		contentPane.add(label_12);
		
		textField_13 = new JTextField();
		textField_13.setText(mdonly[3]);
		textField_13.setFont(new Font("新細明體", Font.PLAIN, 16));
		textField_13.setColumns(10);
		textField_13.setBounds(532, 117, 341, 21);
		contentPane.add(textField_13);
		
		JLabel label_13 = new JLabel("管理費模式:");
		label_13.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_13.setBounds(10, 532, 120, 27);
		contentPane.add(label_13);
		
		textField_14 = new JTextField();
		textField_14.setText(mdonly[4]);
		textField_14.setFont(new Font("新細明體", Font.PLAIN, 16));
		textField_14.setColumns(10);
		textField_14.setBounds(101, 536, 293, 21);
		contentPane.add(textField_14);
		
		JLabel label_14 = new JLabel("履約期限:");
		label_14.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_14.setBounds(10, 344, 72, 27);
		contentPane.add(label_14);
		
		textField_15 = new JTextField();
		textField_15.setText(mdonly[17]);
		textField_15.setFont(new Font("新細明體", Font.PLAIN, 16));
		textField_15.setColumns(10);
		textField_15.setBounds(84, 348, 310, 21);
		contentPane.add(textField_15);
	}
}
