﻿import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class ModifyVMedicine extends JFrame {
	private String[] str =  {"藥品唯一碼","成份(包括含量、含量單位)","規格","規格單位","劑型","健保核價單位","包裝","藥品代碼","商品名","管制藥等級","成癮性麻醉藥品","藥品或藥材","ATCcode","藥理分類",
			"藥品適應症","藥理作用備註","備註","兒科水劑","用藥指導單張編碼","廠牌","藥品許可證字號",//Medicine
			"何時通過新藥","何時刪除/倂項或分項列標",//TypeOfPurchase
			"廠商統一編號","廠商名稱","電話","傳真","聯絡人","聯絡人電話","聯絡信箱","廠商備註",//FirmData
			"管證登記證字號","管證登記證生效起始日","管證登記證生效終止日"//Certificate 34
			};
	private JPanel contentPane;
	private JTable vTableMedicine;
	private JTable mvTableMedicine;
	private DefaultTableModel model;
	private JTextField infield[] = new JTextField[34];
	private String inmodify;
	private String [] inModify = new String[34];

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ModifyVMedicine frame = new ModifyVMedicine(null,null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ModifyVMedicine(ModifyMedicine MM,final String[] modifydata) throws ClassNotFoundException {
		setTitle("修改藥品品項");
		final ModifyVMedicine clone = this;
		final ModifyMedicine Hidding = MM;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		String [] modifymd = modifydata;
		
		JLabel pic1 = new JLabel("");
		java.net.URL imgURL = ModifyVMedicine.class.getResource("image/MIM.png");
		pic1.setIcon(new ImageIcon(imgURL));
		pic1.setHorizontalAlignment(SwingConstants.RIGHT);
		contentPane.add(pic1, BorderLayout.NORTH);
		
		JPanel panel_1 = new JPanel();
		panel_1.setPreferredSize(new Dimension(1200,700));
		JScrollPane scrollPane = new JScrollPane(panel_1);
		contentPane.add(scrollPane, BorderLayout.CENTER);
        panel_1.setAutoscrolls(true);
        GridBagLayout gbl_panel_1 = new GridBagLayout();
        gbl_panel_1.columnWidths = new int[]{0, 0};
        gbl_panel_1.rowHeights = new int[]{0, 0, 0};
        gbl_panel_1.columnWeights = new double[]{0.0, Double.MIN_VALUE};
        gbl_panel_1.rowWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
        panel_1.setLayout(gbl_panel_1);
        
        scrollPane.setPreferredSize(new Dimension(900,600));
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        contentPane.add(scrollPane,BorderLayout.CENTER);
	  
        int a=0;        
		for(int i = 0;i < 3;i+=2){
			for(int j = 0;j< 17;j++){
				if(a==34){
					break;
				}
	        	JLabel field = new JLabel(str[a]);
	        	field.setFont(new Font("標楷體", Font.PLAIN, 15));
	            GridBagConstraints strr = new GridBagConstraints();
	            strr.gridx = i;
	            strr.gridy = j;
	            strr.gridwidth = 1;
	            strr.gridheight = 1;
	            strr.weightx = 0;
	            strr.weighty = 0;
	            strr.fill = GridBagConstraints.BOTH;
	            strr.anchor = GridBagConstraints.NORTHWEST;
	            panel_1.add(field, strr);
	            
	            a++;			
			}			
		}
		
        int b=0;       
		for(int i = 1;i < 4;i+=2){
			for(int j = 0;j< 17;j++){
				if(b==34){
					break;
				}
	        	infield[b] = new JTextField(modifymd[b]);
	        	infield[b].setFont(new Font("標楷體", Font.PLAIN, 15));
	        	infield[b].setEditable(false);
	            GridBagConstraints strr = new GridBagConstraints();
	            strr.gridx = i;
	            strr.gridy = j;
	            strr.gridwidth = 1;
	            strr.gridheight = 1;
	            strr.weightx = 10;
	            strr.weighty = 10;
	            strr.fill = GridBagConstraints.BOTH;
	            strr.anchor = GridBagConstraints.NORTHWEST;
	            panel_1.add(infield[b], strr);
	            
	            b++;			
			}			
		}
		

		
		
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);
		
		JButton btnBKModify = new JButton("返回修改");
		btnBKModify.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(btnBKModify);
		
		JButton btnCRModify = new JButton("確認修改");
		btnCRModify.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(btnCRModify);
		
		btnBKModify.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {	
	    		
	    		Hidding.setVisible(true);
	    			dispose();

	    	}
	        });
		btnCRModify.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {	
	    		
	    		
	            int c=0;       
	    		for(int i = 1;i < 4;i+=2){
	    			for(int j = 0;j< 17;j++){
	    				if(c==34){
	    					break;
	    				}
	    	            GridBagConstraints strr = new GridBagConstraints();
	    	            strr.gridx = i;
	    	            strr.gridy = j;
	    	            strr.gridwidth = 1;
	    	            strr.gridheight = 1;
	    	            strr.weightx = 10;
	    	            strr.weighty = 10;
	    	            System.out.println(c);
	    	        	inmodify = infield[c].getText();
	    	        	inModify[c] = inmodify;
    	            
	    	            c++;			
	    			}			
	    		}
	    		
	    	      Connection conn = null;  
	    	  	  Statement statement;
	    	  	  ResultSet rs;
	    	  	  ResultSetMetaData rsMetaData;
	    	  	  String k="";
	    	  	  

	    	  	  
                   
	    	  	  try{
	    	  	         Class.forName("org.mariadb.jdbc.Driver");
	    	  	         System.out.println("資料庫連結成功");
	    	             conn = DriverManager.getConnection("jdbc:mariadb://lots.im.nuu.edu.tw/MIMSystem", "MIMSystem", "MIMSystem");
	    	             System.out.println("連接成功MySQL");
	    	             statement = conn.createStatement();
	    		         //statement.executeUpdate("INSERT INTO `Medicine`(`藥品唯一碼`, `成份`, `規格`, `規格單位`, `劑型`, `健保核價單位`, `包裝`, `藥品代碼`, `商品名`, `管制藥等級`, `成癮性麻醉藥品`, `藥品或藥材`, `ATCcode`, `藥理分類`, `藥品適應症`, `藥理作用備註`, `備註`, `兒科水劑`, `用藥指導單張編碼`, `廠牌`, `藥品許可證字號`) VALUES ('"+inNew[0]+"','"+inNew[9]+"','"+inNew[10]+"','"+inNew[11]+"','"+inNew[12]+"','"+inNew[13]+"','"+inNew[14]+"','"+inNew[17]+"','"+inNew[19]+"','"+inNew[6]+"','"+inNew[7]+"','"+inNew[8]+"','"+inNew[32]+"','"+inNew[33]+"','"+inNew[34]+"','"+inNew[35]+"','"+inNew[36]+"','"+inNew[37]+"','"+inNew[38]+"','"+inNew[30]+"','"+inNew[39]+"')");
	    		         statement.executeUpdate("UPDATE `Medicine` SET `成份`='"+inModify[1]+"',`規格`='"+inModify[2]+"',`規格單位`='"+inModify[3]+"',`劑型`='"+inModify[4]+"',`健保核價單位`='"+inModify[5]+"',`包裝`='"+inModify[6]+"',`藥品代碼`='"+inModify[7]+"',`商品名`='"+inModify[8]+"',`管制藥等級`='"+inModify[9]+"',`成癮性麻醉藥品`='"+inModify[10]+"',`藥品或藥材`='"+inModify[11]+"',`ATCcode`='"+inModify[12]+"',`藥理分類`='"+inModify[13]+"',`藥品適應症`='"+inModify[14]+"',`藥理作用備註`='"+inModify[15]+"',`備註`='"+inModify[16]+"',`兒科水劑`='"+inModify[17]+"',`用藥指導單張編碼`='"+inModify[18]+"',`廠牌`='"+inModify[19]+"',`藥品許可證字號`='"+inModify[20]+"' WHERE `藥品唯一碼` ='"+inModify[0]+"'");
	    		         statement.executeUpdate("UPDATE `FirmData` SET `廠商名稱`='"+inModify[24]+"',`電話`='"+inModify[25]+"',`傳真`='"+inModify[26]+"',`聯絡人`='"+inModify[27]+"',`聯絡人電話`='"+inModify[28]+"',`聯絡信箱`='"+inModify[29]+"',`廠商備註`='"+inModify[30]+"' WHERE `廠商統一編號` ='"+inModify[23]+"'");
	    		         statement.executeUpdate("UPDATE `TypeOfPurchase` SET `何時通過新藥`='"+inModify[21]+"',`何時刪除及倂項或分項列標`='"+inModify[22]+"' WHERE `藥品唯一碼` ='"+inModify[0]+"'");
	    		         statement.executeUpdate("INSERT INTO `Certificate`(`管證登記證字號`, `管證登記證生效起始日`, `管證登記證生效終止日`, `廠商統一編號`) VALUES ('"+inModify[31]+"','"+inModify[32]+"','"+inModify[33]+"','"+inModify[23]+"')");	
	    		         
	    		         
	    	  		  	  statement.close();
	    	  		      conn.close();
	    	  		      
	    		    	    int result=JOptionPane.showConfirmDialog(null,
	    		    	               "修改成功！",
	    		    	               "修改藥品品項",
	    		    	               JOptionPane.DEFAULT_OPTION,
	    		    	               JOptionPane.PLAIN_MESSAGE);
	    		    	    if (result==0) {
					    		Index ID;
								ID = new Index();
								ID.setVisible(true);
								dispose();
	    		    	    }

	    	  	         
	    	  	      }catch(ClassNotFoundException classNotFound){//找不到JDBC Driver
	    	  	        classNotFound.printStackTrace();
    		    	    int result=JOptionPane.showConfirmDialog(null,
 		    	               "修改失敗！",
 		    	               "修改藥品品項",
 		    	               JOptionPane.DEFAULT_OPTION,
 		    	               JOptionPane.PLAIN_MESSAGE);
    		    	    if (result==0) {
				    		Hidding.setVisible(true);
			    			dispose();
    		    	    }
	    	  	       }catch(SQLException sqlException){//資料庫操作發生錯誤
	    	  	        sqlException.printStackTrace();
    		    	    int result=JOptionPane.showConfirmDialog(null,
  		    	               "資料重複！",
  		    	               "修改藥品品項",
  		    	               JOptionPane.DEFAULT_OPTION,
  		    	               JOptionPane.PLAIN_MESSAGE);
     		    	    if (result==0) {
				    		Hidding.setVisible(true);
			    			dispose();
     		    	    }
	    	  	      }  
	    		
	    		
	    		


	    	}
	        });
	}

}
