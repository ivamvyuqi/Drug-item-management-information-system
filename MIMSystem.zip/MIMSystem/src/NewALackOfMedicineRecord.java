﻿import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.GridBagLayout;
import java.awt.Insets;


public class NewALackOfMedicineRecord extends JFrame {
	private String[] str =  {"得知日期","藥品唯一碼","缺停藥類型","訊息來源","公告來函日期","回收批號","缺停藥狀況說明","替代藥藥品唯一碼","替代藥類型","備註","恢復供貨日期","缺藥公文檔名","缺藥公文路徑"};
	private JPanel contentPane;
	private JTable aTableMedicine;
	private DefaultTableModel model;
	private JTextField field[] = new JTextField[13];
	private String getnew;
	private String [] getNew = new String[13];


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewALackOfMedicineRecord frame = new NewALackOfMedicineRecord(null,0,null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public NewALackOfMedicineRecord(final String[] data,final int EST,NewSRLackOfMedicineRecord NSRLOMR){//throws ClassNotFoundException {
		final NewALackOfMedicineRecord clone = this;
		final NewSRLackOfMedicineRecord Hidding = NSRLOMR;
		setTitle("新增缺藥紀錄");
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 900, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		String [] mdonly = data;
		
		
		JLabel pic1 = new JLabel("");
		java.net.URL img = Index.class.getResource("image/MIM.png");
		pic1.setIcon(new ImageIcon(img));
		pic1.setHorizontalAlignment(SwingConstants.RIGHT);
		contentPane.add(pic1, BorderLayout.NORTH);
		
		
	

		JPanel panel_1 = new JPanel();
		panel_1.setPreferredSize(new Dimension(1200,700));
		JScrollPane scrollPane = new JScrollPane(panel_1);
		contentPane.add(scrollPane, BorderLayout.CENTER);
        panel_1.setAutoscrolls(true);
        GridBagLayout gbl_panel_1 = new GridBagLayout();
        gbl_panel_1.columnWidths = new int[]{0, 0};
        gbl_panel_1.rowHeights = new int[]{0, 0, 0};
        gbl_panel_1.columnWeights = new double[]{0.0, Double.MIN_VALUE};
        gbl_panel_1.rowWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
        panel_1.setLayout(gbl_panel_1);
        
        scrollPane.setPreferredSize(new Dimension(900,600));
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        contentPane.add(scrollPane,BorderLayout.CENTER);
        
        
        
	  
        int a=0;
        int x=0;

			for(int j = 0;j< 13;j++){
				if(a==13){
					break;
				}
	        	JLabel field = new JLabel(str[a]);
	        	field.setFont(new Font("標楷體", Font.PLAIN, 15));
	            GridBagConstraints strr = new GridBagConstraints();
	            strr.gridx = x;
	            strr.gridy = j;
	            strr.gridwidth = 1;
	            strr.gridheight = 1;
	            strr.weightx = 0;
	            strr.weighty = 0;
	            strr.fill = GridBagConstraints.BOTH;
	            strr.anchor = GridBagConstraints.NORTHWEST;
	            panel_1.add(field, strr);
	            
	            a++;			
			}			
		
		
        int b=0;
        int y=1;

			for(int j = 0;j< 13;j++){
				if(b==13){
					break;
				}
	        	field[b] = new JTextField(mdonly[b]);
	        	field[b].setFont(new Font("標楷體", Font.PLAIN, 15));
	            GridBagConstraints strr = new GridBagConstraints();
	            strr.gridx = y;
	            strr.gridy = j;
	            strr.gridwidth = 1;
	            strr.gridheight = 1;
	            strr.weightx = 10;
	            strr.weighty = 10;
	            strr.fill = GridBagConstraints.BOTH;
	            strr.anchor = GridBagConstraints.NORTHWEST;
	            panel_1.add(field[b], strr);
	          	            
	            b++;			
			}			

			//上傳檔案  
			JButton button_1 = new JButton("上傳缺藥公文");
			button_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
		            JFileChooser fileChooser = new JFileChooser();//宣告filechooser 
		            int returnValue = fileChooser.showOpenDialog(null);//叫出filechooser 
		            if (returnValue == JFileChooser.APPROVE_OPTION) //判斷是否選擇檔案 
		            { 
			            File selectedFile = fileChooser.getSelectedFile();//指派給File 
			            System.out.println(selectedFile.getName()); //印出檔名
			            System.out.println(selectedFile.getAbsolutePath());
			            String path = selectedFile.getAbsolutePath();
			            String filepath = path.replace("\\","\\\\");
            	
			            field[11].setText(selectedFile.getName());
			            field[12].setText(filepath);
			            
		            }
		            
				}
			});
			/****/
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);
		
		JButton btnBKReSearch = new JButton("返回查詢結果");
		btnBKReSearch.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(btnBKReSearch);
		
		btnBKReSearch.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {	
	    			    		
	    			Hidding.setVisible(true);
	    			dispose();

	    	}
	        });
		

		button_1.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(button_1);
		
		JButton btnFace = new JButton("顯示預覽畫面");
		btnFace.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(btnFace);
		btnFace.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		
	            int c=0;
	            int z=1;
	    			for(int j = 0;j< 13;j++){
	    				if(c==13){
	    					break;
	    				}
	    	            GridBagConstraints strr = new GridBagConstraints();
	    	            strr.gridx = z;
	    	            strr.gridy = j;
	    	            strr.gridwidth = 1;
	    	            strr.gridheight = 1;
	    	            strr.weightx = 10;
	    	            strr.weighty = 10;
	    	            System.out.println(c);
	    	            getnew = field[c].getText();
	    	            getNew[c] = getnew;
	    	            //strr.fill = GridBagConstraints.BOTH;
	    	            //strr.anchor = GridBagConstraints.NORTHWEST;
	    	            //panel_1.add(field, strr);
	    	            
	    	            c++;			
	    			}
	    			
	    			
	    		
	    		
	    		
	    		String mednum = mdonly[0];
	    		try {
	    			NewVLackOfMedicineRecord nvm = new NewVLackOfMedicineRecord(clone,getNew,mednum);
	    			nvm.setVisible(true);
	    			dispose();
	    		} catch (ClassNotFoundException e1) {
	    			// TODO Auto-generated catch block
	    			e1.printStackTrace();
	    		}

	    	}
	        });
	}

}