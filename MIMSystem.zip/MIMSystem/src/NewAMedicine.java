﻿import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.GridBagLayout;
import java.awt.Insets;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.GridBagLayout;
import java.awt.Insets;

public class NewAMedicine extends JFrame {
	private String[] str =  {"藥品唯一碼","案號項次","決標分項","標案狀況","履約起日","履約迄日","管制藥等級","成癮性麻醉藥品","藥品或藥材","成份","規格",
			"規格單位","劑型","健保核價單位","包裝","缺停藥類型","替代藥類型","藥品代碼","缺停藥狀況說明","商品名","健保碼","健保價","預算單價","投標價","決標折讓X%","決標折讓Y%",
			"決標折讓Y%備註","決標淨額","廠商","廠牌","何時通過新藥","何時刪除及倂項或分項列標","ATCcode","藥理分類","藥品適應症","藥理作用備註","備註","兒科水劑","用藥指導單張編碼","藥品許可證字號"};
	private JPanel contentPane;
	private JTable aTableMedicine;
	private DefaultTableModel model;
	private JTextField field[] = new JTextField[40];
	private String getnew;
	private String [] getNew = new String[40];


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewAMedicine frame = new NewAMedicine(null,0,null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public NewAMedicine(final String[] data,final int EST,NewSRMedicine NSRM){//throws ClassNotFoundException {
		final NewAMedicine clone = this;
		final NewSRMedicine Hidding = NSRM;
		setTitle("新增藥品品項");
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 900, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		String [] mdonly = data;
		
		
		JLabel pic1 = new JLabel("");
		java.net.URL img = Index.class.getResource("image/MIM.png");
		pic1.setIcon(new ImageIcon(img));
		pic1.setHorizontalAlignment(SwingConstants.RIGHT);
		contentPane.add(pic1, BorderLayout.NORTH);

		JPanel panel_1 = new JPanel();
		panel_1.setPreferredSize(new Dimension(1200,700));
		JScrollPane scrollPane = new JScrollPane(panel_1);
		contentPane.add(scrollPane, BorderLayout.CENTER);
        panel_1.setAutoscrolls(true);
        GridBagLayout gbl_panel_1 = new GridBagLayout();
        gbl_panel_1.columnWidths = new int[]{0, 0};
        gbl_panel_1.rowHeights = new int[]{0, 0, 0};
        gbl_panel_1.columnWeights = new double[]{0.0, Double.MIN_VALUE};
        gbl_panel_1.rowWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
        panel_1.setLayout(gbl_panel_1);
        
        scrollPane.setPreferredSize(new Dimension(900,600));
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        contentPane.add(scrollPane,BorderLayout.CENTER);
	  
        int a=0;        
		for(int i = 0;i < 3;i+=2){
			for(int j = 0;j< 21;j++){
				if(a==40){
					break;
				}
	        	JLabel field = new JLabel(str[a]);
	        	field.setFont(new Font("標楷體", Font.PLAIN, 15));
	            GridBagConstraints strr = new GridBagConstraints();
	            strr.gridx = i;
	            strr.gridy = j;
	            strr.gridwidth = 1;
	            strr.gridheight = 1;
	            strr.weightx = 0;
	            strr.weighty = 0;
	            strr.fill = GridBagConstraints.BOTH;
	            strr.anchor = GridBagConstraints.NORTHWEST;
	            panel_1.add(field, strr);
	            
	            a++;			
			}			
		}
		
        int b=0;       
		for(int i = 1;i < 4;i+=2){
			for(int j = 0;j< 21;j++){
				if(b==40){
					break;
				}
	        	field[b] = new JTextField(mdonly[b]);
	        	field[b].setFont(new Font("標楷體", Font.PLAIN, 15));
	            GridBagConstraints strr = new GridBagConstraints();
	            strr.gridx = i;
	            strr.gridy = j;
	            strr.gridwidth = 1;
	            strr.gridheight = 1;
	            strr.weightx = 10;
	            strr.weighty = 10;
	            strr.fill = GridBagConstraints.BOTH;
	            strr.anchor = GridBagConstraints.NORTHWEST;
	            panel_1.add(field[b], strr);
	            
	            if(b==1 || b==2 || b==3 || b==4 || b==5 || b==15 || b==16 || b==18 || b==20 || b==21 || b==22 || b==23 || 
	            		b==24 || b==25 || b==26 || b==27 || b==28 || b==30 || b==31){
	            	field[b].setEditable(false);           
	            }
	            
	            b++;			
			}			
		}

		
		
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);
		
		JButton btnBKReSearch = new JButton("返回查詢結果");
		btnBKReSearch.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(btnBKReSearch);
		
		JButton btnFace = new JButton("顯示預覽畫面");
		btnFace.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(btnFace);
		
		btnBKReSearch.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {	
	    			    		
	    			Hidding.setVisible(true);
	    			dispose();

	    	}
	        });
		btnFace.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		
	            int c=0;       
	    		for(int i = 1;i < 4;i+=2){
	    			for(int j = 0;j< 21;j++){
	    				if(c==40){
	    					break;
	    				}


	    	            GridBagConstraints strr = new GridBagConstraints();
	    	            strr.gridx = i;
	    	            strr.gridy = j;
	    	            strr.gridwidth = 1;
	    	            strr.gridheight = 1;
	    	            strr.weightx = 10;
	    	            strr.weighty = 10;
	    	            System.out.println(c);
	    	        	getnew = field[c].getText();
	    	        	getNew[c] = getnew;
	    	            //strr.fill = GridBagConstraints.BOTH;
	    	            //strr.anchor = GridBagConstraints.NORTHWEST;
	    	            //panel_1.add(field, strr);
	    	            
	    	            c++;			
	    			}			
	    		}
	    		
	    		
	    		
	    		String mednum = mdonly[0];
	    		try {
	    			NewVMedicine nvm = new NewVMedicine(clone,getNew,mednum);
	    			nvm.setVisible(true);
	    			dispose();
	    		} catch (ClassNotFoundException e1) {
	    			// TODO Auto-generated catch block
	    			e1.printStackTrace();
	    		}

	    	}
	        });
	}

}