﻿import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;


public class NewFirm extends JFrame {

	private static final String ActionListener = null;
	private JPanel contentPane;
	private JTextField firmname_textfield;
	private JTextField firmfax_textfield;
	private JTextField EIN_textfield;
	private JTextField firmphone_textfield;
	private JTextField personphone_textfield;
	private JTextField personname_textfield;
	private JTextField personemail_textfield;
	private JTextField number1_textField;

	private JTextField star1_textField;

	private JTextField end1_textField;
	private JTextField firmremark_textField;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewFirm frame = new NewFirm(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public NewFirm(Index index) {
		setTitle("\u65B0\u589E\u5EE0\u5546\u8CC7\u6599");
		final Index Hidding = index;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 935, 344);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		/*JLabel lblNewLabel = new JLabel("");
		java.net.URL img = Index.class.getResource("image/MIM.png");
		lblNewLabel.setIcon(new ImageIcon(img));
		lblNewLabel.setBounds(749, 0, 160, 129);
		contentPane.add(lblNewLabel);*/
		
		JLabel firmname = new JLabel("\u5EE0\u5546\u540D\u7A31\uFF1A");
		firmname.setBounds(10, 60, 84, 18);
		firmname.setFont(new Font("標楷體", Font.PLAIN, 15));
		contentPane.add(firmname);
		
		JLabel firmfax = new JLabel("\u5EE0\u5546\u50B3\u771F\uFF1A");
		firmfax.setBounds(10, 91, 84, 18);
		firmfax.setFont(new Font("標楷體", Font.PLAIN, 15));
		contentPane.add(firmfax);
		
		JLabel firmphone = new JLabel("\u5EE0\u5546\u96FB\u8A71\uFF1A");
		firmphone.setBounds(396, 56, 84, 18);
		firmphone.setFont(new Font("標楷體", Font.PLAIN, 15));
		contentPane.add(firmphone);
		
		JLabel EIN = new JLabel("\u7D71\u4E00\u7DE8\u865F\uFF1A");
		EIN.setBounds(396, 87, 84, 18);
		EIN.setFont(new Font("標楷體", Font.PLAIN, 15));
		contentPane.add(EIN);
		
		firmname_textfield = new JTextField();
		firmname_textfield.setBounds(115, 60, 179, 21);
		contentPane.add(firmname_textfield);
		firmname_textfield.setColumns(10);
		
		firmfax_textfield = new JTextField();
		firmfax_textfield.setBounds(115, 91, 179, 21);
		firmfax_textfield.setColumns(10);
		contentPane.add(firmfax_textfield);
		
		EIN_textfield = new JTextField();
		EIN_textfield.setBounds(476, 87, 179, 21);
		EIN_textfield.setColumns(10);
		contentPane.add(EIN_textfield);
		
		firmphone_textfield = new JTextField();
		firmphone_textfield.setBounds(476, 56, 179, 21);
		firmphone_textfield.setColumns(10);
		contentPane.add(firmphone_textfield);
		
		JLabel personname = new JLabel("\u806F\u7D61\u4EBA\u540D\u7A31\uFF1A");
		personname.setBounds(10, 121, 95, 18);
		personname.setFont(new Font("標楷體", Font.PLAIN, 15));
		contentPane.add(personname);
		
		JLabel personmail = new JLabel("\u806F\u7D61\u4EBA\u4FE1\u7BB1\uFF1A");
		personmail.setBounds(10, 152, 95, 18);
		personmail.setFont(new Font("標楷體", Font.PLAIN, 15));
		contentPane.add(personmail);
		
		JLabel personphone = new JLabel("\u806F\u7D61\u4EBA\u96FB\u8A71\uFF1A");
		personphone.setBounds(382, 120, 98, 18);
		personphone.setFont(new Font("標楷體", Font.PLAIN, 15));
		contentPane.add(personphone);
		
		personphone_textfield = new JTextField();
		personphone_textfield.setBounds(476, 118, 179, 21);
		personphone_textfield.setColumns(10);
		contentPane.add(personphone_textfield);
		
		personname_textfield = new JTextField();
		personname_textfield.setBounds(115, 121, 179, 21);
		personname_textfield.setColumns(10);
		contentPane.add(personname_textfield);
		
		personemail_textfield = new JTextField();
		personemail_textfield.setBounds(115, 153, 423, 21);
		personemail_textfield.setColumns(10);
		contentPane.add(personemail_textfield);
		
		JLabel number1 = new JLabel("\u7BA1\u8B49\u767B\u8A18\u8B49\u5B57\u865F\uFF1A");
		number1.setBounds(10, 184, 122, 18);
		number1.setFont(new Font("標楷體", Font.PLAIN, 15));
		contentPane.add(number1);
		
		number1_textField = new JTextField();
		number1_textField.setBounds(130, 183, 179, 21);
		number1_textField.setColumns(10);
		contentPane.add(number1_textField);
		
		
		JLabel star1 = new JLabel("\u751F\u6548\u8D77\u59CB\u65E5\uFF1A");
		star1.setBounds(342, 186, 95, 18);
		star1.setFont(new Font("標楷體", Font.PLAIN, 15));
		contentPane.add(star1);
		
		star1_textField = new JTextField();
		star1_textField.setBounds(433, 184, 179, 21);
		star1_textField.setColumns(10);
		contentPane.add(star1_textField);
		
		
		JLabel end1 = new JLabel("\u751F\u6548\u7D42\u6B62\u65E5\uFF1A");
		end1.setBounds(633, 186, 95, 18);
		end1.setFont(new Font("標楷體", Font.PLAIN, 15));
		contentPane.add(end1);
		
		end1_textField = new JTextField();
		end1_textField.setBounds(723, 184, 179, 21);
		end1_textField.setColumns(10);
		contentPane.add(end1_textField);
		
		final NewFirm clone =this;
		final String[] firm=new String[11];
		JButton tomodifynewfirm = new JButton("\u986F\u793A\u9810\u89BD\u9801");
		tomodifynewfirm.setFont(new Font("標楷體", Font.PLAIN, 15));
		tomodifynewfirm.setBounds(474, 268, 122, 27);
		tomodifynewfirm.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				//
				String firmname2,firmphone2,firmfax2,EIN2,personname2,personphone2,personemail2,firmremark2;
				String num1,starstar1,endend1;
				firmname2=firmname_textfield.getText();
				firmphone2=firmphone_textfield.getText();
				firmfax2=firmfax_textfield.getText();
				EIN2=EIN_textfield.getText();
				personname2=personname_textfield.getText();
				personphone2=personphone_textfield.getText();
				personemail2=personemail_textfield.getText();
				num1=number1_textField.getText();
				starstar1=star1_textField.getText();
				endend1=end1_textField.getText();
				firmremark2=firmremark_textField.getText();
				int empty=0;
				
				//
				firm[0]=firmname_textfield.getText();
				firm[1]=firmphone_textfield.getText();
				firm[2]=firmfax_textfield.getText();
				firm[3]=EIN_textfield.getText();
				firm[4]=personname_textfield.getText();
				firm[5]=personphone_textfield.getText();
				firm[6]=personemail_textfield.getText();
				firm[7]=number1_textField.getText();
				firm[8]=star1_textField.getText();
				firm[9]=end1_textField.getText();
				firm[10]=firmremark_textField.getText();

				try{
					if("".equals(firmname2.toString().trim())){empty++;}
					if("".equals(firmphone2.toString().trim())){empty++;}
					if("".equals(firmfax2.toString().trim())){empty++;}
					if("".equals(EIN2.toString().trim())){empty++;}
					if("".equals(personname2.toString().trim())){empty++;}
					if("".equals(personphone2.toString().trim())){empty++;}
					if("".equals(personemail2.toString().trim())){empty++;}
					if("".equals(num1.toString().trim())){empty++;}
					if("".equals(starstar1.toString().trim())){empty++;}
					if("".equals(endend1.toString().trim())){empty++;}
					if(empty==0){
						//if (checkFirm(firmname2,EIN2)!=1){
							PreviewNewFirm PNF =new PreviewNewFirm(clone,firmname_textfield.getText(),firmphone_textfield.getText(),firmfax_textfield.getText(),EIN_textfield.getText(),personname_textfield.getText(),personphone_textfield.getText(),personemail_textfield.getText(),number1_textField.getText(),star1_textField.getText(),end1_textField.getText(),firmremark_textField.getText());
							PNF.setVisible(true);
							dispose();
						//}else{
						//	JOptionPane.showMessageDialog(null, "��ƫ�����²�٭���","�s�W���~",JOptionPane.WARNING_MESSAGE);}
					}else JOptionPane.showMessageDialog(null, "欄位不可空值", "新增失敗", JOptionPane.WARNING_MESSAGE);
				}catch(NumberFormatException n){
					JOptionPane.showMessageDialog(null, "��J���~", "ĵ�i", JOptionPane.WARNING_MESSAGE);
					n.printStackTrace();
				}
			}
		});
		contentPane.add(tomodifynewfirm);
		
		JLabel firmremark = new JLabel("廠商備註：");
		firmremark.setFont(new Font("標楷體", Font.PLAIN, 15));
		firmremark.setBounds(10, 237, 84, 18);
		contentPane.add(firmremark);
		
		firmremark_textField = new JTextField();
		firmremark_textField.setColumns(10);
		firmremark_textField.setBounds(115, 237, 423, 21);
		contentPane.add(firmremark_textField);
		
		JButton btnNewButton = new JButton("返回主選單");
		btnNewButton.setFont(new Font("標楷體", Font.PLAIN, 15));
		btnNewButton.setBounds(325, 268, 122, 26);
		btnNewButton.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {	

	    			Hidding.setVisible(true);
	    			dispose();

	    	}
	    });
		contentPane.add(btnNewButton);
		
		
		JLabel label = new JLabel("新增廠商資料");
		label.setFont(new Font("標楷體", Font.PLAIN, 20));
		label.setBounds(349, 10, 131, 36);
		contentPane.add(label);
		
		}
}
