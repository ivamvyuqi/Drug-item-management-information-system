﻿import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.EventListener;
import java.util.EventObject;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.CellEditorListener;
import javax.swing.event.EventListenerList;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import java.awt.Component;
import java.awt.Dimension;


public class NewSRLackOfMedicineRecord extends JFrame implements ActionListener {
	private final boolean DEBUG = false;
	private JButton btnNewMedicine[];
	private JPanel contentPane;
	private JPanel panel_1;
	private JTable tableMedicine;
	private DefaultTableModel model;
	private String sMedicine;
	private String iMedicine;
	private Object[][] data = new Object[1][];
	static int numberOfColumns = 0;
	private int numberOfRows=0;
	static String []columnNames=new String[1];

	static NewALackOfMedicineRecord[] nam=new NewALackOfMedicineRecord[1];
	static int EST=0;
	static int testn=0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewSRLackOfMedicineRecord frame = new NewSRLackOfMedicineRecord(null,"","");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public NewSRLackOfMedicineRecord(NewLackOfMedicineRecord NLOMR,String sM,String iM) throws ClassNotFoundException {
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		final NewSRLackOfMedicineRecord clone = this;
		final NewLackOfMedicineRecord Hidding = NLOMR;
		setTitle("新增缺藥紀錄");
		setBounds(100, 100, 900, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		sMedicine = sM;
		iMedicine = iM;
		
		JLabel pic1 = new JLabel("");
		java.net.URL img = Index.class.getResource("image/MIM.png");
		pic1.setIcon(new ImageIcon(img));
		pic1.setHorizontalAlignment(SwingConstants.RIGHT);
		contentPane.add(pic1, BorderLayout.NORTH);
		
		panel_1 = new JPanel();
		panel_1.setLayout( new BorderLayout() );
        getContentPane().add( panel_1 );
        
        
      Connection conn = null;  
  	  Statement statement;
  	  ResultSet rs;
  	  ResultSetMetaData rsMetaData;
  	  String k="";
  	  //String columnNames[] = {sMedicine,"新增"};
  	  try{
  	         Class.forName("org.mariadb.jdbc.Driver");
  	         System.out.println("資料庫連結成功");
             conn = DriverManager.getConnection("jdbc:mariadb://lots.im.nuu.edu.tw/MIMSystem", "MIMSystem", "MIMSystem");
             System.out.println("連接成功MySQL");
             statement = conn.createStatement();
             //rs = statement.executeQuery("SELECT * FROM Medicine where "+sMedicine+" LIKE '%"+iMedicine+"%'");
	           rs = statement.executeQuery("SELECT * FROM `ReLackMedicineRecord` WHERE `"+sMedicine+"` LIKE '%"+iMedicine+"%'");
	                         rsMetaData = rs.getMetaData();
  			 numberOfColumns = rsMetaData.getColumnCount();	
  			 columnNames=new String[numberOfColumns+1];
  	  
  				for(int i=1; i<=numberOfColumns; i++){
  				  System.out.printf("%s\t",rsMetaData.getColumnName(i));//計算有幾欄
  				columnNames[i-1]=rsMetaData.getColumnName(i);//每欄名稱
  				}
  			    
  			    System.out.println();
  			    
  			  boolean nodata= true;
  			    while (rs.next()){
  			    	nodata=false;
  			      for(int i=1; i<=numberOfColumns; i++)
  				   {
  				     System.out.printf("%s\t",rs.getObject(i));			  	
  			       }
  			      System.out.println();	
  			      numberOfRows++;
  			     }
  			    if(nodata){
  			    	
  			    }
  			    
  			  btnNewMedicine = new JButton[numberOfRows];//每筆後面有按鈕

		    
  			    data=new Object[numberOfRows][numberOfColumns+1];//開大小
  			    int order=0;
	           rs = statement.executeQuery("SELECT * FROM `ReLackMedicineRecord` WHERE `"+sMedicine+"` LIKE '%"+iMedicine+"%'");

  			    while (rs.next()){
				      for(int i=1; i<=numberOfColumns; i++)
					   {
				    	 if(rs.getObject(i)==null){
				    		data[order][i-1]="";
				    	 }
				    	 else{
				    		 data[order][i-1]=rs.getObject(i);	
				    	 }
					     		  	
				       }
				      order++;
  				 }
  		  	  statement.close();
  		      conn.close();
  		      
  		      if(order == 0){
		    	    int result=JOptionPane.showConfirmDialog(null,
		    	               "查無資料！",
		    	               "新增缺藥紀錄",
		    	               JOptionPane.DEFAULT_OPTION,
		    	               JOptionPane.PLAIN_MESSAGE);
 		    	    if (result==0) {
 		    	    	Hidding.setVisible(true);
 		    	    	dispose();
 		    	    }
  		      }
  	         
  	         
  	      }catch(ClassNotFoundException classNotFound){//找不到JDBC Driver
  	        classNotFound.printStackTrace();	
  	       }catch(SQLException sqlException){//資料庫操作發生錯誤
  	        sqlException.printStackTrace();
  	      }  
  	  	  
  	  	 // Table(columnNames, data);
  	 
      
      MyTableModel myTableModel = new MyTableModel(columnNames, data);//自行定義table
      myTableModel.fireTableDataChanged();
      if (DEBUG) { 
        for (int i = 0; i < numberOfRows; i++) {
          for (int j = 0; j < numberOfColumns; j++) {
            System.out.println(myTableModel.getValueAt(i, j) + "  ");
          }
        }
      }
      
      for (int i = 0; i < data.length; i++) { //按鈕
      	btnNewMedicine[i] = new JButton("新增"+i);     	
      	data[i][numberOfColumns] = btnNewMedicine[i];
      }
      ////numberOfRows=0;
      System.out.println(data.length);
      tableMedicine = new JTable(myTableModel); 
      //tableMedicine.setFont(new Font("標楷體", Font.PLAIN, 15));
      tableMedicine.setRowSelectionAllowed(false);
      tableMedicine.getTableHeader().setReorderingAllowed(false);//欄位拖動功能
      tableMedicine.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);  
      tableMedicine.setPreferredScrollableViewportSize(new Dimension(650, 70));
      // table.setFillsViewportHeight(true);
      // Create the scroll pane and add the table to it.
      JScrollPane scrollPane = new JScrollPane(tableMedicine);
      tableMedicine.setDefaultRenderer(JButton.class, new JButtonRenderer());
      // Add the scroll pane to this panel.
      //add(scrollPane);
      panel_1.add(scrollPane, BorderLayout.CENTER);
      final TableCellButton tableCellButton = new TableCellButton();
      tableMedicine.setDefaultEditor(JButton.class, tableCellButton);
      tableCellButton.addActionListener(this);
		

		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);
		
		JButton btnReSearch = new JButton("重新查詢");
		btnReSearch.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(btnReSearch);
				
		btnReSearch.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {	
	    		
	    		 
	    			Hidding.setVisible(true);
	    			dispose();

	    	}
	        });
  	  
  	  
  	  
    }
   
    /*public void Table(String[] columnNames, Object[][] data) {
  	
      super(new GridLayout(1, 0));
      MyTableModel myTableModel = new MyTableModel(columnNames, data);
      myTableModel.fireTableDataChanged();
      if (DEBUG) {
        for (int i = 0; i < numberOfRows; i++) {
          for (int j = 0; j < numberOfColumns; j++) {
            System.out.println(myTableModel.getValueAt(i, j) + "  ");
          }
        }
      }
      
      for (int i = 0; i < data.length; i++) {
    	  btnNewMedicine[i]=new JButton("新增");
      	data[i][numberOfColumns] = btnNewMedicine[i];
      }
      
      tableMedicine = new JTable(myTableModel);
      //tableMedicine.setFont(new Font("標楷體", Font.PLAIN, 15));
      tableMedicine.setRowSelectionAllowed(false);
      tableMedicine.getTableHeader().setReorderingAllowed(false);//欄位拖動功能
      tableMedicine.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);  
      tableMedicine.setPreferredScrollableViewportSize(new Dimension(650, 70));
      // table.setFillsViewportHeight(true);
      // Create the scroll pane and add the table to it.
      JScrollPane scrollPane = new JScrollPane(tableMedicine);
      tableMedicine.setDefaultRenderer(JButton.class, new JButtonRenderer());
      // Add the scroll pane to this panel.
      //add(scrollPane);
      panel_1.add(scrollPane, BorderLayout.CENTER);
      final TableCellButton tableCellButton = new TableCellButton();
      tableMedicine.setDefaultEditor(JButton.class, tableCellButton);
      tableCellButton.addActionListener(this);

		
	}*/
	  public void actionPerformed(ActionEvent actEvent) { 
		  

		 System.out.println(actEvent);
		  int ae = Integer.parseInt(actEvent.getActionCommand().substring(2));//取按鈕上面的第3個字，從0開始
		  System.out.println(ae);
		  String[] d= new String[numberOfColumns];
		  for(int i=0; i<numberOfColumns;i++){
			  d[i]=data[ae][i].toString();
		  }
		  testn++;
		switch("SearchOrder"){	  	
		case "SearchOrder" :{
			NewSRLackOfMedicineRecord clone = this;
		  		if(nam[0]!=null){
		  			
		  			nam = new NewALackOfMedicineRecord[2];
					nam[1]=new NewALackOfMedicineRecord(d,EST,clone);
		  			nam[0].setVisible(false);	
		  			nam[1].setVisible(true);
		  			dispose();
			  		break;
			  		
	
		  		}
		  		nam = new NewALackOfMedicineRecord[1];
				nam[0]=new NewALackOfMedicineRecord(d,EST,clone);
		  		nam[0].setVisible(true);
		  		dispose();
		  		break;
				}
		  		default: break;
		  }
		  

		  
		  

	  }
	  class MyTableModel extends AbstractTableModel { 
	    String[] columnNames;
	    Object[][] data;
	    public void removeTableModelListener(TableModelListener l){
	    	l.tableChanged(null);
	    }
	    public MyTableModel(String[] columnNames, Object[][] data) {
	      this.columnNames = columnNames;
	      this.data = data;
	    }
	 
	    public int getColumnCount() {
	      return columnNames.length;
	    }
	 
	    public int getRowCount() {
	      return data.length;
	    }
	 
	    public String getColumnName(int col) {
	      return columnNames[col];
	    }
	 
	    public Object getValueAt(int row, int col) {
	      return data[row][col];
	    }
	 
	    public Class getColumnClass(int c) {
	      return getValueAt(0, c).getClass();
	      //Object value=this.getValueAt(0,c);
	     // return (value==null?Object.class:value.getClass());

	    }
	 
	    @Override
	    public boolean isCellEditable(int rowIndex, int columnIndex) {
	      return getColumnClass(columnIndex) == JButton.class;
	    }
	    
	  }
}
/*class TableCellButton extends JButton implements TableCellEditor {
	  private EventListenerList cellEditorListeners = new EventListenerList();
	 
	  public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected,
	      int row, int column) {
	    JButton button = (JButton) value;
	    setText(button.getText());
	    putClientProperty("row", new Integer(row));
	    return this;
	  }
	 
	  public void addCellEditorListener(CellEditorListener l) {
	    cellEditorListeners.add(CellEditorListener.class, l);
	  }
	 
	  protected void fireEditingCanceled() {
	    EventListener[] listeners = cellEditorListeners.getListeners(CellEditorListener.class);
	    for (int i = 0; i < listeners.length; ++i) {
	      CellEditorListener l = (CellEditorListener) listeners[i];
	      l.editingCanceled(changeEvent);
	    }
	  }
	 
	  protected void fireEditingStopped() {
	    EventListener[] listeners = cellEditorListeners.getListeners(CellEditorListener.class);
	    for (int i = 0; i < listeners.length; ++i) {
	      CellEditorListener l = (CellEditorListener) listeners[i];
	      l.editingStopped(changeEvent);
	    }
	  }
	 
	  public void cancelCellEditing() {
	    fireEditingCanceled();
	  }
	 
	  public Object getCellEditorValue() {
	    return null;
	  }
	 
	  public boolean isCellEditable(EventObject anEvent) {
	    if (anEvent instanceof MouseEvent) {
	      MouseEvent e = (MouseEvent) anEvent;
	      if (e.getID() == MouseEvent.MOUSE_PRESSED) {
	        MouseEvent newEvent = new MouseEvent(this, MouseEvent.MOUSE_PRESSED, e.getWhen(), e
	            .getModifiers(), 0, 0, e.getClickCount(), e.isPopupTrigger());
	        Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(newEvent);
	        return true;
	      }
	    }
	    return false;
	  }
	 
	  public void removeCellEditorListener(CellEditorListener l) {
	    cellEditorListeners.remove(CellEditorListener.class, l);
	  }
	 
	  public boolean shouldSelectCell(EventObject anEvent) {
	    return false;
	  }
	 
	  public boolean stopCellEditing() {
	    fireEditingStopped();
	    return true;
	  }
	}
	 
	class JButtonRenderer extends JButton implements TableCellRenderer {
	  public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
	      boolean hasFocus, int row, int column) {
	    JButton button = (JButton) value;
	    setText(button.getText());
	    return this;
	  }
	}
*/