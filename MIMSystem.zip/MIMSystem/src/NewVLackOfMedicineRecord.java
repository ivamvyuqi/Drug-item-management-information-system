﻿import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;


public class NewVLackOfMedicineRecord extends JFrame {
	private String[] str =  {"得知日期","藥品唯一碼","缺停藥類型","訊息來源","公告來函日期","回收批號","缺停藥狀況說明","替代藥藥品唯一碼","替代藥類型","備註","恢復供貨日期","缺藥公文檔名","缺藥公文路徑"};
	private JPanel contentPane;
	private JTable vTableMedicine;
	private DefaultTableModel model;
	private JTextField infield[] = new JTextField[13];
	private String innew;
	private String [] inNew = new String[13];

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewVMedicine frame = new NewVMedicine(null,null,null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public NewVLackOfMedicineRecord(NewALackOfMedicineRecord NALOMR,final String[] newdata,String mednum) throws ClassNotFoundException {
		final NewVLackOfMedicineRecord clone = this;
		final NewALackOfMedicineRecord Hidding = NALOMR;

		setTitle("新增缺藥紀錄");
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 900, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		String [] newmd = newdata;
		String onlymednum = mednum;
		
		JLabel pic1 = new JLabel("");
		java.net.URL img = Index.class.getResource("image/MIM.png");
		pic1.setIcon(new ImageIcon(img));
		pic1.setHorizontalAlignment(SwingConstants.RIGHT);
		contentPane.add(pic1, BorderLayout.NORTH);
		
		JPanel panel_1 = new JPanel();
		panel_1.setPreferredSize(new Dimension(1200,700));
		JScrollPane scrollPane = new JScrollPane(panel_1);
		contentPane.add(scrollPane, BorderLayout.CENTER);
        panel_1.setAutoscrolls(true);
        GridBagLayout gbl_panel_1 = new GridBagLayout();
        gbl_panel_1.columnWidths = new int[]{0, 0};
        gbl_panel_1.rowHeights = new int[]{0, 0, 0};
        gbl_panel_1.columnWeights = new double[]{0.0, Double.MIN_VALUE};
        gbl_panel_1.rowWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
        panel_1.setLayout(gbl_panel_1);
        
        scrollPane.setPreferredSize(new Dimension(900,600));
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        contentPane.add(scrollPane,BorderLayout.CENTER);
	  
        int a=0;        
        int x=0;
			for(int j = 0;j< 13;j++){
				if(a==13){
					break;
				}
	        	JLabel field = new JLabel(str[a]);
	        	field.setFont(new Font("標楷體", Font.PLAIN, 15));
	            GridBagConstraints strr = new GridBagConstraints();
	            strr.gridx = x;
	            strr.gridy = j;
	            strr.gridwidth = 1;
	            strr.gridheight = 1;
	            strr.weightx = 0;
	            strr.weighty = 0;
	            strr.fill = GridBagConstraints.BOTH;
	            strr.anchor = GridBagConstraints.NORTHWEST;
	            panel_1.add(field, strr);
	            
	            a++;			
			}			
		
		
        int b=0;       
        int y=1;
			for(int j = 0;j< 13;j++){
				if(b==13){
					break;
				}
	        	infield[b] = new JTextField(newmd[b]);
	        	infield[b].setFont(new Font("標楷體", Font.PLAIN, 15));
	        	infield[b].setEditable(false);
	            GridBagConstraints strr = new GridBagConstraints();
	            strr.gridx = y;
	            strr.gridy = j;
	            strr.gridwidth = 1;
	            strr.gridheight = 1;
	            strr.weightx = 10;
	            strr.weighty = 10;
	            strr.fill = GridBagConstraints.BOTH;
	            strr.anchor = GridBagConstraints.NORTHWEST;
	            panel_1.add(infield[b], strr);
	            
	            b++;			
			}

		
		

		
		
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);
		
		JButton btnBKNew = new JButton("返回新增");
		btnBKNew.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(btnBKNew);
		
		JButton btnCRNew = new JButton("確認新增");
		btnCRNew.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(btnCRNew);
		
		btnBKNew.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {	
	    		
	    		/*try {
	    			SearchMResult smr = new SearchMResult(clone,selectGroup,selectMedicament,selectCondition,cansearch);
	    		} catch (ClassNotFoundException e1) {
	    			// TODO Auto-generated catch block
	    			e1.printStackTrace();
	    		}*/

	    		Hidding.setVisible(true);
	    			dispose();


	    	}
	        });
		btnCRNew.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {	
	    		

	    		/*try {
	    			//NewVMedicine nvm = new NewVMedicine(clone);
	    			nvm.setVisible(true);
	    			dispose();
	    		} catch (ClassNotFoundException e1) {
	    			// TODO Auto-generated catch block
	    			e1.printStackTrace();
	    		}*/
	    		//JOptionPane.showMessageDialog(null, "新增成功！", "新增藥品品項", JOptionPane.DEFAULT_OPTION );
	    		
	            int c=0;
	            int z=1;

	    			for(int j = 0;j< 13;j++){
	    				if(c==13){
	    					break;
	    				}
	    	            GridBagConstraints strr = new GridBagConstraints();
	    	            strr.gridx = z;
	    	            strr.gridy = j;
	    	            strr.gridwidth = 1;
	    	            strr.gridheight = 1;
	    	            strr.weightx = 10;
	    	            strr.weighty = 10;
	    	            System.out.println(c);
	    	        	innew = infield[c].getText();
	    	        	inNew[c] = innew;
	    	            //strr.fill = GridBagConstraints.BOTH;
	    	            //strr.anchor = GridBagConstraints.NORTHWEST;
	    	            //panel_1.add(field, strr);	    	            
	    	            c++;			
	    			}
	    		
	    	      Connection conn = null;  
	    	  	  Statement statement;
	    	  	  ResultSet rs;
	    	  	  ResultSetMetaData rsMetaData;
	    	  	  String k="";
	    	  	  
	    	  	  if(inNew[0].equals(onlymednum)){
  		    	    int result=JOptionPane.showConfirmDialog(null,
		    	               "資料重複！",
		    	               "新增缺藥紀錄",
		    	               JOptionPane.DEFAULT_OPTION,
		    	               JOptionPane.PLAIN_MESSAGE);
		    	    if (result==0) {
			    		Hidding.setVisible(true);
		    			dispose();
		    	    }	    	  		  
	    	  	  }else{
		    	  	  try{
		    	  	         Class.forName("org.mariadb.jdbc.Driver");
		    	  	         System.out.println("資料庫連結成功");
		    	             conn = DriverManager.getConnection("jdbc:mariadb://lots.im.nuu.edu.tw/MIMSystem", "MIMSystem", "MIMSystem");
		    	             System.out.println("連接成功MySQL");
		    	             statement = conn.createStatement();

		    		         statement.executeUpdate("INSERT INTO `ReLackMedicineRecord`(`得知日期`, `藥品唯一碼`, `缺停藥類型`, `訊息來源`, `公告來函日期`, `回收批號`, `缺停藥狀況說明`, `替代藥藥品唯一碼`, `替代藥類型`, `備註`, `恢復供貨日期`,`缺藥公文檔名`,`缺藥公文路徑`) VALUES ('"+inNew[0]+"','"+inNew[1]+"','"+inNew[2]+"','"+inNew[3]+"','"+inNew[4]+"','"+inNew[5]+"','"+inNew[6]+"','"+inNew[7]+"','"+inNew[8]+"','"+inNew[9]+"','"+inNew[10]+"','"+inNew[11]+"','"+inNew[12]+"')");
		    		         System.out.println(inNew[12]);
		    	  		  	  statement.close();
		    	  		      conn.close();
		    	  		      
		    		    	    int result=JOptionPane.showConfirmDialog(null,
		    		    	               "新增成功！",
		    		    	               "新增藥品品項",
		    		    	               JOptionPane.DEFAULT_OPTION,
		    		    	               JOptionPane.PLAIN_MESSAGE);
		    		    	    if (result==0) {
						    		Index ID;
									ID = new Index();
									ID.setVisible(true);
									dispose();
		    		    	    }

		    	  	         
		    	  	      }catch(ClassNotFoundException classNotFound){//找不到JDBC Driver
		    	  	        
			    	    	    int result=JOptionPane.showConfirmDialog(null,
					    	               "新增失敗！",
					    	               "新增缺藥紀錄",
					    	               JOptionPane.DEFAULT_OPTION,
					    	               JOptionPane.PLAIN_MESSAGE);
					    	    if (result==0) {
						    		Hidding.setVisible(true);
					    			dispose();
					    	    }
					    	    classNotFound.printStackTrace();
		    	  	       }catch(SQLException sqlException){//資料庫操作發生錯誤
		    	  	    	   
		    		    	    int result=JOptionPane.showConfirmDialog(null,
		 		    	               "資料重複！",
		 		    	               "新增缺藥紀錄",
		 		    	               JOptionPane.DEFAULT_OPTION,
		 		    	               JOptionPane.PLAIN_MESSAGE);
		    		    	    if (result==0) {
		    		    	    	Hidding.setVisible(true);
		    		    	    	dispose();
		    		    	    }
		    	  	    	  	sqlException.printStackTrace();
		    	  	      }
	    	  	  }
	    	  	  
                   
  
	    	  	  	  
	    		
	    		

	    	}
	        });
	}

}
