﻿import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class NewVMedicine extends JFrame {
	private String[] str =  {"藥品唯一碼","案號項次","決標分項","標案狀況","履約起日","履約迄日","管制藥等級","成癮性麻醉藥品","藥品或藥材","成份","規格",
			"規格單位","劑型","健保核價單位","包裝","缺停藥類型","替代藥類型","藥品代碼","缺停藥狀況說明","商品名","健保碼","健保價","預算單價","投標價","決標折讓X%","決標折讓Y%",
			"決標折讓Y%備註","決標淨額","廠商","廠牌","何時通過新藥","何時刪除及倂項或分項列標","ATCcode","藥理分類","藥品適應症","藥理作用備註","備註","兒科水劑","用藥指導單張編碼","藥品許可證字號"};
	private JPanel contentPane;
	private JTable vTableMedicine;
	private DefaultTableModel model;
	private JTextField infield[] = new JTextField[40];
	private String innew;
	private String [] inNew = new String[40];

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewVMedicine frame = new NewVMedicine(null,null,null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public NewVMedicine(NewAMedicine NAM,final String[] newdata,String mednum) throws ClassNotFoundException {
		final NewVMedicine clone = this;
		final NewAMedicine Hidding = NAM;

		setTitle("新增藥品品項");
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 900, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		String [] newmd = newdata;
		String onlymednum = mednum;
		
		JLabel pic1 = new JLabel("");
		java.net.URL img = Index.class.getResource("image/MIM.png");
		pic1.setIcon(new ImageIcon(img));
		pic1.setHorizontalAlignment(SwingConstants.RIGHT);
		contentPane.add(pic1, BorderLayout.NORTH);
		
		JPanel panel_1 = new JPanel();
		panel_1.setPreferredSize(new Dimension(1200,700));
		JScrollPane scrollPane = new JScrollPane(panel_1);
		contentPane.add(scrollPane, BorderLayout.CENTER);
        panel_1.setAutoscrolls(true);
        GridBagLayout gbl_panel_1 = new GridBagLayout();
        gbl_panel_1.columnWidths = new int[]{0, 0};
        gbl_panel_1.rowHeights = new int[]{0, 0, 0};
        gbl_panel_1.columnWeights = new double[]{0.0, Double.MIN_VALUE};
        gbl_panel_1.rowWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
        panel_1.setLayout(gbl_panel_1);
        
        scrollPane.setPreferredSize(new Dimension(900,600));
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        contentPane.add(scrollPane,BorderLayout.CENTER);
	  
        int a=0;        
		for(int i = 0;i < 3;i+=2){
			for(int j = 0;j< 21;j++){
				if(a==40){
					break;
				}
	        	JLabel field = new JLabel(str[a]);
	        	field.setFont(new Font("標楷體", Font.PLAIN, 15));
	            GridBagConstraints strr = new GridBagConstraints();
	            strr.gridx = i;
	            strr.gridy = j;
	            strr.gridwidth = 1;
	            strr.gridheight = 1;
	            strr.weightx = 0;
	            strr.weighty = 0;
	            strr.fill = GridBagConstraints.BOTH;
	            strr.anchor = GridBagConstraints.NORTHWEST;
	            panel_1.add(field, strr);
	            
	            a++;			
			}			
		}
		
        int b=0;       
		for(int i = 1;i < 4;i+=2){
			for(int j = 0;j< 21;j++){
				if(b==40){
					break;
				}
	        	infield[b] = new JTextField(newmd[b]);
	        	infield[b].setFont(new Font("標楷體", Font.PLAIN, 15));
	        	infield[b].setEditable(false);
	            GridBagConstraints strr = new GridBagConstraints();
	            strr.gridx = i;
	            strr.gridy = j;
	            strr.gridwidth = 1;
	            strr.gridheight = 1;
	            strr.weightx = 10;
	            strr.weighty = 10;
	            strr.fill = GridBagConstraints.BOTH;
	            strr.anchor = GridBagConstraints.NORTHWEST;
	            panel_1.add(infield[b], strr);
	            
	            b++;			
			}			
		}

		
		

		
		
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);
		
		JButton btnBKNew = new JButton("返回新增");
		btnBKNew.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(btnBKNew);
		
		JButton btnCRNew = new JButton("確認新增");
		btnCRNew.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(btnCRNew);
		
		btnBKNew.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {	
	    		
	    		/*try {
	    			SearchMResult smr = new SearchMResult(clone,selectGroup,selectMedicament,selectCondition,cansearch);
	    		} catch (ClassNotFoundException e1) {
	    			// TODO Auto-generated catch block
	    			e1.printStackTrace();
	    		}*/

	    		Hidding.setVisible(true);
	    			dispose();


	    	}
	        });
		btnCRNew.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {	
	    		

	    		/*try {
	    			//NewVMedicine nvm = new NewVMedicine(clone);
	    			nvm.setVisible(true);
	    			dispose();
	    		} catch (ClassNotFoundException e1) {
	    			// TODO Auto-generated catch block
	    			e1.printStackTrace();
	    		}*/
	    		//JOptionPane.showMessageDialog(null, "新增成功！", "新增藥品品項", JOptionPane.DEFAULT_OPTION );
	    		
	            int c=0;       
	    		for(int i = 1;i < 4;i+=2){
	    			for(int j = 0;j< 21;j++){
	    				if(c==40){
	    					break;
	    				}
	    	            GridBagConstraints strr = new GridBagConstraints();
	    	            strr.gridx = i;
	    	            strr.gridy = j;
	    	            strr.gridwidth = 1;
	    	            strr.gridheight = 1;
	    	            strr.weightx = 10;
	    	            strr.weighty = 10;
	    	            System.out.println(c);
	    	        	innew = infield[c].getText();
	    	        	inNew[c] = innew;
	    	            //strr.fill = GridBagConstraints.BOTH;
	    	            //strr.anchor = GridBagConstraints.NORTHWEST;
	    	            //panel_1.add(field, strr);	    	            
	    	            c++;			
	    			}			
	    		}
	    		
	    	      Connection conn = null;  
	    	  	  Statement statement;
	    	  	  ResultSet rs;
	    	  	  ResultSetMetaData rsMetaData;
	    	  	  String k="";
	    	  	  
	    	  	  if(inNew[0].equals(onlymednum)){
  		    	    int result=JOptionPane.showConfirmDialog(null,
		    	               "資料重複！",
		    	               "新增藥品品項",
		    	               JOptionPane.DEFAULT_OPTION,
		    	               JOptionPane.PLAIN_MESSAGE);
		    	    if (result==0) {
			    		Hidding.setVisible(true);
		    			dispose();
		    	    }	    	  		  
	    	  	  }else{
		    	  	  try{
		    	  	         Class.forName("org.mariadb.jdbc.Driver");
		    	  	         System.out.println("資料庫連結成功");
		    	             conn = DriverManager.getConnection("jdbc:mariadb://lots.im.nuu.edu.tw/MIMSystem", "MIMSystem", "MIMSystem");
		    	             System.out.println("連接成功MySQL");
		    	             statement = conn.createStatement();
		    		         statement.executeUpdate("INSERT INTO `Medicine`(`藥品唯一碼`, `成份`, `規格`, `規格單位`, `劑型`, `健保核價單位`, `包裝`, `藥品代碼`, `商品名`, `管制藥等級`, `成癮性麻醉藥品`, `藥品或藥材`, `ATCcode`, `藥理分類`, `藥品適應症`, `藥理作用備註`, `備註`, `兒科水劑`, `用藥指導單張編碼`, `廠牌`, `藥品許可證字號`) VALUES ('"+inNew[0]+"','"+inNew[9]+"','"+inNew[10]+"','"+inNew[11]+"','"+inNew[12]+"','"+inNew[13]+"','"+inNew[14]+"','"+inNew[17]+"','"+inNew[19]+"','"+inNew[6]+"','"+inNew[7]+"','"+inNew[8]+"','"+inNew[32]+"','"+inNew[33]+"','"+inNew[34]+"','"+inNew[35]+"','"+inNew[36]+"','"+inNew[37]+"','"+inNew[38]+"','"+inNew[30]+"','"+inNew[39]+"')");

		    	  		  	  statement.close();
		    	  		      conn.close();
		    	  		      
		    		    	    int result=JOptionPane.showConfirmDialog(null,
		    		    	               "新增成功！",
		    		    	               "新增藥品品項",
		    		    	               JOptionPane.DEFAULT_OPTION,
		    		    	               JOptionPane.PLAIN_MESSAGE);
		    		    	    if (result==0) {
						    		Index ID;
									ID = new Index();
									ID.setVisible(true);
									dispose();
		    		    	    }

		    	  	         
		    	  	      }catch(ClassNotFoundException classNotFound){//找不到JDBC Driver
		    	  	        
			    	    	    int result=JOptionPane.showConfirmDialog(null,
					    	               "新增失敗！",
					    	               "新增藥品品項",
					    	               JOptionPane.DEFAULT_OPTION,
					    	               JOptionPane.PLAIN_MESSAGE);
					    	    if (result==0) {
						    		Hidding.setVisible(true);
					    			dispose();
					    	    }
					    	    classNotFound.printStackTrace();
		    	  	       }catch(SQLException sqlException){//資料庫操作發生錯誤
		    	  	    	   
		    		    	    int result=JOptionPane.showConfirmDialog(null,
		 		    	               "資料重複！",
		 		    	               "新增藥品品項",
		 		    	               JOptionPane.DEFAULT_OPTION,
		 		    	               JOptionPane.PLAIN_MESSAGE);
		    		    	    if (result==0) {
		    		    	    	Hidding.setVisible(true);
		    		    	    	dispose();
		    		    	    }
		    	  	    	  	sqlException.printStackTrace();
		    	  	      }
	    	  	  }
	    	  	  
                   
  
	    	  	  	  
	    		
	    		

	    	}
	        });
	}

}
