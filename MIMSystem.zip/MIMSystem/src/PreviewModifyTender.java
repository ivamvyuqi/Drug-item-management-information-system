﻿import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFDataFormat;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.util.List;
import java.util.ArrayList;



public class PreviewModifyTender extends JFrame {

	private JPanel contentPane;
	private Object[][] arr;
	Connection conn = null;  
  	Statement statement;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PreviewModifyTender frame = new PreviewModifyTender(null,null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PreviewModifyTender(ModifyTender MT,final String[] md) {
		final ModifyTender Hidding=MT;
		final PreviewModifyTender clone = this;
		
		String [] columnNames={"流水號","案號項次","成分規格含量","標註用藥品或藥材","廠牌或同等品","品質需求","招標藥品單位","招標藥品包裝","預算單價","預估用量","預估總價","履約起日","	履約迄日","標案狀況","後續擴充期限","	後續擴充模式	","後續擴充金額","後擴契約起日","	後擴契約迄日",	"標購方式","	歷次廠商報價	","歷次廠商投標價","	強制結案","	中文案名	","總務室承辦人","案號","管理費模式"};
		String [] dataT = md;
		setTitle("\u4FEE\u6539\u62DB\u6A19\u54C1\u9805\u8868\u9810\u89BD\u9801");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 654);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		/*JLabel pic = new JLabel("");  //圖片
		pic.setBounds(928, 10, 46, 15);
		pic.setIcon(new ImageIcon("C:\\Users\\user\\workspace\\MIMSystem\\src\\MIM.png"));
		pic.setHorizontalAlignment(SwingConstants.RIGHT);
		contentPane.add(pic, BorderLayout.NORTH);*/
		
		JLabel label = new JLabel("流水號 :"+dataT[0]);
		label.setFont(new Font("標楷體", Font.PLAIN, 18));
		label.setBounds(10, 23, 218, 27);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("案號項次 :"+dataT[5]);
		label_1.setFont(new Font("標楷體", Font.PLAIN, 16));
		label_1.setBounds(238, 25, 223, 27);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("成份規格含量:"+dataT[6]);
		label_2.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_2.setBounds(10, 107, 371, 27);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("標註用藥品或藥材:"+dataT[7]);
		label_3.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_3.setBounds(10, 144, 451, 27);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("廠牌或同等品:"+dataT[8]);
		label_4.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_4.setBounds(489, 144, 371, 27);
		contentPane.add(label_4);
		
		JLabel label_5 = new JLabel("品質需求:"+dataT[9]);
		label_5.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_5.setBounds(10, 181, 451, 27);
		contentPane.add(label_5);
		
		JLabel label_6 = new JLabel("招標藥品單位:"+dataT[10]);
		label_6.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_6.setBounds(489, 181, 371, 27);
		contentPane.add(label_6);
		
		JLabel label_7 = new JLabel("招標藥品包裝:"+dataT[11]);
		label_7.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_7.setBounds(10, 218, 451, 27);
		contentPane.add(label_7);
		
		JLabel label_8 = new JLabel("預算單價:"+dataT[12]);
		label_8.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_8.setBounds(489, 218, 371, 27);
		contentPane.add(label_8);
		
		JLabel label_9 = new JLabel("預估用量:"+dataT[13]);
		label_9.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_9.setBounds(10, 255, 451, 27);
		contentPane.add(label_9);
		
		JLabel label_10 = new JLabel("預估總價:"+dataT[14]);
		label_10.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_10.setBounds(489, 255, 371, 27);
		contentPane.add(label_10);
		
		JLabel label_11 = new JLabel("履約起日:"+dataT[15]);
		label_11.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_11.setBounds(10, 292, 451, 27);
		contentPane.add(label_11);
		
		JLabel label_12 = new JLabel("履約迄日:"+dataT[16]);
		label_12.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_12.setBounds(489, 292, 371, 27);
		contentPane.add(label_12);
		
		JLabel label_13 = new JLabel("標案狀況:"+dataT[18]);
		label_13.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_13.setBounds(489, 329, 451, 27);
		contentPane.add(label_13);
		
		JLabel label_14 = new JLabel("後續擴充期限:"+dataT[19]);
		label_14.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_14.setBounds(489, 366, 371, 27);
		contentPane.add(label_14);
		
		JLabel label_15 = new JLabel("後續擴充模式:"+dataT[20]);
		label_15.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_15.setBounds(10, 366, 451, 27);
		contentPane.add(label_15);
		
		JLabel label_16 = new JLabel("後續擴充金額:"+dataT[21]);
		label_16.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_16.setBounds(489, 403, 371, 27);
		contentPane.add(label_16);
		
		JLabel label_17 = new JLabel("後擴契約起日:"+dataT[22]);
		label_17.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_17.setBounds(10, 403, 451, 27);
		contentPane.add(label_17);
		
		JLabel label_18 = new JLabel("後擴契約迄日:"+dataT[23]);
		label_18.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_18.setBounds(489, 440, 371, 27);
		contentPane.add(label_18);
		
		JLabel label_19 = new JLabel("標購方式:"+dataT[24]);
		label_19.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_19.setBounds(10, 440, 451, 27);
		contentPane.add(label_19);
		
		JLabel label_20 = new JLabel("歷次廠商報價:"+dataT[25]);
		label_20.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_20.setBounds(489, 477, 371, 27);
		contentPane.add(label_20);
		
		JLabel label_21 = new JLabel("歷次廠商投標價:"+dataT[26]);
		label_21.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_21.setBounds(10, 477, 451, 27);
		contentPane.add(label_21);
		
		JLabel label_22 = new JLabel("強制結案:"+dataT[27]);
		label_22.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_22.setBounds(489, 514, 371, 27);
		contentPane.add(label_22);
		
		JButton return_btn = new JButton("返回上一頁");
		return_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Hidding.setVisible(true);
				dispose();
			}
		});
		return_btn.setFont(new Font("標楷體", Font.PLAIN, 15));
		return_btn.setBounds(328, 571, 114, 34);
		contentPane.add(return_btn);
		
		final String date =getDateTime();
		String chinNam=dataT[1];
		String charPerS=dataT[2];
		
		
		

		JButton modifybtn = new JButton("確定修改");
		modifybtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Statement statement;
				int isUpdate = 0;
				int isUpdate1 = 0;
				int empty = 0;
				final String TNum = "";// 測試 因為產生新約還不確定案號跟管理費模式
				final String FeeType = "";// 測試
				try {
					Class.forName("org.mariadb.jdbc.Driver");
		 	        System.out.println("資料庫連結成功");
		            conn = DriverManager.getConnection("jdbc:mariadb://lots.im.nuu.edu.tw/MIMSystem", "MIMSystem", "MIMSystem");
		            System.out.println("連接成功MySQL");
		            statement = conn.createStatement();

					try {
						// 修改資料到資料庫
						isUpdate = statement.executeUpdate("Update TenderDetail SET 成份規格含量='"+dataT[26]+"',標註用藥品或藥材='"+dataT[7]+"',廠牌或同等品='"+dataT[8]+"',"
								+ "品質需求='"+dataT[9]+"',招標藥品單位='"+dataT[10]+"',招標藥品包裝='"+dataT[11]+"',預算單價='"+dataT[12]+"',"
								+ "預估用量='"+dataT[13]+"',預估總價='"+dataT[14]+"',履約起日='"+dataT[15]+"',履約迄日='"+dataT[16]+"',履約期限='"+dataT[17]+"',"
								+ "標案狀況='"+dataT[18]+"',後續擴充期限='"+dataT[19]+"',後續擴充模式='"+dataT[20]+"',後續擴充金額='"+dataT[21]+"',"
								+ "後擴契約起日='"+dataT[22]+"',後擴契約迄日='"+dataT[23]+"',標購方式='"+dataT[24]+"',歷次廠商報價='"+dataT[25]+"',"
								+ "歷次廠商投標價='"+dataT[26]+"',強制結案='"+dataT[27]+"' WHERE 流水號 ='"+dataT[0]+"' ");

						isUpdate1 = statement.executeUpdate("Update Tender SET 中文案名='"+dataT[1]+"',總務室承辦人='"+dataT[2]+"',案號='"+dataT[3]+"',管理費模式='"+dataT[4]+"' WHERE 流水號 ='"+dataT[0]+"' ");
						// 新增表格資料到資料庫
					/*	for (int i = 0; i < table.getRowCount(); i++) {

							isUpdate = statement.executeUpdate(
									"INSERT into TenderDetail(流水號, 案號項次, 成份規格含量, 廠牌或同等品, 品質需求, 招標藥品單位, 招標藥品包裝, 預算單價, 預估用量, 預估總價, 標案狀況)VALUES('"
											+ dateTime + "','" + table.getValueAt(i, 0) + "','" + table.getValueAt(i, 1)
											+ "','" + table.getValueAt(i, 2) + "','" + table.getValueAt(i, 3) + "' ,'"
											+ table.getValueAt(i, 4) + "','" + table.getValueAt(i, 5) + "','"
											+ table.getValueAt(i, 6) + "','" + table.getValueAt(i, 7) + "','"
											+ table.getValueAt(i, 8) + "','" + table.getValueAt(i, 9) + "' )");
							// System.out.println(table.getValueAt(i, j));
						}*/
						
						

						// Creat Excel檔案
						// 創建工作簿
						XSSFWorkbook wb = new XSSFWorkbook();
						// 創建工作表
						XSSFSheet sheet = wb.createSheet(date + "招標品項表");
						for (int i = 0; i < 3; i++) {
							// 設置列寬
							sheet.setColumnWidth(i, 3000);
						}
						// 創建行
						XSSFRow row = sheet.createRow(0);
						row.setHeightInPoints(30);// 設置行高
						// 創建單元格
						XSSFCell cell = row.createCell(0);
						cell.setCellValue(chinNam);
						// 合併單元格
						sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 9));
						// 創建行
						XSSFRow row1 = sheet.createRow(1);

						// 標題信息
						String[] titles = { "案號項次", "成份規格含量", "廠牌或同等品", "品質需求", "招標藥品單位", "招標藥品包裝", "預算單價", "預估用量",
								"預估總價", "標案狀況" };
						for (int i = 0; i < titles.length; i++) {
							// 創建單元格
							XSSFCell cell1 = row1.createCell(i);
							cell1.setCellValue(titles[i]);
						}
						// 模擬數據，實際情況下String[]多為實體bean
						//Object[][] arr;

						//試看看宣告在這
						int data = dataT.length/27;
					
						arr = new Object[data][27];

						List<String[]> list = new ArrayList<String[]>();
						
						//順便看一下dataT.length
						System.out.println(dataT.length);
						
						
						//這寫法會出錯 
						/*for(int i=0;i<27;i++){
							for(int j=0;j<dataT.length;j++){
								arr[i][j]=dataT[j];
							}
						}*/

						//這應該才正確
						for(int i=0;i<data;i++){
							for(int j=0;j<27;j++){
								arr[i][j] = dataT[i*27+j];
								System.out.println("arr["+i+"]["+j+"]="+arr[i][j]);
							}
						}

						System.out.println("arr.length:"+arr[0].length);
						for (int i = 0; i < arr.length; i++) {
							String[] d = new String[arr[0].length];
							for (int j = 0; j < d.length; j++) {
								if(arr[i][j]==null)d[j]=null;//有值是null不能.toString()
								else d[j] = arr[i][j].toString();// 把Object變成一個個string放入data,然後再把data放進list
								//System.out.println("我是i:"+i+"我是j:"+d[j]);
								//System.out.println("我是i:"+i+"我是j="+j+" "+arr[i][j].toString());
							}
							list.add(d);
						}

						// 保留2位小數
						XSSFCellStyle cellStyle = wb.createCellStyle();
						XSSFDataFormat format = wb.createDataFormat();
						cellStyle.setDataFormat(format.getFormat("0.00"));

						// 循環賦值 把欄位資料放入每一行
						for (int i = 0; i < list.size(); i++) {
							// 創建行
							XSSFRow row2 = sheet.createRow(i + 2);
							// 創建單元格
							XSSFCell cell1 = row2.createCell(0);
							cell1.setCellValue(list.get(i)[0]);
							// 創建單元格
							XSSFCell cell2 = row2.createCell(1);
							cell2.setCellValue(list.get(i)[1]);
							// 創建單元格
							XSSFCell cell3 = row2.createCell(2);
							cell3.setCellValue(list.get(i)[2]);
							// 創建單元格
							XSSFCell cell4 = row2.createCell(3);
							cell4.setCellValue(list.get(i)[3]);
							// 創建單元格
							XSSFCell cell5 = row2.createCell(4);
							cell5.setCellValue(list.get(i)[4]);
							// 創建單元格
							XSSFCell cell6 = row2.createCell(5);
							cell6.setCellValue(list.get(i)[5]);
							XSSFCell cell7 = row2.createCell(6);
							cell7.setCellValue(list.get(i)[6]);
							XSSFCell cell8 = row2.createCell(7);
							cell8.setCellValue(list.get(i)[7]);
							XSSFCell cell9 = row2.createCell(8);
							cell9.setCellValue(list.get(i)[8]);
							XSSFCell cell10 = row2.createCell(9);
							cell10.setCellValue(list.get(i)[9]);
						}

						// 計算公式
						wb.getCreationHelper().createFormulaEvaluator().evaluateAll();
						// String name="KavenLoveBetty";
						File file = new File("C:/Users/d4/Desktop/" + date + " test.xls");
						try {
							if (!file.exists()) {
								file.createNewFile();
							}

							FileOutputStream fileOut = new FileOutputStream(file);
							wb.write(fileOut);
							fileOut.close();
						} catch (IOException IO) {
							System.out.println(IO);
						}

						System.out.println("Success");
					} catch (SQLException sqlException) {
						sqlException.printStackTrace();
					}
					if (isUpdate > 0 && isUpdate1 > 0) {
						System.out.println("noUpdate: " + isUpdate +" "+isUpdate1);
						/*
						 * JOptionPane.showMessageDialog(null, "產生新約成功 !",
						 * "新增成功", JOptionPane.INFORMATION_MESSAGE); dispose();
						 */
						int mType = JOptionPane.QUESTION_MESSAGE;
						int oType = JOptionPane.YES_NO_CANCEL_OPTION;
						String[] options = { "需要", "不需要，結束此功能" };
						int opt = JOptionPane.showOptionDialog(null, "需要產生部分欄位檔案嗎?", "請選擇", oType, mType, null, options,
								"接受");
						if (opt == JOptionPane.YES_OPTION) {
							try {
								
								chooseOutputData choose = new chooseOutputData(chinNam, charPerS, date, columnNames,arr);
								System.out.println("成功囉");
								choose.setVisible(true);
								dispose();
							} catch (NumberFormatException n) {
								JOptionPane.showMessageDialog(null, "輸入錯誤", "警告", JOptionPane.WARNING_MESSAGE);
								n.printStackTrace();

							}

						}
						if (opt == JOptionPane.NO_OPTION) {
							// JOptionPane.showMessageDialog(null,"您選擇的是 :
							// 產生部分欄位檔案 " + opt);
				    		Index ID;
							ID = new Index();
							ID.setVisible(true);
							dispose();

						}
					} else {

						JOptionPane.showMessageDialog(null, "產生新約失敗 !", "修改失敗", JOptionPane.WARNING_MESSAGE);
						int result = JOptionPane.showConfirmDialog(null, "確定要結束程式嗎?", "確認訊息", JOptionPane.YES_NO_OPTION,
								JOptionPane.WARNING_MESSAGE);
						if (result == JOptionPane.YES_OPTION) {
							System.exit(0);
						}
					}
				} catch (SQLException SQLe) {
					SQLe.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		modifybtn.setFont(new Font("標楷體", Font.PLAIN, 15));
		modifybtn.setBounds(452, 571, 114, 34);
		contentPane.add(modifybtn);
		
		JLabel label_23 = new JLabel("總務室承辦人:"+dataT[2]);
		label_23.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_23.setBounds(10, 70, 432, 27);
		contentPane.add(label_23);
		
		JLabel label_24 = new JLabel("中文案名:"+dataT[1]);
		label_24.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_24.setBounds(489, 70, 371, 27);
		contentPane.add(label_24);
		
		JLabel label_25 = new JLabel("案號:"+dataT[3]);
		label_25.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_25.setBounds(489, 107, 365, 27);
		contentPane.add(label_25);
		
		JLabel label_26 = new JLabel("管理費模式:"+dataT[4]);
		label_26.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_26.setBounds(10, 514, 371, 27);
		contentPane.add(label_26);
		
		JLabel label_27 = new JLabel("履約期限："+dataT[17]);
		label_27.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_27.setBounds(10, 329, 451, 27);
		contentPane.add(label_27);
		
	}
	public String getDateTime(){
		SimpleDateFormat sdFormat = new SimpleDateFormat("yyyyMMdd");
		Date date = new Date();
		String strDate = sdFormat.format(date);
		return strDate;
	}

}
