﻿import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class PreviewNewFirm extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PreviewNewFirm frame = new PreviewNewFirm(null,"","","","","","","","","","","");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PreviewNewFirm(NewFirm NF,final String firmname,final String firmphone,final String firmfax,final String EIN,final String personname,final String personphone,final String personemail,final String number1,final String star1,final String end1,final String firmremark) {
		setTitle("\u65B0\u589E\u5EE0\u5546\u9810\u89BD\u9801");
		final NewFirm Hidding = NF;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 831, 275);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		/*JLabel lblNewLabel = new JLabel("");
		java.net.URL img = Index.class.getResource("image/MIM.png");
		lblNewLabel.setIcon(new ImageIcon(img));
		lblNewLabel.setBounds(655, 0, 160, 132);
		contentPane.add(lblNewLabel);*/
		
		JLabel prefirmname = new JLabel("\u5EE0\u5546\u540D\u7A31\uFF1A"+firmname);
		prefirmname.setBounds(10, 39, 377, 18);
		contentPane.add(prefirmname);
		prefirmname.setFont(new Font("標楷體", Font.PLAIN, 14));
		/*String str="\u5EE0\u5546\u540D\u7A31\uFF1A"+firmname; //Ū��label�r��
		String[] strfirmname=str.split("�G");
		for(int i=1;i<strfirmname.length;i++){
			System.out.println(strfirmname[i]);
		}*/
		  
		
		JLabel prefirmfax = new JLabel("\u5EE0\u5546\u50B3\u771F\uFF1A"+firmfax);
		prefirmfax.setFont(new Font("標楷體", Font.PLAIN, 14));
		prefirmfax.setBounds(10, 67, 377, 18);
		contentPane.add(prefirmfax);
		//prefirmfax.setFont(new Font("�s�ө���", Font.PLAIN, 14));
		
		JLabel prepersonname = new JLabel("\u806F\u7D61\u4EBA\u540D\u7A31\uFF1A"+personname);
		prepersonname.setFont(new Font("標楷體", Font.PLAIN, 14));
		prepersonname.setBounds(10, 100, 377, 18);
		contentPane.add(prepersonname);
		//prepersonname.setFont(new Font("�s�ө���", Font.PLAIN, 14));
		
		JLabel prepersonmail = new JLabel("\u806F\u7D61\u4EBA\u4FE1\u7BB1\uFF1A"+personemail);
		prepersonmail.setFont(new Font("標楷體", Font.PLAIN, 14));
		prepersonmail.setBounds(10, 130, 466, 18);
		contentPane.add(prepersonmail);
		//prepersonmail.setFont(new Font("�s�ө���", Font.PLAIN, 14));
		
		JLabel prefirmphone = new JLabel("\u5EE0\u5546\u96FB\u8A71\uFF1A"+firmphone);
		prefirmphone.setFont(new Font("標楷體", Font.PLAIN, 14));
		prefirmphone.setBounds(406, 39, 347, 18);
		contentPane.add(prefirmphone);
		//prefirmphone.setFont(new Font("�s�ө���", Font.PLAIN, 14));
		
		JLabel preEIN = new JLabel("\u7D71\u4E00\u7DE8\u865F\uFF1A"+EIN);
		preEIN.setFont(new Font("標楷體", Font.PLAIN, 14));
		preEIN.setBounds(406, 70, 347, 18);
		contentPane.add(preEIN);
		//preEIN.setFont(new Font("�s�ө���", Font.PLAIN, 14));
		
		JLabel prepersonphone = new JLabel("\u806F\u7D61\u4EBA\u96FB\u8A71\uFF1A"+personphone);
		prepersonphone.setFont(new Font("標楷體", Font.PLAIN, 14));
		prepersonphone.setBounds(392, 103, 361, 18);
		contentPane.add(prepersonphone);
		//prepersonphone.setFont(new Font("�s�ө���", Font.PLAIN, 14));
		
		JLabel prenumber1 = new JLabel("\u7BA1\u8B49\u767B\u8A18\u8B49\u5B57\u865F\uFF1A"+number1);
		prenumber1.setFont(new Font("標楷體", Font.PLAIN, 14));
		prenumber1.setBounds(10, 168, 298, 18);
		contentPane.add(prenumber1);
		
		
		JLabel prestar1 = new JLabel("\u751F\u6548\u8D77\u59CB\u65E5\uFF1A"+star1);
		prestar1.setFont(new Font("標楷體", Font.PLAIN, 14));
		prestar1.setBounds(318, 168, 263, 18);
		contentPane.add(prestar1);
		
		
		JLabel preend1 = new JLabel("\u751F\u6548\u7D42\u6B62\u65E5\uFF1A"+end1);
		preend1.setFont(new Font("標楷體", Font.PLAIN, 14));
		preend1.setBounds(591, 168, 206, 18);
		contentPane.add(preend1);
		
		//String firmname2,EIN2;
		JButton sureadd = new JButton("\u78BA\u5B9A\u65B0\u589E");
		sureadd.setFont(new Font("標楷體", Font.PLAIN, 14));
		sureadd.setBounds(683, 207, 122, 27);
		contentPane.add(sureadd);
		sureadd.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				Connection conn;
				Statement statement;
				int Update=0;
				int Update2=0;
				try{
					Class.forName("org.mariadb.jdbc.Driver");
					System.out.println("資料庫連結成功");
					try{
						conn=DriverManager.getConnection("jdbc:mariadb://lots.im.nuu.edu.tw/MIMSystem", "MIMSystem", "MIMSystem");
						System.out.println("連接成功MySQL");
						statement=conn.createStatement();
						
						try{
							if (checkFirm(firmname,EIN)!=1){
								Update=statement.executeUpdate("Insert Into FirmData(廠商統一編號,廠商名稱,電話,傳真,聯絡人,聯絡人電話,聯絡信箱,廠商備註)VALUES('"+EIN+"','"+firmname+"','"+firmphone+"','"+firmfax+"','"+personname+"','"+personphone+"','"+personemail+"','"+firmremark+"')");
								Update2=statement.executeUpdate("Insert Into Certificate(管證登記證字號,管證登記證生效起始日,管證登記證生效終止日,廠商統一編號)VALUES('"+number1+"','"+star1+"','"+end1+"','"+EIN+"')");
								if(Update>0&&Update2>0){
									int result = JOptionPane.showConfirmDialog(null,"新增廠商資料成功","新增成功",JOptionPane.INFORMATION_MESSAGE);
			    		    	    if (result==0) {
							    		Index ID;
										ID = new Index();
										ID.setVisible(true);
										dispose();
			    		    	    }
								}else{
									JOptionPane.showMessageDialog(null,"新增廠商資料失敗","新增失敗",JOptionPane.WARNING_MESSAGE);
									int result=JOptionPane.showConfirmDialog(null,"確定要結束程式嗎?","確認訊息",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
									if(result==JOptionPane.YES_OPTION){System.exit(0);}
								}
							}else{
								JOptionPane.showMessageDialog(null,"廠商資料已存在","新增失敗",JOptionPane.WARNING_MESSAGE);
								System.exit(0);
							}
							
						}catch(SQLException sqlException){
							sqlException.printStackTrace();
						}
					}catch(SQLException  SQLe){
						SQLe.printStackTrace();
					}
					
				}catch(ClassNotFoundException SQLe){
					SQLe.printStackTrace();
				}
			}
		});
		
		JButton returnaddfirm = new JButton("\u8FD4\u56DE\u65B0\u589E");
		returnaddfirm.setFont(new Font("標楷體", Font.PLAIN, 14));
		returnaddfirm.setBounds(551, 207, 122, 27);
		contentPane.add(returnaddfirm);
		returnaddfirm.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				Hidding.setVisible(true);
				dispose();
			}
		});
		
		JLabel prefirmremark = new JLabel("廠商備註："+firmremark);
		prefirmremark.setFont(new Font("標楷體", Font.PLAIN, 14));
		prefirmremark.setBounds(10, 208, 377, 18);
		contentPane.add(prefirmremark);
		
	}
	public int checkFirm(final String firmname,final String EIN){
				Connection conn;
				Statement statement;
				ResultSet rs;
				ResultSetMetaData rsMetaData;
				int checkfirm=0;
				String[] check=new String [2];
				check[0]="";
				check[1]="";
				int numberOfColumns;
				try{
					Class.forName("org.mariadb.jdbc.Driver");
					try{
						 conn=DriverManager.getConnection("jdbc:mariadb://lots.im.nuu.edu.tw/MIMSystem", "MIMSystem", "MIMSystem");
						   //System.out.println("�s�����\");
						   statement = conn.createStatement();
						//try{
							   rs = statement.executeQuery("Select 廠商名稱,廠商統一編號 From  FirmData  where 廠商名稱='"+firmname+"' OR 廠商統一編號='"+EIN+"'");
							   rsMetaData = rs.getMetaData();
							   numberOfColumns = rsMetaData.getColumnCount();
							   while (rs.next()){  //������̪����
								   for(int i=1; i<=numberOfColumns; i++)
								   {
									   check[i-1]= rs.getObject(i).toString();
									   System.out.println((i-1)+": "+check[i-1]);  	
									   }
								   }
						//}catch(SQLException sqlException){
						//	sqlException.printStackTrace();
						//}
					}catch(SQLException sqlException){
						sqlException.printStackTrace();
					}
				}catch(ClassNotFoundException SQLe){
					SQLe.printStackTrace();
					}
				if((check[0].equals(firmname))||(check[1].equals(EIN))){
			    	checkfirm=1;
			    }
			   return checkfirm;
			   
			   
	}
}
