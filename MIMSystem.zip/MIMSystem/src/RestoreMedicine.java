﻿import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JFileChooser;

public class RestoreMedicine extends JFrame {

	private JPanel contentPane;
	private JTextField restore;
	private JTextField remark;
	private JTextField file;
	private JTextField path;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RestoreMedicine frame = new RestoreMedicine(null,null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RestoreMedicine(ShowLackMedicine SLM,final String[] data) {
		/*JLabel pic = new JLabel("");  //圖片
		pic.setBounds(944, 10, 46, 15);
		pic.setIcon(new ImageIcon("C:\\Users\\user\\workspace\\MIMSystem\\src\\MIM.png"));
		pic.setHorizontalAlignment(SwingConstants.RIGHT);
		contentPane.add(pic, BorderLayout.NORTH);*/
		
		final ShowLackMedicine Hidding=SLM;
		final RestoreMedicine clone = this;
		String [] mdonly = data;//將上頁傳來的陣列放進此陣列
		
		setTitle("恢復供藥紀錄");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 730, 435);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("得知日期："+data[0]);
		lblNewLabel.setFont(new Font("標楷體", Font.PLAIN, 15));
		lblNewLabel.setBounds(21, 52, 258, 29);
		contentPane.add(lblNewLabel);
		
		JLabel label = new JLabel("藥品唯一碼："+data[1]);
		label.setFont(new Font("標楷體", Font.PLAIN, 15));
		label.setBounds(316, 52, 258, 29);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("缺停藥類型："+data[2]);
		label_1.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_1.setBounds(21, 91, 258, 29);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("訊息來源："+data[3]);
		label_2.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_2.setBounds(316, 91, 258, 29);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("公告/來函日期："+data[4]);
		label_3.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_3.setBounds(21, 130, 258, 29);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("回收批號："+data[5]);
		label_4.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_4.setBounds(316, 130, 258, 29);
		contentPane.add(label_4);
		
		JLabel label_5 = new JLabel("缺停藥狀況說明："+data[6]);
		label_5.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_5.setBounds(21, 169, 258, 29);
		contentPane.add(label_5);
		
		JLabel label_6 = new JLabel("替代藥藥品唯一碼："+data[7]);
		label_6.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_6.setBounds(316, 169, 258, 29);
		contentPane.add(label_6);
		
		JLabel label_7 = new JLabel("替代藥類型："+data[8]);
		label_7.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_7.setBounds(21, 208, 258, 29);
		contentPane.add(label_7);
		
		JLabel label_8 = new JLabel("備註：");
		label_8.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_8.setBounds(21, 286, 52, 29);
		contentPane.add(label_8);
		
		JLabel label_9 = new JLabel("恢復供藥日期：");
		label_9.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_9.setBounds(21, 247, 111, 29);
		contentPane.add(label_9);
		
		JLabel label_10 = new JLabel("恢復供藥公文檔名：");
		label_10.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_10.setBounds(316, 208, 153, 29);
		contentPane.add(label_10);
		
		JLabel label_11 = new JLabel("恢復供藥公文路徑：");
		label_11.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_11.setBounds(316, 281, 135, 29);
		contentPane.add(label_11);
		
		restore = new JTextField();
		restore.setFont(new Font("新細明體", Font.PLAIN, 15));
		restore.setBounds(126, 249, 153, 24);
		contentPane.add(restore);
		restore.setColumns(10);
		
		remark = new JTextField();
		remark.setText(data[9]);
		remark.setFont(new Font("新細明體", Font.PLAIN, 15));
		remark.setColumns(60);
		remark.setBounds(66, 286, 213, 24);
		contentPane.add(remark);
		
		file = new JTextField(data[13]);
		file.setText((String) null);
		file.setFont(new Font("新細明體", Font.PLAIN, 15));
		file.setColumns(60);
		file.setBounds(451, 208, 241, 24);
		contentPane.add(file);
		
		path = new JTextField(data[14]);
		path.setText((String) null);
		path.setFont(new Font("新細明體", Font.PLAIN, 15));
		path.setColumns(60);
		path.setBounds(451, 283, 241, 24);
		contentPane.add(path);
		

		
		JButton button = new JButton("上傳恢復供藥公文");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
	            JFileChooser fileChooser = new JFileChooser();//宣告filechooser 
	            int returnValue = fileChooser.showOpenDialog(null);//叫出filechooser 
	            if (returnValue == JFileChooser.APPROVE_OPTION) //判斷是否選擇檔案 
	            { 
		            File selectedFile = fileChooser.getSelectedFile();//指派給File 
		            System.out.println(selectedFile.getName()); //印出檔名
		            System.out.println(selectedFile.getAbsolutePath());
		            String lpath = selectedFile.getAbsolutePath();
		            String filepath = lpath.replace("\\","\\\\");
        	
		            file.setText(selectedFile.getName());
		            path.setText(filepath);
		            
	            }
				
			}
		});
		
		JButton return_btn = new JButton("返回上一頁");
		return_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Hidding.setVisible(true);
				dispose();
			}
		});
		return_btn.setFont(new Font("標楷體", Font.PLAIN, 15));
		return_btn.setBounds(207, 353, 114, 34);
		contentPane.add(return_btn);
		
		JButton modify_button = new JButton("確定新增恢復供藥");
		modify_button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection conn = null;  
			  	Statement statement;
			  	//ResultSet rs;
			  	//ResultSetMetaData rsMetaData;
			  	int update=0;
				String mark = remark.getText();
				String restore1=restore.getText();
			  	
				String ufile = file.getText();
				String upath = path.getText();
				
			  	try{
			  		Class.forName("org.mariadb.jdbc.Driver");
			         System.out.println("資料庫連結成功");
		           conn = DriverManager.getConnection("jdbc:mariadb://lots.im.nuu.edu.tw/MIMSystem", "MIMSystem", "MIMSystem");
		           System.out.println("連接成功MySQL");

		           statement = conn.createStatement();
			           //rs = statement.executeQuery("SELECT * FROM TenderDetail WHERE "+selectcombobox+" = '"+inputcondition+"'");
			           update = statement.executeUpdate("Update ReLackMedicineRecord SET 得知日期='"+data[0]+"',藥品唯一碼='"+data[1]+"',缺停藥類型='"+data[2]+"',訊息來源='"+data[3]+"',公告來函日期='"+data[4]+"',回收批號='"+data[5]+"',缺停藥狀況說明='"+data[6]+"',替代藥藥品唯一碼='"+data[7]+"',替代藥類型='"+data[8]+"',備註='"+mark+"' ,恢復供貨日期='"+restore1+"',恢復供藥公文檔名	='"+ufile+"',恢復供藥公文路徑='"+upath+"' WHERE 得知日期='"+data[0]+"' AND 藥品唯一碼='"+data[1]+"'");
			           if(update>0){
			        	   JOptionPane.showMessageDialog(null,"新增恢復供藥紀錄成功","新增成功",JOptionPane.INFORMATION_MESSAGE);
				    		Index ID;
							ID = new Index();
							ID.setVisible(true);
							dispose();
			           }else{
							JOptionPane.showMessageDialog(null,"新增恢復供藥紀錄失敗","新增失敗",JOptionPane.WARNING_MESSAGE);
							int result=JOptionPane.showConfirmDialog(null,"確定要結束程式嗎?","確認訊息",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
							if(result==JOptionPane.YES_OPTION){						    		Index ID;
							ID = new Index();
							ID.setVisible(true);
							dispose();}
						}
			           //rsMetaData = rs.getMetaData();
			  	}catch(ClassNotFoundException classNotFound){
			  		classNotFound.printStackTrace();
			  	}catch(SQLException sqlException){//資料庫操作發生錯誤
		  	        sqlException.printStackTrace();
		  	      }
			}
		});
		modify_button.setFont(new Font("標楷體", Font.PLAIN, 15));
		modify_button.setBounds(331, 353, 189, 34);
		contentPane.add(modify_button);
		

		

		button.setFont(new Font("標楷體", Font.PLAIN, 15));
		button.setBounds(451, 242, 179, 29);
		contentPane.add(button);
		

		
		
	}
}
