﻿import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class SearchLackMedicine extends JFrame {
	private String[] LackMedicament= {"得知日期","藥品唯一碼","缺停藥類型","訊息來源","公告來函日期","回收批號","缺停藥狀況說明","替代藥藥品唯一碼","替代藥類型","備註","恢復供貨日期"};

	private JPanel contentPane;
	private JTextField textMedicine;
	static String selectMedicine;
	static String inputMedicine;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SearchLackMedicine frame = new SearchLackMedicine(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SearchLackMedicine(Index index) throws ClassNotFoundException {
		setResizable(false);
		final SearchLackMedicine clone = this;
		final Index Hidding = index;
		setTitle("查詢缺藥歷程");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JLabel pic = new JLabel("");		
		java.net.URL img = Index.class.getResource("image/MIM.png");
		pic.setIcon(new ImageIcon(img));
		pic.setHorizontalAlignment(SwingConstants.RIGHT);
		contentPane.add(pic, BorderLayout.NORTH);
		
		JPanel panel_1 = new JPanel();
		contentPane.add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(null);
		
		JComboBox cbMedicine = new JComboBox(LackMedicament);
		cbMedicine.setFont(new Font("標楷體", Font.PLAIN, 15));
		cbMedicine.setBounds(156, 158, 271, 21);
		panel_1.add(cbMedicine);
		
		textMedicine = new JTextField();
		textMedicine.setBounds(437, 158, 289, 21);
		textMedicine.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel_1.add(textMedicine);
		textMedicine.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("輸入查詢條件：");
		lblNewLabel.setFont(new Font("標楷體", Font.PLAIN, 20));
		lblNewLabel.setBounds(156, 99, 140, 32);
		panel_1.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("查詢缺藥歷程");
		lblNewLabel_1.setFont(new Font("標楷體", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(10, 10, 140, 21);
		panel_1.add(lblNewLabel_1);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);
		
		JButton btnIndex = new JButton("返回主選單");
		btnIndex.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(btnIndex);
		btnIndex.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {	

	    			Hidding.setVisible(true);
	    			dispose();

	    	}
	    });
		
		JButton btnSearch = new JButton("查詢");
		btnSearch.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(btnSearch);
	    btnSearch.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		selectMedicine = cbMedicine.getSelectedItem().toString();
	    		inputMedicine = textMedicine.getText().trim();	

	    		try {
	    			SearchLResult slr = new SearchLResult(clone,selectMedicine,inputMedicine);
	    			slr.setVisible(true);
	    			dispose();
	    		} catch (ClassNotFoundException e1) {
	    			// TODO Auto-generated catch block
	    			e1.printStackTrace();
	    		}

	    	}
	        });
	}
}

