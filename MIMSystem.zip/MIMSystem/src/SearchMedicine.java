﻿import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.ActionEvent;
import java.awt.FlowLayout;
import javax.swing.JTabbedPane;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.JEditorPane;

public class SearchMedicine extends JFrame {

	/*private String[] Medicament= {
			"藥品唯一碼","成份","規格","規格單位","劑型","健保核價單位","包裝","藥品代碼","商品名","管制藥等級","成癮性麻醉藥品","藥品或藥材","ATCcode","藥理分類",
			"藥品適應症","藥理作用備註","備註","兒科水劑","用藥指導單張編碼","廠牌","藥品許可證字號",//Medicine
			"何時通過新藥","何時刪除及倂項或分項列標",//TypeOfPurchase
			"案號項次","決標分項","預算單價","決標折讓X%","決標折讓Y%","決標折讓Y%備註","決標淨額",//TenderResult
			"標案狀況","履約起日","履約迄日","歷次廠商投標價",//TenderDetail
			"缺停藥類型","替代藥類型","缺停藥狀況說明",//ReLackMedicineRecord
			"健保碼","健保價",//Price
			"廠商統一編號","廠商名稱","電話","傳真","聯絡人","聯絡人電話","聯絡信箱","廠商備註",//FirmData
			"管證登記證字號","管證登記證生效起始日","管證登記證生效終止日"//Certificate
			};
	*/
	private String[] Medicament= {
		"-藥品品項-","藥品唯一碼","成份","規格","規格單位","劑型","健保核價單位","包裝","藥品代碼","商品名","管制藥等級","成癮性麻醉藥品","藥品或藥材","ATCcode","藥理分類",
		"藥品適應症","藥理作用備註","備註","兒科水劑","用藥指導單張編碼","廠牌","藥品許可證字號",//Medicine1-21
		"-缺停藥品項-","得知日期","缺停藥類型","訊息來源","回收批號","缺停藥狀況說明","替代藥藥品唯一碼","替代藥類型","備註","恢復供貨日期",//ReLackMedicineRecord23-31
		"-藥品採購類型-","藥品採購類型","藥品採購類型起日","藥品採購類型迄日","何時通過新藥","何時刪除及倂項或分項列標",//TypeOfPurchase33-37
		"-健保價-","上傳日期","健保碼","健保價","生效起日","生效迄日",//Price39-43
		"-招標-","流水號","中文案名","總務室承辦人","案號","管理費模式",//Tender45-49
		"-招標明細-","案號項次","成份規格含量","標註用藥品或藥材","廠牌或同等品","品質需求","招標藥品單位","招標藥品包裝","預算單價","預估用量","預估總價","履約起日","履約迄日","履約期限",
		"標案狀況","後續擴充期限","後續擴充模式","後續擴充金額","後擴契約迄日","後擴契約起日","標購方式","歷次廠商報價","歷次廠商投標價","強制結案",//TenderDetail51-73
		"-招標結果-","決標分項","決標健保碼","決標健保價","決標折讓X%","決標折讓Y%","決標折讓Y%備註","決標淨額","決標日期","健保調價承諾A%","履約起日",//TenderResult75-84
		"-廠商資料-","廠商統一編號","廠商名稱","電話","傳真","聯絡人","聯絡人電話","聯絡信箱","廠商備註",//FirmData86-93
		"-廠商管證登記證-","管證登記證字號","管證登記證生效起始日","管證登記證生效終止日"//Certificate95-98
	};
	
	private JPanel contentPane;
	private JScrollPane scrollPane;
	private JRadioButton And[] = new JRadioButton[49];
	private JRadioButton Or[] = new JRadioButton[49];
	private ButtonGroup AndOrGroup[] = new ButtonGroup[49];
    private String saveValue=null;
	static	String selectGroup[] = new String[49];
	private JComboBox SearchMedicament[] = new JComboBox[50];
	static	String selectMedicament[] = new String[50];
    private JTextField condition[] = new JTextField[50];
    static	String selectCondition[] = new String[50];
    private RadioButtonListener radioButtonListener=new RadioButtonListener();
    static int cansearch = 1;
    int v;
	static	String select = "SELECT Medicine.`藥品唯一碼`,FirmData.`廠商統一編號`";	

	static	String from = " FROM `Medicine`,`FirmData`,`TenderResult`";
	static	String where;
	private JTextField textField;
    private JTextField editSQL;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SearchMedicine frame = new SearchMedicine(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SearchMedicine(Index index) throws ClassNotFoundException {
		final SearchMedicine clone = this;		
		final Index Hidding = index;
        contentPane=new JPanel();  
        contentPane.setBorder(new EmptyBorder(5,5,5,5));  
        contentPane.setLayout(new BorderLayout(0,0));
        this.setContentPane(contentPane);  
        this.setTitle("查詢藥品品項");  
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        this.setBounds(100, 100, 744, 445);  
        this.setVisible(true);
        //捲軸
        JPanel panel = new JPanel();
        panel.setPreferredSize(new Dimension(0,3000));
        scrollPane=new JScrollPane(panel);
        panel.setAutoscrolls(true);
        scrollPane.setPreferredSize(new Dimension(900,600));
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        contentPane.add(scrollPane,BorderLayout.CENTER);
        panel.setLayout(null);
        JPanel panel_1 = new JPanel();
        contentPane.add(panel_1, BorderLayout.SOUTH);
        
        JButton newSearch = new JButton("+");
        newSearch.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
       		 if(cansearch<50){
    			 int b = cansearch;
    		   		And[b-1].setVisible(true);
    		   		Or[b-1].setVisible(true);
    		   		SearchMedicament[b].setVisible(true);
    		   		condition[b].setVisible(true);
    		   		
    	            /*SearchMedicament[b].addItemListener(new ItemListener() {
    	             	 public void itemStateChanged(final ItemEvent e) {
    	             	 int index = SearchMedicament[b].getSelectedIndex();
    	             	 if (index == 0 || index == 22 || index == 32 || index == 38 || index == 44 || index == 50 || index == 74 || index == 85 || index == 94) { // ==0表示选中的事第一个
    	             		condition[b].setEditable(false); 
    	             	 }
    	             	}
    	             });*/
    		        SearchMedicament[b].setSelectedIndex(1);
    		        SearchMedicament[b].addItemListener(new ItemListener() {
    		          	 public void itemStateChanged(final ItemEvent e) {
    		                 if(e.getStateChange()==ItemEvent.SELECTED){
    		                     //未被選擇變成已選擇
    					          	 int index = SearchMedicament[b].getSelectedIndex();
    					          	 if (index == 0 || index == 22 || index == 32 || index == 38 || index == 44 || index == 50 || index == 74 || index == 85 || index == 94) { // ==0表示选中的事第一个
    					          		condition[b].setEditable(false); 
    					          	 }                     
    		                     }
    		                     if(e.getStateChange()==ItemEvent.DESELECTED){
    		                     //已選擇變成未被選擇
    					          	 int index = SearchMedicament[b].getSelectedIndex();
    					          	 if (index != 0 || index != 22 || index != 32 || index != 38 || index != 44 || index != 50 || index != 74 || index != 85 || index != 94) { // ==0表示选中的事第一个
    					          		condition[b].setEditable(true); 
    					          	 } 
    		                     } 

    		          	}
    		          });
    		   		
    		   		
    			 cansearch++;
    		 }
        	}
        });
        newSearch.setBounds(422, 88, 46, 23);
        panel.add(newSearch);
        
        JButton button = new JButton("返回主選單");
        button.setFont(new Font("標楷體", Font.PLAIN, 15));
        panel_1.add(button);
        button.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
    			Hidding.setVisible(true);
    			dispose();
        	}
        });
        
        JLabel label = new JLabel("查詢條件：");
        label.setFont(new Font("標楷體", Font.PLAIN, 15));
        panel_1.add(label);       
        editSQL = new JTextField();
        editSQL.setFont(new Font("新細明體", Font.PLAIN, 14));
        panel_1.add(editSQL);
        editSQL.setColumns(30);
        
              
        //SQL按鈕
        JButton btnNewButton = new JButton("SQL");
        panel_1.add(btnNewButton);
		btnNewButton.setFont(new Font("標楷體", Font.PLAIN, 15));
		btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {

				int seat;
        		final	String selectFTable[] = new String[cansearch];
        		final	String selectWTable[] = new String[cansearch];

        		/*for(int a=1;a<cansearch;a++){
        			selectGroup[a-1] = AndOrGroup[a-1].getSelection().toString();
        			//System.out.println(selectGroup[a-1]);
        		}//取RADIO*/
			
        		for(int b=0;b<cansearch;b++){
        			selectMedicament[b] = SearchMedicament[b].getSelectedItem().toString();
        			selectCondition[b] = condition[b].getText().trim();		
        		}//取欄位跟輸入

				for(int i=0;i<cansearch;i++){
					for(int j=0;j<98;j++){
						if(selectMedicament[i].equals(Medicament[j])){
							seat=j;

							if(seat >= 1 && seat <= 21){
								//selectFTable[i]="`Medicine`,";
								selectWTable[i]="Medicine.";
							}else if(seat >= 23 && seat <= 31){
								//selectFTable[i]="`ReLackMedicineRecord`,";
								selectWTable[i]="ReLackMedicineRecord.";
							}else if(seat >= 33 && seat <= 37){
								//selectFTable[i]="`TypeOfPurchase`,";
								selectWTable[i]="TypeOfPurchase,";
							}else if(seat >= 39 && seat <= 43){
								//selectFTable[i]="`Price`,";
								selectWTable[i]="Price.";
							}else if(seat >= 45 && seat <= 49){
								//selectFTable[i]="`Tender`,";
								selectWTable[i]="Tender.";
							}else if(seat >= 51 && seat <= 73){
								//selectFTable[i]="`TenderDetail`,";
								selectWTable[i]="TenderDetail.";
							}else if(seat >= 75 && seat <= 84){
								//selectFTable[i]="`TenderResult`,";
								selectWTable[i]="TenderResult.";
							}else if(seat >= 86 && seat <= 93){
								//selectFTable[i]="`FirmData`,";
								selectWTable[i]="FirmData.";
							}else if(seat >= 95 && seat <= 98){
								//selectFTable[i]="`Certificate`,";
								selectWTable[i]="Certificate.";
							}
						}
					}
        		}//取table
				//where = " WHERE Medicine.`藥品唯一碼` = TenderResult.`藥品唯一碼` AND FirmData.`廠商統一編號` = TenderResult.`廠商統一編號` AND TenderDetail.`流水號` = TenderResult.`流水號` AND TenderDetail.`案號項次` = TenderResult.`案號項次` AND Medicine.`藥品唯一碼` = Price.`藥品唯一碼` AND Medicine.`藥品唯一碼` = ReLackMedicineRecord.`藥品唯一碼` AND Medicine.`藥品唯一碼` = TypeOfPurchase.`藥品唯一碼` AND FirmData.`廠商統一編號` = Certificate.`廠商統一編號` AND";
				where = " WHERE Medicine.`藥品唯一碼` = TenderResult.`藥品唯一碼` AND FirmData.`廠商統一編號` = TenderResult.`廠商統一編號` AND";
				for(int k=0;k<cansearch;k++){
					//from = from + selectFTable[k];

					if(k != (cansearch-1)){
						where = where + (" "+selectWTable[k]+"`"+selectMedicament[k]+"` LIKE '%"+selectCondition[k]+"%' "+selectGroup[k]);
					}else if(k == (cansearch-1)){
						where = where + (" "+selectWTable[k]+"`"+selectMedicament[k]+"` LIKE '%"+selectCondition[k]+"%'");
					}

				}
				System.out.println(where);	
				editSQL.setText(where);
				
				for(int i=0 ;i<49;i++){
					System.out.println(selectGroup[i]);			
				}

        	}               	
        });
		          
        JButton btnSearch = new JButton("勾選顯示欄位");
        btnSearch.setFont(new Font("標楷體", Font.PLAIN, 15));
        btnSearch.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		String sql_where = editSQL.getText().trim();	
      			try {
					CheckMedicine cm = new CheckMedicine(clone,select,from,sql_where);
					cm.setVisible(true);
					dispose();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
        	}
        });
        panel_1.add(btnSearch);
        panel_1.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
       

       
        //圖片
        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		java.net.URL imgURL = SearchMedicine.class.getResource("image/MIM.png");
		lblNewLabel.setIcon(new ImageIcon(imgURL));
        contentPane.add(lblNewLabel, BorderLayout.NORTH); 
        
        //顯示
        SearchMedicament[0] = new JComboBox(Medicament);
        SearchMedicament[0].setBounds(105, 89, 178, 21);
        SearchMedicament[0].setFont(new Font("標楷體", Font.PLAIN, 15));
        panel.add(SearchMedicament[0]);

        
        condition[0] = new JTextField();
        condition[0].setBounds(293, 89, 119, 21);
        panel.add(condition[0]);
        
        SearchMedicament[0].setSelectedIndex(1);
        SearchMedicament[0].addItemListener(new ItemListener() {
          	 public void itemStateChanged(final ItemEvent e) {
                 if(e.getStateChange()==ItemEvent.SELECTED){
                     //未被選擇變成已選擇
			          	 int index = SearchMedicament[0].getSelectedIndex();
			          	 if (index == 0 || index == 22 || index == 32 || index == 38 || index == 44 || index == 50 || index == 74 || index == 85 || index == 94) { // ==0表示选中的事第一个
			          		condition[0].setEditable(false); 
			          	 }                     
                     }
                     if(e.getStateChange()==ItemEvent.DESELECTED){
                     //已選擇變成未被選擇
			          	 int index = SearchMedicament[0].getSelectedIndex();
			          	 if (index != 0 || index != 22 || index != 32 || index != 38 || index != 44 || index != 50 || index != 74 || index != 85 || index != 94) { // ==0表示选中的事第一个
			          		condition[0].setEditable(true); 
			          	 } 
                     } 

          	}
          });
        
        JLabel lblNewLabel_1 = new JLabel("查詢藥品品項");
        lblNewLabel_1.setFont(new Font("標楷體", Font.PLAIN, 20));
        lblNewLabel_1.setBounds(10, 10, 137, 31);
        panel.add(lblNewLabel_1);
        
        JLabel lblNewLabel_2 = new JLabel("輸入查詢條件：");
        lblNewLabel_2.setFont(new Font("標楷體", Font.PLAIN, 20));
        lblNewLabel_2.setBounds(150, 51, 156, 23);
        panel.add(lblNewLabel_2);
        condition[0].setColumns(25);     
        
        //隱藏
        
        for(v=1;v<50;v++){
        	
	   		And[v-1] = new JRadioButton("AND");
	   		And[v-1].addActionListener(radioButtonListener);
	   		And[v-1].setFont(new Font("Arial", Font.PLAIN, 12));
	   		And[v-1].setBounds(70, 89+(31*v), 54, 21);
	   		panel.add(And[v-1]);
	   		Or[v-1] = new JRadioButton("OR");
	   		Or[v-1].addActionListener(radioButtonListener);
	   		Or[v-1].setFont(new Font("Arial", Font.PLAIN, 12));
	   		Or[v-1].setBounds(120, 89+(31*v), 50, 21);
	   		panel.add(Or[v-1]);
	   		AndOrGroup[v-1] = new ButtonGroup();
	   		AndOrGroup[v-1].add(And[v-1]);
	   		AndOrGroup[v-1].add(Or[v-1]);
	   		And[v-1].setVisible(false);
	   		Or[v-1].setVisible(false);
        	
            SearchMedicament[v] = new JComboBox(Medicament);
            SearchMedicament[v].setBounds(180, 89+(31*v), 178, 21);
            SearchMedicament[v].setFont(new Font("標楷體", Font.PLAIN, 15));
            panel.add(SearchMedicament[v]);
            SearchMedicament[v].setVisible(false);
            
            condition[v] = new JTextField();
            condition[v].setBounds(368, 89+(31*v), 119, 21);
            panel.add(condition[v]);
            condition[v].setColumns(25);
            condition[v].setVisible(false);
            
            
            
        }
        
	}
    public class RadioButtonListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent a) {
        	
        	for(int y=1;y<cansearch;y++){        	
	            JRadioButton temp = (JRadioButton)a.getSource();
	            if(temp.isSelected()){
	                saveValue=temp.getText();
	                selectGroup[y-1] = temp.getText();
	            }            
        	}             
        }
         
    }
}

