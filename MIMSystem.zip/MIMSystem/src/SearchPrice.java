﻿import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SearchPrice extends JFrame {

	private JPanel contentPane;
	private String[] price={"上傳日期","藥品唯一碼","健保碼","健保價","生效起日","生效迄日"};
	private JTextField condition;
	static String inputcondition;
	static String selectcombobox;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SearchPrice frame = new SearchPrice(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SearchPrice(Index index) {
		final SearchPrice clone = this;
		final Index Hidding = index;
		setTitle("查詢健保價");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 552, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		/*JLabel lblNewLabel = new JLabel("");
		java.net.URL img = Index.class.getResource("image/MIM.png");
		lblNewLabel.setIcon(new ImageIcon(img));
		lblNewLabel.setBounds(376, 0, 160, 129);
		contentPane.add(lblNewLabel);*/
		
		JLabel label = new JLabel("請選擇要查詢的條件");
		label.setFont(new Font("標楷體", Font.PLAIN, 20));
		label.setBounds(178, 25, 240, 38);
		contentPane.add(label);
		
		JComboBox comboBox = new JComboBox(price);
		comboBox.setFont(new Font("標楷體", Font.PLAIN, 14));
		comboBox.setBounds(78, 123, 97, 21);
		contentPane.add(comboBox);
		
		condition = new JTextField();
		condition.setBounds(232, 123, 240, 21);
		contentPane.add(condition);
		condition.setColumns(10);
		
		JButton search_bt = new JButton("查詢");
		search_bt.setFont(new Font("標楷體", Font.PLAIN, 16));
		search_bt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selectcombobox = comboBox.getSelectedItem().toString();//抓條件
	    		inputcondition = condition.getText().trim();//抓輸入值
	    		
	    		if(condition.getText().trim().equals("")){
	    			JOptionPane.showMessageDialog(SearchPrice.this, "尚未輸入條件!","查詢失敗",JOptionPane.WARNING_MESSAGE);
					//int result=JOptionPane.showConfirmDialog(SearchPrice.this,"確定要結束程式嗎?","確認訊息",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
					//if (result==JOptionPane.YES_OPTION) {System.exit(0);}
					}else{
						ShowPrice searchpricereasult = new ShowPrice(clone,selectcombobox,inputcondition);
						searchpricereasult.setVisible(true);
						dispose();
					}
			}
		});
		search_bt.setBounds(283, 205, 87, 38);
		contentPane.add(search_bt);
		
		JButton index_bt = new JButton("返回主選單");
		index_bt.setFont(new Font("標楷體", Font.PLAIN, 16));
		index_bt.setBounds(127, 205, 123, 38);
		index_bt.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {	
	    		
    			Hidding.setVisible(true);
    			dispose();

	    	}
	        });
		contentPane.add(index_bt);
	}
}
