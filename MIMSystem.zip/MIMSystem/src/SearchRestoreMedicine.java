﻿import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SearchRestoreMedicine extends JFrame {

	private JPanel contentPane;
	private JTextField condition;
	private JButton Search_button;
	static String inputcondition;
	static String selectcombobox;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SearchRestoreMedicine frame = new SearchRestoreMedicine(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SearchRestoreMedicine(Index index) {
		final SearchRestoreMedicine clone=this;
		final Index Hidding = index;
		setTitle("恢復供藥紀錄");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 498, 275);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("請輸入欲查詢條件");
		label.setFont(new Font("標楷體", Font.PLAIN, 20));
		label.setBounds(173, 30, 170, 34);
		contentPane.add(label);
		
		String []search={"得知日期","藥品唯一碼","缺停藥類型","訊息來源","公告來函日期","回收批號","缺停藥狀況說明","替代藥藥品唯一碼","替代藥類型","備註"};
		
		JComboBox comboBox = new JComboBox(search);
		comboBox.setFont(new Font("標楷體", Font.PLAIN, 15));
		comboBox.setBounds(20, 103, 183, 21);
		contentPane.add(comboBox);
		
		condition = new JTextField();
		condition.setBounds(213, 97, 269, 34);
		contentPane.add(condition);
		condition.setColumns(10);
		
		Search_button = new JButton("\u67E5\u8A62");
		Search_button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selectcombobox = comboBox.getSelectedItem().toString();//抓條件
	    		inputcondition = condition.getText().trim();//抓輸入值
	    		
	    		if(condition.getText().trim().equals("")){
	    			JOptionPane.showMessageDialog(SearchRestoreMedicine.this, "尚未輸入條件!","查詢失敗",JOptionPane.WARNING_MESSAGE);
					//int result=JOptionPane.showConfirmDialog(SearchTender.this,"確定要結束程式嗎?","確認訊息",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
					//if (result==JOptionPane.YES_OPTION) {System.exit(0);}
	    		}else{
	    			ShowLackMedicine SLM =new ShowLackMedicine(clone,selectcombobox,inputcondition);
					SLM.setVisible(true);
					dispose();
	    		}
			}
		});
		Search_button.setFont(new Font("標楷體", Font.PLAIN, 15));
		Search_button.setBounds(250, 200, 87, 29);
		contentPane.add(Search_button);
		
		JButton btnNewButton = new JButton("回主畫面");
		btnNewButton.setFont(new Font("標楷體", Font.PLAIN, 15));
		btnNewButton.setBounds(136, 201, 104, 28);
		contentPane.add(btnNewButton);
		
		/*JLabel pic = new JLabel("");  //圖片
		pic.setBounds(436, 10, 46, 15);
		pic.setIcon(new ImageIcon("C:\\Users\\user\\workspace\\MIMSystem\\src\\MIM.png"));
		pic.setHorizontalAlignment(SwingConstants.RIGHT);
		contentPane.add(pic, BorderLayout.NORTH);*/
	}
}
