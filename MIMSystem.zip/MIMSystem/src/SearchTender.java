﻿
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SearchTender extends JFrame {

	private JPanel contentPane;
	private JTextField condition;
	private JLabel lblNewLabel;
	private JButton Search_button;
	static String inputcondition;
	static String selectcombobox;
	private JLabel lblNewLabel_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SearchTender frame = new SearchTender(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SearchTender(Index index) {
		setResizable(false);
		final SearchTender clone=this;
		final Index Hidding = index;
		setTitle("\u67E5\u8A62\u62DB\u6A19\u54C1\u9805\u8868");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 552, 349);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		String []search={"中文案名","總務室承辦人","案號","案號項次","成份規格含量","標註用藥品或藥材","廠牌或同等品","品質需求","招標藥品單位","招標藥品包裝","預算單價","預估用量","預估總價","履約起日","履約迄日","標案狀況","後續擴充期限","後續擴充模式","後續擴充金額","後擴契約起日","後擴契約迄日","標購方式","歷次廠商報價","歷次廠商投標價","強制結案","管理費模式"};
		contentPane.setLayout(null);
		
		JComboBox comboBox = new JComboBox(search);
		comboBox.setFont(new Font("標楷體", Font.PLAIN, 15));
		comboBox.setBounds(29, 146, 183, 21);
		contentPane.add(comboBox);
		
		condition = new JTextField();
		condition.setBounds(249, 141, 269, 34);
		contentPane.add(condition);
		condition.setColumns(10);
		
		lblNewLabel = new JLabel("\u8ACB\u8F38\u5165\u6B32\u67E5\u8A62\u689D\u4EF6");
		lblNewLabel.setFont(new Font("標楷體", Font.PLAIN, 20));
		lblNewLabel.setBounds(173, 30, 170, 34);
		contentPane.add(lblNewLabel);
		
		Search_button = new JButton("\u67E5\u8A62");
		Search_button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selectcombobox = comboBox.getSelectedItem().toString();//抓條件
	    		inputcondition = condition.getText().trim();//抓輸入值
	    		
	    		if(condition.getText().trim().equals("")){
	    			JOptionPane.showMessageDialog(SearchTender.this, "尚未輸入條件!","查詢失敗",JOptionPane.WARNING_MESSAGE);
					//int result=JOptionPane.showConfirmDialog(SearchTender.this,"確定要結束程式嗎?","確認訊息",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
					//if (result==JOptionPane.YES_OPTION) {System.exit(0);}
	    		}else{
	    			ShowTender ST =new ShowTender(clone,selectcombobox,inputcondition);
					ST.setVisible(true);
					dispose();
	    		}
			}
		});
		Search_button.setFont(new Font("標楷體", Font.PLAIN, 15));
		Search_button.setBounds(320, 270, 87, 29);
		contentPane.add(Search_button);
		
		JButton btnNewButton = new JButton("返回主選單");
		btnNewButton.setFont(new Font("標楷體", Font.PLAIN, 15));
		btnNewButton.setBounds(123, 270, 126, 28);
		btnNewButton.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {	

	    			Hidding.setVisible(true);
	    			dispose();

	    	}
	    });
		
		contentPane.add(btnNewButton);
		
		/*lblNewLabel_1 = new JLabel("");
		java.net.URL img = Index.class.getResource("image/MIM.png");
		lblNewLabel_1.setIcon(new ImageIcon(img));
		lblNewLabel_1.setBounds(377, 0, 169, 117);
		contentPane.add(lblNewLabel_1);*/
		
		/*JLabel pic = new JLabel("");  //圖片
		pic.setBounds(436, 10, 46, 15);
		pic.setIcon(new ImageIcon("C:\\Users\\user\\workspace\\MIMSystem\\src\\MIM.png"));
		pic.setHorizontalAlignment(SwingConstants.RIGHT);
		contentPane.add(pic, BorderLayout.NORTH);*/
	}
}
