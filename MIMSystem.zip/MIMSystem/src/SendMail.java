﻿
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendMail {
 public static void main(String args[]) {
  String host = "smtp.gmail.com";
  int port = 587;
  final String username = "mimsystem708@gmail.com";
  final String password = "MIMSystem708708";//your password

  Properties props = new Properties();
  props.put("mail.smtp.host", host);
  props.put("mail.smtp.auth", "true");
  props.put("mail.smtp.starttls.enable", "true");
  props.put("mail.smtp.port", port);
  Session session = Session.getInstance(props, new Authenticator() {
   protected PasswordAuthentication getPasswordAuthentication() {
    return new PasswordAuthentication(username, password);
   }
  });

  try {

   Message message = new MimeMessage(session);
   message.setFrom(new InternetAddress("mimsystem708@gmail.com"));
   message.setRecipients(Message.RecipientType.TO, InternetAddress.parse("shmily0514@yahoo.com.tw"));
   message.setSubject("提醒進行招標作業");
   message.setText("Dear 聯醫, 該進行招標作業囉!");

   Transport transport = session.getTransport("smtp");
   transport.connect(host, port, username, password);

   Transport.send(message);

   System.out.println("寄送email結束.");

  } catch (MessagingException e) {
   throw new RuntimeException(e);
  }
 }
}