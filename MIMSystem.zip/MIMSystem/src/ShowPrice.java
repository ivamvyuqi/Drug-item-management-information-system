﻿import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ShowPrice extends JFrame {

	private JPanel contentPane;
	private String selectcombobox;
	private String inputcondition;
	private Object[][] data = new Object[1][];
	static int numberOfColumns = 0;
	private int numberOfRows=0;
	static String []columnNames=new String[1];
	private final boolean DEBUG = false;
	private JTable tableprice;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ShowPrice frame = new ShowPrice(null,"","");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ShowPrice(SearchPrice searchprice,String combobox,String condition) {
		setTitle("查詢健保價");
		final ShowPrice clone = this;
		final SearchPrice Hidding = searchprice;
		
		selectcombobox=combobox;
		inputcondition=condition;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 618, 473);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		/*JLabel lblNewLabel = new JLabel("");
		java.net.URL img = Index.class.getResource("image/MIM.png");
		lblNewLabel.setIcon(new ImageIcon(img));
		lblNewLabel.setBounds(432, 10, 160, 129);
		contentPane.add(lblNewLabel);*/
		
	     Connection conn = null;  
	  	 Statement statement;
	  	 ResultSet rs;
	  	 ResultSetMetaData rsMetaData;
	     try{
  	         Class.forName("org.mariadb.jdbc.Driver");
  	         System.out.println("資料庫連結成功");
             conn = DriverManager.getConnection("jdbc:mariadb://lots.im.nuu.edu.tw/MIMSystem", "MIMSystem", "MIMSystem");
             System.out.println("連接成功MySQL");
             statement = conn.createStatement();
	           rs = statement.executeQuery("SELECT * FROM Price WHERE "+selectcombobox+" LIKE '%"+inputcondition+"%'");
             //rs = statement.executeQuery("SELECT * FROM Price WHERE "+selectcombobox+"= '"+inputcondition+"'");  
	           rsMetaData = rs.getMetaData();
	           numberOfColumns = rsMetaData.getColumnCount();	
	  			 columnNames=new String[numberOfColumns];
	  				for(int i=1; i<=numberOfColumns; i++){
	  				  System.out.printf("%s\t",rsMetaData.getColumnName(i));//計算有幾欄
	  				  columnNames[i-1]=rsMetaData.getColumnName(i);//每欄名稱
	  				}
	  			    System.out.println(); 	
	  			  while (rs.next()){
	  			      for(int i=1; i<=numberOfColumns; i++)
	  				   {
	  				     System.out.printf("%s\t",rs.getObject(i));			  	
	  			       }
	  			      System.out.println();	
	  			      numberOfRows++;
	  			     }
	  			    data=new Object[numberOfRows][numberOfColumns];//開大小
	  			    int order=0;
	  			  rs = statement.executeQuery("SELECT * FROM Price WHERE "+selectcombobox+" LIKE '%"+inputcondition+"%'");
	  			  //rs = statement.executeQuery("SELECT * FROM Price WHERE "+selectcombobox+"= '"+inputcondition+"'");  			  
	  			    while (rs.next()){
					      for(int i=1; i<=numberOfColumns; i++)
						   {
					    	 if(rs.getObject(i)==null){
					    		data[order][i-1]="";
					    	 }
					    	 else{
					    		data[order][i-1]=rs.getObject(i);
					    	 }
					       }
					      order++;
					      if(order==0){
					    	  int result=JOptionPane.showConfirmDialog(null, "查無資料","查詢健保價",JOptionPane.DEFAULT_OPTION,JOptionPane.PLAIN_MESSAGE);
					    	  if(result==0){
					    		  Hidding.setVisible(true);
					    		  dispose();
					    	  }
					      }
	  				 }System.out.println(order);
	  				
	  		  	  statement.close();
	  		      conn.close();
	     }catch(ClassNotFoundException classNotFound){//找不到JDBC Driver
	  	        classNotFound.printStackTrace();	
	  	       }catch(SQLException sqlException){//資料庫操作發生錯誤
	  	        sqlException.printStackTrace();
	  	      }
	
			 MyTableModel myTableModel = new MyTableModel(columnNames, data);//自行定義table
		      myTableModel.fireTableDataChanged();
		      if (DEBUG) { 
		        for (int i = 0; i < numberOfRows; i++) {
		          for (int j = 0; j < numberOfColumns; j++) {
		            System.out.println(myTableModel.getValueAt(i, j) + "  ");
		          }
		        }
		      }
		      //System.out.println(data.length);
		      tableprice = new JTable(myTableModel); 
		      tableprice.setRowSelectionAllowed(false);
		      tableprice.getTableHeader().setReorderingAllowed(false);//欄位拖動功能
		      tableprice.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);  
		      tableprice.setPreferredScrollableViewportSize(new Dimension(650, 70));
		      JScrollPane scrollPane = new JScrollPane(tableprice);
		      scrollPane.setBounds(10, 147, 582, 238);
		      tableprice.setDefaultRenderer(JButton.class, new JButtonRenderer());
		      contentPane.setLayout(null);
		      contentPane.add(scrollPane);
	     
	     JButton btnNewButton = new JButton("重新查詢");
	     btnNewButton.addActionListener(new ActionListener() {
	     	public void actionPerformed(ActionEvent e) {
	     		Hidding.setVisible(true);
				dispose();
	     	}
	     });
	     btnNewButton.setFont(new Font("標楷體", Font.PLAIN, 16));
	     btnNewButton.setBounds(249, 395, 108, 29);
	     contentPane.add(btnNewButton);
	}
	
	  class MyTableModel extends AbstractTableModel { 
		    String[] columnNames;
		    Object[][] data;
		    public void removeTableModelListener(TableModelListener l){
		    	l.tableChanged(null);
		    }
		    public MyTableModel(String[] columnNames, Object[][] data) {
		      this.columnNames = columnNames;
		      this.data = data;
		    }
		 
		    public int getColumnCount() {
		      return columnNames.length;
		    }
		 
		    public int getRowCount() {
		      return data.length;
		    }
		 
		    public String getColumnName(int col) {
		      return columnNames[col];
		    }
		 
		    public Object getValueAt(int row, int col) {
		      return data[row][col];
		    }
		 
		    public Class getColumnClass(int c) {
		      return getValueAt(0, c).getClass();
		      //Object value=this.getValueAt(0,c);
		     // return (value==null?Object.class:value.getClass());

		    }
		 
		    @Override
		    public boolean isCellEditable(int rowIndex, int columnIndex) {
		      return getColumnClass(columnIndex) == JButton.class;
		    }
		    
		  }

}
