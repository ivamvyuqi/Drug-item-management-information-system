﻿import java.awt.Dimension;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class ShowTender extends JFrame implements ActionListener{

	private JPanel contentPane;
	private String selectcombobox;
	private String inputcondition;
	static int numberOfColumns = 0;
	private int numberOfRows=0;
	static String []columnNames=new String[1];
	private Object[][] data = new Object[1][];
	private final boolean DEBUG = false;
	private JTable tabletender;
	private JButton btnModify[];
	static int testn=0;
	static ModifyTender[] mt=new ModifyTender[1];
	static int EST=0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ShowTender frame = new ShowTender(null,"","");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ShowTender(SearchTender ST,String combobox,String condition) {
		setTitle("查詢招標品項表");
		setResizable(false);
		final ShowTender clone=this;
		final SearchTender Hidding=ST;
		selectcombobox=combobox;
		inputcondition=condition;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		/*JLabel pic = new JLabel("");  //圖片
		pic.setBounds(944, 10, 46, 15);
		pic.setIcon(new ImageIcon("C:\\Users\\user\\workspace\\MIMSystem\\src\\MIM.png"));
		pic.setHorizontalAlignment(SwingConstants.RIGHT);
		contentPane.add(pic, BorderLayout.NORTH);*/
		
		Connection conn = null;  
	  	 Statement statement;
	  	 ResultSet rs;
	  	 ResultSetMetaData rsMetaData;
	     try{
 	         Class.forName("org.mariadb.jdbc.Driver");
 	         System.out.println("資料庫連結成功");
            conn = DriverManager.getConnection("jdbc:mariadb://lots.im.nuu.edu.tw/MIMSystem", "MIMSystem", "MIMSystem");
            System.out.println("連接成功MySQL");
            statement = conn.createStatement();
	           //rs = statement.executeQuery("SELECT * FROM TenderDetail WHERE "+selectcombobox+" = '"+inputcondition+"'");
            rs = statement.executeQuery("SELECT Tender.流水號,Tender.中文案名,Tender.總務室承辦人,Tender.案號,Tender.管理費模式,"
  			  		+ "TenderDetail.案號項次,TenderDetail.成份規格含量,TenderDetail.標註用藥品或藥材,TenderDetail.廠牌或同等品,TenderDetail.品質需求,TenderDetail.招標藥品單位,TenderDetail.招標藥品包裝,"
  			  		+ "TenderDetail.預算單價,TenderDetail.預估用量,TenderDetail.預估總價,TenderDetail.履約起日,TenderDetail.履約迄日,TenderDetail.履約期限,TenderDetail.標案狀況,TenderDetail.後續擴充期限,TenderDetail.後續擴充模式,TenderDetail.後續擴充金額,"
  			  		+ "TenderDetail.後擴契約起日,TenderDetail.後擴契約迄日,TenderDetail.標購方式,TenderDetail.歷次廠商報價,TenderDetail.歷次廠商投標價,TenderDetail.強制結案"
  			  		+ " FROM TenderDetail,Tender WHERE "+selectcombobox+" LIKE '%"+inputcondition+"%' and  TenderDetail.流水號=Tender.流水號 ");
	           //rs = statement.executeQuery("SELECT * FROM Price WHERE '健保價' = '11'");
	           rsMetaData = rs.getMetaData();
	           numberOfColumns = rsMetaData.getColumnCount();	
	  			 columnNames=new String[numberOfColumns+1];
	  				for(int i=1; i<=numberOfColumns; i++){
	  				  System.out.printf("%s\t",rsMetaData.getColumnName(i));//計算有幾欄
	  				  columnNames[i-1]=rsMetaData.getColumnName(i);//每欄名稱
	  				}
	  			    System.out.println(); 	
	  			    
	  			  while (rs.next()){
	  			      for(int i=1; i<=numberOfColumns; i++)
	  				   {
	  				     System.out.printf("%s\t",rs.getObject(i));			  	
	  			       }
	  			      System.out.println();	
	  			      numberOfRows++;
	  			     }
	  			  
	  			  	btnModify = new JButton[numberOfRows];//每筆後面有按鈕
	  			    data=new Object[numberOfRows][numberOfColumns+1];//開大小
	  			    int order=0;
	  			  rs = statement.executeQuery("SELECT Tender.流水號,Tender.中文案名,Tender.總務室承辦人,Tender.案號,Tender.管理費模式,"
		  			  		+ "TenderDetail.案號項次,TenderDetail.成份規格含量,TenderDetail.標註用藥品或藥材,TenderDetail.廠牌或同等品,TenderDetail.品質需求,TenderDetail.招標藥品單位,TenderDetail.招標藥品包裝,"
		  			  		+ "TenderDetail.預算單價,TenderDetail.預估用量,TenderDetail.預估總價,TenderDetail.履約起日,TenderDetail.履約迄日,TenderDetail.履約期限,TenderDetail.標案狀況,TenderDetail.後續擴充期限,TenderDetail.後續擴充模式,TenderDetail.後續擴充金額,"
		  			  		+ "TenderDetail.後擴契約起日,TenderDetail.後擴契約迄日,TenderDetail.標購方式,TenderDetail.歷次廠商報價,TenderDetail.歷次廠商投標價,TenderDetail.強制結案"
		  			  		+ " FROM TenderDetail,Tender WHERE "+selectcombobox+" LIKE '%"+inputcondition+"%' and  TenderDetail.流水號=Tender.流水號 ");
	  			  
	  			  //rs = statement.executeQuery("SELECT * FROM Price WHERE '健保價' = '11'");
	  			  
	  			 while (rs.next()){
				      for(int i=1; i<=numberOfColumns; i++)
					   {
				    	 if(rs.getObject(i)==null){
				    		data[order][i-1]="";
				    	 }
				    	 else{
				    		data[order][i-1]=rs.getObject(i);
				    	 }
				       }
				      order++;
				      if(order==0){
				    	  int result=JOptionPane.showConfirmDialog(null, "查無資料","查詢招標品項表",JOptionPane.DEFAULT_OPTION,JOptionPane.PLAIN_MESSAGE);
				    	  if(result==0){
				    		  Hidding.setVisible(true);
				    		  dispose();
				    	  }
				      }
				      
 				 }System.out.println(order);
 		  	  statement.close();
 		      conn.close();
	     }catch(ClassNotFoundException classNotFound){//找不到JDBC Driver
	  	        classNotFound.printStackTrace();	
	  	       }catch(SQLException sqlException){//資料庫操作發生錯誤
	  	        sqlException.printStackTrace();
	  	      }
	     MyTableModel myTableModel = new MyTableModel(columnNames, data);//自行定義table
	      myTableModel.fireTableDataChanged();
	      if (DEBUG) { 
	        for (int i = 0; i < numberOfRows; i++) {
	          for (int j = 0; j < numberOfColumns; j++) {
	            System.out.println(myTableModel.getValueAt(i, j) + "  ");
	          }
	        }
	      }
	      
	      for (int i = 0; i < data.length; i++) { //按鈕
	        	btnModify[i] = new JButton("修改"+i);     	
	        	data[i][numberOfColumns] = btnModify[i];
	        }
	      //System.out.println(data.length);
	      tabletender = new JTable(myTableModel);
	      tabletender.setFont(new Font("標楷體", Font.PLAIN, 16));
	      tabletender.setRowSelectionAllowed(false);
	      tabletender.getTableHeader().setReorderingAllowed(false);//欄位拖動功能
	      tabletender.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);  
	      tabletender.setPreferredScrollableViewportSize(new Dimension(650, 70));
	      JScrollPane scrollPane = new JScrollPane(tabletender);
	      scrollPane.setBounds(10, 64, 980, 364);	      
	      tabletender.setDefaultRenderer(JButton.class, new JButtonRenderer());
	      final TableCellButton tableCellButton = new TableCellButton();
	      tabletender.setDefaultEditor(JButton.class, tableCellButton);
		  tableCellButton.addActionListener(this);
	      contentPane.setLayout(null);
	      contentPane.add(scrollPane);	      
	      
		
     JButton returnSearch_bt = new JButton("重新查詢");
     returnSearch_bt.setFont(new Font("標楷體", Font.PLAIN, 15));
     returnSearch_bt.addActionListener(new ActionListener() {
     	public void actionPerformed(ActionEvent e) {
     		Hidding.setVisible(true);
			dispose();
     	}
     });
     returnSearch_bt.setBounds(448, 438, 107, 23);
     contentPane.add(returnSearch_bt);
    
	}
	
	public void actionPerformed(ActionEvent actEvent) { 
			
		  System.out.println(actEvent);
		  int ae = Integer.parseInt(actEvent.getActionCommand().substring(2));
		  System.out.println(ae);
		  String[] d= new String[numberOfColumns];
		  for(int i=0; i<numberOfColumns;i++){
			  d[i]=data[ae][i].toString();
		  }
		  testn++;
		  switch("SearchOrder"){	  	
		  case "SearchOrder" :{
		  ShowTender clone = this;
		  		if(mt[0]!=null){		  			
		  			mt = new ModifyTender[2];
					mt[1]=new ModifyTender(clone,d);
		  			mt[0].setVisible(false);	
		  			mt[1].setVisible(true);
		  			dispose();
			  		break;			  		
		  		}
		  		mt = new ModifyTender[1];
				mt[0]=new ModifyTender(clone,d);
		  		mt[0].setVisible(true);
		  		dispose();
		  		break;
				}
		  		default: break;
		 }
    }	
		
	  class MyTableModel extends AbstractTableModel {
		    String[] columnNames;
		    Object[][] data;
		    public void removeTableModelListener(TableModelListener l){
		    	l.tableChanged(null);
		    }
		    public MyTableModel(String[] columnNames, Object[][] data) {
		      this.columnNames = columnNames;
		      this.data = data;
		    }
		 
		    public int getColumnCount() {
		      return columnNames.length;
		    }
		 
		    public int getRowCount() {
		      return data.length;
		    }
		 
		    public String getColumnName(int col) {
		      return columnNames[col];
		    }
		 
		    public Object getValueAt(int row, int col) {
		      return data[row][col];
		    }
		 
		    public Class getColumnClass(int c) {
		      return getValueAt(0, c).getClass();
		      //Object value=this.getValueAt(0,c);
		     // return (value==null?Object.class:value.getClass());

		    }
		 
		    @Override
		    public boolean isCellEditable(int rowIndex, int columnIndex) {
		      return getColumnClass(columnIndex) == JButton.class;
		    }
		    
		  }
	}
	/*class TableCellButton extends JButton implements TableCellEditor {
		  private EventListenerList cellEditorListeners = new EventListenerList();
		 
		  public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected,
		      int row, int column) {
		    JButton button = (JButton) value;
		    setText(button.getText());
		    putClientProperty("row", new Integer(row));
		    return this;
		  }
		 
		  public void addCellEditorListener(CellEditorListener l) {
		    cellEditorListeners.add(CellEditorListener.class, l);
		  }
		 
		  protected void fireEditingCanceled() {
		    EventListener[] listeners = cellEditorListeners.getListeners(CellEditorListener.class);
		    for (int i = 0; i < listeners.length; ++i) {
		      CellEditorListener l = (CellEditorListener) listeners[i];
		      l.editingCanceled(changeEvent);
		    }
		  }
		 
		  protected void fireEditingStopped() {
		    EventListener[] listeners = cellEditorListeners.getListeners(CellEditorListener.class);
		    for (int i = 0; i < listeners.length; ++i) {
		      CellEditorListener l = (CellEditorListener) listeners[i];
		      l.editingStopped(changeEvent);
		    }
		  }
		 
		  public void cancelCellEditing() {
		    fireEditingCanceled();
		  }
		 
		  public Object getCellEditorValue() {
		    return null;
		  }
		 
		  public boolean isCellEditable(EventObject anEvent) {
		    if (anEvent instanceof MouseEvent) {
		      MouseEvent e = (MouseEvent) anEvent;
		      if (e.getID() == MouseEvent.MOUSE_PRESSED) {
		        MouseEvent newEvent = new MouseEvent(this, MouseEvent.MOUSE_PRESSED, e.getWhen(), e
		            .getModifiers(), 0, 0, e.getClickCount(), e.isPopupTrigger());
		        Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(newEvent);
		        return true;
		      }
		    }
		    return false;
		  }
		 
		  public void removeCellEditorListener(CellEditorListener l) {
		    cellEditorListeners.remove(CellEditorListener.class, l);
		  }
		 
		  public boolean shouldSelectCell(EventObject anEvent) {
		    return false;
		  }
		 
		  public boolean stopCellEditing() {
		    fireEditingStopped();
		    return true;
		  }
		}
		 
		class JButtonRenderer extends JButton implements TableCellRenderer {
		  public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
		      boolean hasFocus, int row, int column) {
		    JButton button = (JButton) value;
		    setText(button.getText());
		    return this;
		  }
		}
	*/