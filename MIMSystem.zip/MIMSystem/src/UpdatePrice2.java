﻿import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class UpdatePrice2 extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private String filePath;
	private File selectedFile;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UpdatePrice2 frame = new UpdatePrice2(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UpdatePrice2(Index index)throws ClassNotFoundException {
		final Index Hidding = index;
		
		setTitle("上傳健保價");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 552, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		/*JLabel lblNewLabel = new JLabel("");
		java.net.URL img = Index.class.getResource("image/MIM.png");
		lblNewLabel.setIcon(new ImageIcon(img));
		lblNewLabel.setBounds(376, 0, 160, 129);
		contentPane.add(lblNewLabel);*/
		
		JLabel filename = new JLabel("檔名：");
		filename.setFont(new Font("標楷體", Font.PLAIN, 16));
		filename.setBounds(27, 135, 54, 26);
		contentPane.add(filename);
		
		textField = new JTextField();
		textField.setBounds(80, 139, 342, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		final String date =getDateTime();
		
		
		JButton button = new JButton("瀏覽");
		button.setFont(new Font("標楷體", Font.PLAIN, 16));
		button.setBounds(428, 137, 87, 23);
		contentPane.add(button);
		button.addActionListener(new ActionListener()  
		{ 
		public void actionPerformed(ActionEvent ae)  
		{ 
		JFileChooser fileChooser = new JFileChooser();//宣告filechooser 
		int returnValue = fileChooser.showOpenDialog(null);//叫出filechooser 
		if (returnValue == JFileChooser.APPROVE_OPTION){ //判斷是否選擇檔案 
			selectedFile = fileChooser.getSelectedFile();//指派給File 
			System.out.println(selectedFile.getName()); //印出檔名 
			String filename=selectedFile.getName();
			//String filePath = "."; 	
			filePath =""+fileChooser.getSelectedFile().getPath();//將File轉成String   
			textField = new JTextField(filename);
			textField.setBounds(80, 139, 342, 21);
			contentPane.add(textField);
			textField.setColumns(10);
			}else{
				JOptionPane.showMessageDialog(UpdatePrice2.this, "尚未選擇檔案!","上傳失敗",JOptionPane.WARNING_MESSAGE);
				int result=JOptionPane.showConfirmDialog(UpdatePrice2.this,"確定要結束程式嗎?","確認訊息",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
				if (result==JOptionPane.YES_OPTION) {System.exit(0);}
			}
		}
		}); 
	
		JButton updatebutton = new JButton("上傳健保價");
		updatebutton.addActionListener(new ActionListener() {			
			public void actionPerformed(ActionEvent e) {
				
				if(textField.getText().toString().equals("")){
					JOptionPane.showMessageDialog(UpdatePrice2.this, "尚未選擇檔案!","上傳失敗",JOptionPane.WARNING_MESSAGE);
					int result=JOptionPane.showConfirmDialog(UpdatePrice2.this,"確定要結束程式嗎?","確認訊息",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
					if (result==JOptionPane.YES_OPTION) {System.exit(0);}
					}
				
				Connection conn;
				Statement statement;
				int newdate=0;
					try{
						conn=DriverManager.getConnection("jdbc:mariadb://120.105.161.89/MIMSystem","MIMSystem","MIMSystem");
						System.out.println("連接成功");
						statement = conn.createStatement();
						//BufferedReader brdFile = new BufferedReader(filePath);//bufferedReader
						BufferedReader brdFile =new BufferedReader((new FileReader(filePath)));
						String strLine=null ;
						try{
							while((strLine = brdFile.readLine())!=null){
							String []array=strLine.trim().split(",");//因為預設是用"，"分開所以用split切開存入字串陣列

							/*for(int i=0;i<array.length;i++){
								System.out.println(array[i]);
								
							}	*/		
							for(int j=0;j<array.length;j+=5){
								statement.executeUpdate("Insert Into Price(上傳日期,藥品唯一碼,健保碼,健保價,生效起日,生效迄日)VALUES('"+date+"','"+array[0]+"','"+array[j+1]+"','"+array[j+2]+"','"+array[j+3]+"','"+array[j+4]+"')");
								newdate++;
								System.out.println("newdate : "+newdate);
								System.out.println(array[j]);
							}
							};
							//System.out.println(array.length);	
						}catch (IOException SQLe) {
							// TODO Auto-generated catch block
							SQLe.printStackTrace();
							}
						
					}catch(SQLException SQLe){SQLe.printStackTrace();} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					if(newdate>0){
						JOptionPane.showMessageDialog(UpdatePrice2.this, "上傳資料成功 !","上傳成功",JOptionPane.INFORMATION_MESSAGE);
			    		Index ID;
						ID = new Index();
						ID.setVisible(true);
						dispose();
						}else{
							JOptionPane.showMessageDialog(UpdatePrice2.this, "上傳資料失敗 !","上傳失敗",JOptionPane.WARNING_MESSAGE);
							int result=JOptionPane.showConfirmDialog(UpdatePrice2.this,
									"確定要結束程式嗎?",
									"確認訊息",
									JOptionPane.YES_NO_OPTION,
									JOptionPane.WARNING_MESSAGE);
							if (result==JOptionPane.YES_OPTION) {
					    		Index ID;
								ID = new Index();
								ID.setVisible(true);
								dispose();
								}
							}
					//String

					}
			});
		updatebutton.setFont(new Font("標楷體", Font.PLAIN, 16));
		updatebutton.setBounds(262, 203, 126, 29);
		contentPane.add(updatebutton);
		
		JLabel updatefile = new JLabel("請選擇要上傳的檔案");
		updatefile.setFont(new Font("標楷體", Font.PLAIN, 26));
		updatefile.setBounds(148, 38, 240, 38);
		contentPane.add(updatefile);
		
		JButton btnNewButton = new JButton("返回主選單");
		btnNewButton.setFont(new Font("標楷體", Font.PLAIN, 16));
		btnNewButton.setBounds(126, 203, 126, 29);
		contentPane.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {	
	    		
    			Hidding.setVisible(true);
    			dispose();

	    	}
	        });
		
		
	}
	public String getDateTime(){
		SimpleDateFormat sdFormat = new SimpleDateFormat("yyyy/MM/dd ");
		Date date = new Date();
		String strDate = sdFormat.format(date);
		return strDate;
	}

}

