﻿
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFDataFormat;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.swing.JCheckBox;
import javax.swing.ImageIcon;
import javax.swing.JButton;

public class chooseOutPMD extends JFrame implements ItemListener {

	private JPanel contentPane;

	JCheckBox checkAll;
	// 標題列
	String[] cc1 = { "藥品唯一碼", "成份", "規格", "規格單位", "劑型", "健保核價單位", "包裝", "藥品代碼", "商品名", "管制藥等級", "成癮性麻醉藥品", "藥品或藥材",
			"ATCcode", "藥理分類", "藥品適應症", "藥理作用備註", "備註", "兒科水劑", "用藥指導單張編碼", "廠牌", "藥品許可證字號" };
	JCheckBox checkBoxArray[];// checkbox陣列
	private String[] message = new String[1];
	private int[] num = new int[1];
	

	//
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					chooseOutPMD frame = new chooseOutPMD(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public chooseOutPMD(Index index) {
		final Index Hidding = index;
		setTitle("產生西藥品項表");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 674, 653);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel titleLabel = new JLabel("產生西藥品項表");// LOGO
		titleLabel.setFont(new Font("標楷體", Font.PLAIN, 20));
		titleLabel.setBounds(165, 10, 182, 38);
		contentPane.add(titleLabel);
		message = new String[cc1.length];
		num = new int[cc1.length];

		JLabel Qlabel = new JLabel("請選擇欲產生檔案之欄位：");// LOGO
		Qlabel.setFont(new Font("標楷體", Font.PLAIN, 15));
		Qlabel.setBounds(25, 67, 182, 25);
		contentPane.add(Qlabel);

		checkAll = new JCheckBox("全選");// 全選checkBox
		checkAll.setFont(new Font("標楷體", Font.PLAIN, 15));
		checkAll.setBounds(23, 106, 97, 23);
		contentPane.add(checkAll);
		checkAll.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				for (JCheckBox cb : checkBoxArray) {
					cb.setSelected(checkAll.isSelected());
				}
			}
		});
		
		JLabel lblNewLabel = new JLabel("");// 醫院LOGO
		java.net.URL img = Index.class.getResource("image/MIM.png");
		lblNewLabel.setIcon(new ImageIcon(img));
		lblNewLabel.setBounds(488, 10, 160, 113);
		contentPane.add(lblNewLabel);
		
		System.out.println("長度:" + cc1.length / 2);
		checkBoxArray = new JCheckBox[cc1.length];
		int col2 = 0;// 放入所有checkbox選項
		int col22 = 0;
		// 23, 106, 97, 23

		for (int i = 0; i < cc1.length; i++) {
			if (i >= cc1.length / 2) {
				checkBoxArray[i] = new JCheckBox(cc1[i]);
				contentPane.add(checkBoxArray[i]);
				checkBoxArray[i].setBounds(328, 144 + 40 * col2, 149, 23);
				checkBoxArray[i].setFont(new Font("標楷體", Font.PLAIN, 15));
				checkBoxArray[i].addItemListener(this);
				System.out.println("test" + col2);
				col2++;
			} else {
				checkBoxArray[i] = new JCheckBox(cc1[i]);
				contentPane.add(checkBoxArray[i]);
				checkBoxArray[i].setBounds(23, 144 + 40 * i, 149, 23);
				checkBoxArray[i].setFont(new Font("標楷體", Font.PLAIN, 15));
				checkBoxArray[i].addItemListener(this);
				col22++;
			}
		}

		// 取時間
		String df1 = new SimpleDateFormat("yyyy-MM-dd").format(Calendar.getInstance().getTime());// 產生系統日期
		System.out.println(df1);

		/*
		 * 測試checkBox位置 JCheckBox chckbxNewCheckBox = new JCheckBox(
		 * "New check box"); chckbxNewCheckBox.setFont(new Font("標楷體",
		 * Font.PLAIN, 15)); chckbxNewCheckBox.setBounds(23, 144, 149, 23);
		 * contentPane.add(chckbxNewCheckBox);
		 * 
		 * JCheckBox chckbxNewCheckBox_1 = new JCheckBox("New check box");
		 * chckbxNewCheckBox_1.setFont(new Font("標楷體", Font.PLAIN, 15));
		 * chckbxNewCheckBox_1.setBounds(328, 144, 149, 23);
		 * contentPane.add(chckbxNewCheckBox_1);
		 */

		JButton button = new JButton("產生西藥品項檔");// Button
		button.setFont(new Font("標楷體", Font.PLAIN, 15));
		button.setBounds(499, 563, 149, 41);
		contentPane.add(button);
		button.addActionListener(new ActionListener() {
			private String sI;
			private String iI;
			private Object[][] data = new Object[1][];
			private int numberOfColumns = 0;
			private int numberOfRows = 0;
			private String[] tenderNum;
			private String[] columnNames = new String[1];
			public void actionPerformed(ActionEvent e) {
				Connection conn = null;
				Statement statement;
				ResultSet rs;
				ResultSetMetaData rsMetaData;
				int order = 0;////每次按按鈕會重新計算，就不會累加
				int count = 0;
				final String dateT = df1;// 取得時間

				try {

					Class.forName("org.mariadb.jdbc.Driver");
					System.out.println("資料庫連結成功");
					conn = DriverManager.getConnection("jdbc:mariadb://lots.im.nuu.edu.tw/MIMSystem", "MIMSystem",
							"MIMSystem");
					System.out.println("連接成功MySQL");
					statement = conn.createStatement();

					String sql = "SELECT * FROM `Medicine`  ";// 欄位資料
					System.out.print("取欄位名稱:" + sql);

					// DB取欄位名稱
					rs = statement.executeQuery("SELECT * FROM `Medicine` ");// 欄位資料

					rsMetaData = rs.getMetaData();
					numberOfColumns = rsMetaData.getColumnCount();
					columnNames = new String[numberOfColumns + 1];

					for (int i = 1; i <= numberOfColumns; i++) {
						System.out.printf("%s\t", rsMetaData.getColumnName(i));
						columnNames[i - 1] = rsMetaData.getColumnName(i);
					}

					boolean nodata = true;
					while (rs.next()) {
						nodata = false;
						for (int i = 1; i <= numberOfColumns; i++) {
							System.out.printf("%s\t", rs.getObject(i));
						}
						numberOfRows++;
					}

					// DB取欄位資料
					data = new Object[numberOfRows][numberOfColumns + 1];

					String sql3 = "SELECT * FROM `Medicine`";// 欄位資料

					System.out.println("取資料:" + sql3);
					rs = statement.executeQuery("SELECT * FROM `Medicine`");// 欄位資料

					while (rs.next()) {
						for (int i = 1; i <= numberOfColumns; i++) {
							if (rs.getObject(i) == null) {
								data[order][i - 1] = "";
							} else {
								data[order][i - 1] = rs.getObject(i);
							}

						}
						order++;
					}
					System.out.println("筆數:" + order);

					int selected = 0;
					for (int i = 0; i < cc1.length; i++) {
						if (checkBoxArray[i].isSelected() == false) {
							selected++;
						}
					}
					if (selected == cc1.length) {
						JOptionPane.showMessageDialog(null, "未勾選資料");
					} else {

						for (int i = 0; i < cc1.length; i++) {
							if (num[i] == 1) {
								count++;
								System.out.println(count);
							}
						}

						Object[][] data2 = new Object[data.length][count];

						int a = 0;
						for (int i = 0; i < cc1.length; i++) {
							if (num[i] == 1) {
								System.out.println("num[i]: " + i);
								for (int j = 0; j < data.length; j++) {
									System.out.println("j=" + j + " a=" + a + " i=" + i + "data2[j][a]" + data2[j][a]);
									data2[j][a] = data[j][i];
									System.out.println("現出原形吧:" + data2[j][a]);
								}
								a++;
							}

						}

						// Creat Excel檔案
						// 創建工作簿
						XSSFWorkbook wb = new XSSFWorkbook();
						// 創建工作表
						XSSFSheet sheet = wb.createSheet(dateT + "西藥品項表");
						for (int i = 0; i < 3; i++) {
							// 設置列寬
							sheet.setColumnWidth(i, 3000);
						}
						// 創建行
						XSSFRow row = sheet.createRow(0);
						row.setHeightInPoints(30);// 設置行高
						// 創建單元格
						XSSFCell cell = row.createCell(0);

						// String chi = "我生日";
						cell.setCellValue(dateT);
						// 合併單元格
						sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, count));
						// 創建行
						XSSFRow row1 = sheet.createRow(1);
						// 標題信息
						int col = 0;
						for (int i = 0; i < message.length; i++) {
							// 創建單元格
							if (num[i] != 1)
								continue;
							XSSFCell cell1 = row1.createCell(col);
							cell1.setCellValue(message[i]);
							col++;
						}

						// 模擬數據，實際情況下String[]多為實體bean
						List<String[]> list = new ArrayList<String[]>();

						for (int i = 0; i < data2.length; i++) {
							String[] d = new String[count];
							for (int j = 0; j < count; j++) {
								d[j] = data2[i][j].toString();// 把Object變成一個個string放入data,然後再把data放進list
							}
							list.add(d);
						}

						// 保留2位小數
						XSSFCellStyle cellStyle = wb.createCellStyle();
						XSSFDataFormat format = wb.createDataFormat();
						cellStyle.setDataFormat(format.getFormat("0.00"));

						// 循環賦值
						for (int i = 0; i < list.size(); i++) {
							// 創建行
							XSSFRow row2 = sheet.createRow(i + 2);
							// 創建單元格學號

							for (int q = 0; q < count; q++) {
								XSSFCell cell1 = row2.createCell(q);
								cell1.setCellValue(list.get(i)[q]);
							}

						}

						// 計算公式
						wb.getCreationHelper().createFormulaEvaluator().evaluateAll();

						File file = new File("C:/Users/yuqi/Desktop/" + dateT + " _西藥品項表file.xls");
						try {
							if (!file.exists()) {
								file.createNewFile();
							}

							FileOutputStream fileOut = new FileOutputStream(file);
							wb.write(fileOut);
							int result = JOptionPane.showConfirmDialog(null,
		 		    	               "產生西藥品項表檔案成功 ！",
		 		    	               "產生成功",
		 		    	               JOptionPane.DEFAULT_OPTION,
		 		    	               JOptionPane.PLAIN_MESSAGE);
	    		    	    if (result==0) {
					    		Index ID;
								ID = new Index();
								ID.setVisible(true);
								dispose();
	    		    	    }
							fileOut.close();
						} catch (IOException IO) {
							JOptionPane.showMessageDialog(null, "檔名重複", "警告", JOptionPane.WARNING_MESSAGE);
							IO.printStackTrace();
						}
					}
				} catch (NumberFormatException n) {
					JOptionPane.showMessageDialog(null, "未勾選欄位", "警告", JOptionPane.WARNING_MESSAGE);
					n.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});

		JButton button_1 = new JButton("回主選單");// 返回Button
		button_1.setFont(new Font("標楷體", Font.PLAIN, 15));
		button_1.setBounds(499, 510, 149, 41);
		contentPane.add(button_1);
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// Hidding.setVisible(true);
				dispose();
			}
		});

		/*
		 * 醫院LOGO JLabel lblNewLabel = new JLabel(""); java.net.URL img =
		 * Index.class.getResource("image/MIM.png"); lblNewLabel.setIcon(new
		 * ImageIcon(img)); lblNewLabel.setBounds(520, 10, 167, 118);
		 * getContentPane().add(lblNewLabel);
		 */
	}

	public void itemStateChanged(ItemEvent ie) {
		for (int i = 0; i < cc1.length; i++) {
			if (checkBoxArray[i].isSelected()) {
				message[i] = checkBoxArray[i].getText() + "  ";
				num[i] = 1;//1 = 被勾
				System.out.println(i);// print勾選位置
				System.out.println(message[i]);// print勾選內容
			} else {
				num[i] = 0;
			}
		}
	}
}
