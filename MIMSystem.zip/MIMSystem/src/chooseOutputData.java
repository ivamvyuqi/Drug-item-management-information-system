﻿

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFDataFormat;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JCheckBox;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.FlowLayout;

public class chooseOutputData extends JFrame implements ItemListener {

	private JPanel contentPane;
	JCheckBox checkBoxArray[];

	// 標題列
	String[] cc1;// = { "案號項次", "成份規格含量", "廠牌或同等品", "品質需求", "招標藥品單位", "招標藥品包裝",
					// "預算單價", "預估用量", "預估總價", "標案狀況" };
	private String tittle;
	private Object[][] content;
	private String[] message = new String[1];
	private int[] num = new int[1];
 
	JPanel panel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					chooseOutputData frame = new chooseOutputData("", "", "", null, null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public chooseOutputData(final String chinN, final String chargP, final String dataTime, String[] colName,
			Object data[][]) {
		setTitle("產生部分欄位資料檔案");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 768, 652);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		cc1 = colName;
		message = new String[cc1.length];
		num = new int[cc1.length];
		

		JLabel label = new JLabel("請選擇欲產生的欄位名稱:");//Logo 
		label.setBounds(130, 11, 230, 24);
		label.setFont(new Font("標楷體", Font.PLAIN, 20));
		contentPane.add(label);

		JLabel lblNewLabel = new JLabel("");// 醫院LOGO
		java.net.URL img = Index.class.getResource("image/MIM.png");
		lblNewLabel.setIcon(new ImageIcon(img));
		lblNewLabel.setBounds(582, 10, 160, 113);
		contentPane.add(lblNewLabel);

		JPanel panel_1 = new JPanel();//Panel
		panel_1.setBounds(365, 23, 1, 1);
		contentPane.add(panel_1);
		panel_1.setLayout(null);

		System.out.println("choose長度:" + cc1.length / 2);
		checkBoxArray = new JCheckBox[cc1.length];
		for (int i = 0; i < cc1.length/2+1; i++) {
			int w = 78;
			for (int j = 0; j < 2; j++) {
				if (j == 1)
					w = 369;
				if (i * 2 + j >= cc1.length)
					break;
				checkBoxArray[i * 2 + j] = new JCheckBox(cc1[i * 2 + j]);// cc1.length/2
				checkBoxArray[i * 2 + j].setBounds(w, 47 + 40 * i, 211, 23);
				checkBoxArray[i* 2 + j].setFont(new Font("標楷體", Font.PLAIN, 15));
				contentPane.add(checkBoxArray[i * 2 + j]);
				checkBoxArray[i * 2 + j].addItemListener(this);
				System.out.println("i*2+j="+(i*2+j));
			}
		}
		/*for (int i = 0; i < cc1.length; i++) {
			System.out.println("0913跑到這"+i);
			contentPane.add(checkBoxArray[i]);
			checkBoxArray[i].setFont(new Font("標楷體", Font.PLAIN, 15));
			checkBoxArray[i].addItemListener(this);
		}*/

		setContentPane(contentPane);

		JButton button = new JButton("產生部分欄位檔案"); // 產生部分欄位檔按鈕
		button.setBounds(531, 551, 211, 37);
		button.setFont(new Font("標楷體", Font.PLAIN, 15));
		contentPane.add(button);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int count = 0;//每次按按鈕會重新計算，就不會累加
				int selected = 0;
				for (int i = 0; i < cc1.length; i++) {
					if (checkBoxArray[i].isSelected() == false) {
						selected++;
					}
				}
				if (selected == cc1.length) {
					JOptionPane.showMessageDialog(null, "未勾選資料");
				} else {

					try {
						for (int i = 0; i < cc1.length; i++) {
							if (num[i] == 1) {
								count++;
								System.out.println("choose  count"+count);
							}
						}

						Object[][] data2 = new Object[data.length][count];

						int a = 0;
						for (int i = 0; i < cc1.length; i++) {
							if (num[i] == 1) {
								System.out.println("choose num[i]: " + i);
								for (int j = 0; j < data.length; j++) {
									System.out.println("j=" + j + " a=" + a + " i=" + i + "data2[j][a]" + data2[j][a]);
									data2[j][a] = data[j][i];
									System.out.println("choose 現出原形吧:" + data2[j][a]);
								}
								a++;
							}

						}

						// Creat Excel檔案
						// 創建工作簿
						XSSFWorkbook wb = new XSSFWorkbook();
						// 創建工作表
						XSSFSheet sheet = wb.createSheet(dataTime + "招標品項表");
						for (int i = 0; i < 3; i++) {
							// 設置列寬
							sheet.setColumnWidth(i, 3000);
						}
						// 創建行
						XSSFRow row = sheet.createRow(0);
						row.setHeightInPoints(30);// 設置行高
						// 創建單元格
						XSSFCell cell = row.createCell(0);

						// String chi = "我生日";
						cell.setCellValue(chinN);
						// 合併單元格
						sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, count));
						// 創建行
						XSSFRow row1 = sheet.createRow(1);
						// 標題信息
						int col = 0;
						for (int i = 0; i < message.length; i++) {
							// 創建單元格
							if (num[i] != 1)
								continue;
							XSSFCell cell1 = row1.createCell(col);
							cell1.setCellValue(message[i]);
							col++;
						}

						// 模擬數據，實際情況下String[]多為實體bean
						List<String[]> list = new ArrayList<String[]>();

						for (int i = 0; i < data2.length; i++) {
							String[] d = new String[count];
							for (int j = 0; j < count; j++) {
								d[j] = data2[i][j].toString();// 把Object變成一個個string放入data,然後再把data放進list
							}
							list.add(d);
						}

						// 保留2位小數
						XSSFCellStyle cellStyle = wb.createCellStyle();
						XSSFDataFormat format = wb.createDataFormat();
						cellStyle.setDataFormat(format.getFormat("0.00"));

						// 循環賦值
						for (int i = 0; i < list.size(); i++) {
							// 創建行
							XSSFRow row2 = sheet.createRow(i + 2);
							// 創建單元格學號
							
							//放入欄位資料
							for (int q = 0; q < count; q++) {
								XSSFCell cell1 = row2.createCell(q);
								cell1.setCellValue(list.get(i)[q]);
							}

						}

						// 計算公式
						wb.getCreationHelper().createFormulaEvaluator().evaluateAll();

						File file = new File(
								"C:/Users/yuqi/Desktop/" + dataTime + "_" + chinN + " _部分欄位file.xls");
						try {
							if (!file.exists()) {
								file.createNewFile();
							}

							FileOutputStream fileOut = new FileOutputStream(file);
							wb.write(fileOut);
							int result = JOptionPane.showConfirmDialog(null,
		 		    	               "產生部分欄位資料檔案成功 !",
		 		    	               "產生成功",
		 		    	               JOptionPane.DEFAULT_OPTION,
		 		    	               JOptionPane.PLAIN_MESSAGE);
	    		    	    if (result==0) {
					    		Index ID;
								ID = new Index();
								ID.setVisible(true);
								dispose();
	    		    	    }
							
							fileOut.close();
						} catch (IOException IO) {
							JOptionPane.showMessageDialog(null, "檔名重複", "警告", JOptionPane.WARNING_MESSAGE);
							System.out.println(IO);
						}
					} catch (NumberFormatException n) {
						JOptionPane.showMessageDialog(null, "未勾選欄位", "警告", JOptionPane.WARNING_MESSAGE);
						n.printStackTrace();
					}
				}
			}
		});
		
		this.setVisible(true);
	}

	public void itemStateChanged(ItemEvent ie) {

		for (int i = 0; i < cc1.length; i++) {
			System.out.println("choose勾選長度"+cc1.length);
			System.out.println("cl"+checkBoxArray.length+" "+i);
			if (checkBoxArray[i].isSelected()) {
				System.out.println("choose isSed:"+checkBoxArray[i].isSelected());
				message[i] = checkBoxArray[i].getText() + "  ";
				System.out.println("choose message:"+checkBoxArray[i]);
				num[i] = 1;
				System.out.println("choose勾選位置:"+i);// print勾選位置
				System.out.println("choose內容:"+message[i]);// print勾選內容

			} else {
				num[i] = 0;
			}
		}

	}
}
