﻿


import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class deadLineItem extends JFrame {
	deadLineItem clone = this;

	// 連結資料庫
	static final String DRIVER_NAME = "org.mariadb.jdbc.Driver";
	static final String DB_URL = "jdbc:odbc:GradesData";
	static final String url = "jdbc:mysql://120.105.161.89/MIMSystem";
	static final String username = "MIMSystem";
	static final String password = "MIMSystem";

	static int numberOfRows = 0;
	static int numberOfColumns = 0;
	static Object[][] data = new Object[1][];
	private JTextField chinNameText;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) throws SQLException {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					deadLineItem frame = new deadLineItem(null,null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public deadLineItem(Object[][] data1,Index index) {

		final Index Hidding = index;
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 703, 490);
		setTitle("產生招標品項表");
		getContentPane().setLayout(null);

		// 表格設置
		// ScrollPane for Table
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 132, 677, 249);
		getContentPane().add(scrollPane);

		// Table
		JTable table = new JTable(){
            public boolean isCellEditable(int row, int column){
            	if(column==0)return true;
            	else return false;}//表格不允许被编辑
           };
		scrollPane.setViewportView(table);

		// Model for Table 刪掉checkBox會不能用
		DefaultTableModel model = new DefaultTableModel() {

			public Class<?> getColumnClass(int column) {
				switch (column) {
				case 0:
					return Boolean.class;// 讓第一行顯示checkbox
				/*
				 * case 1: return String.class; case 2: return String.class;
				 * case 3: return String.class; case 4: return String.class;
				 * case 5: return String.class; case 6: return String.class;
				 */
				default:
					return String.class;
				}
			}
		};
		table.setModel(model);
		table.setFont(new Font("標楷體", Font.PLAIN, 16));
		table.setRowSelectionAllowed(false);
		table.getTableHeader().setReorderingAllowed(false);// 欄位拖動功能
		table.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
		table.setPreferredScrollableViewportSize(new Dimension(650, 70));

		String columnNames[] = { "選取", "案號", "案號項次", "成份規格含量", "標註用藥品或藥材", "廠牌或同等品", "品質需求", "招標藥品單位", "招標藥品包裝", "預算單價",
				"預估用量", "預估總價", "履約起日", "履約迄日", "履約期限", "標案狀況", "後續擴充期限", "後續擴充模式", "後續擴充金額", "後擴契約起日", "後擴契約迄日",
				"標購方式", "歷次廠商報價", "歷次廠商投標價", "強制結案" };

		// 放入欄位名稱
		for (int i = 0; i < columnNames.length; i++) {
			model.addColumn(columnNames[i]);
		}

		// Data Row 放入每筆資料
		for (int i = 0; i < data1.length; i++) {
			model.addRow(new Object[0]);
			for (int j = 0; j < data1[0].length; j++) {
				if (j == 0) {
					if (data1[i][0].toString().equals(true))
						model.setValueAt(true, i, j);
					else
						model.setValueAt(false, i, j);
				} else
					model.setValueAt(data1[i][j - 1], i, j);
			}
		}
		System.out.println("col長:" + columnNames.length + "data資料長度:" + data1[0].length);

		// Button區
		// Get Row Selected
		JButton newTenderButton = new JButton("產生新約");
		newTenderButton.setFont(new Font("標楷體", Font.PLAIN, 15));
		newTenderButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int ifCheck = 0;// 確定有沒有資料被勾選
				ArrayList<String[]> checkedData = new ArrayList<String[]>(); // 將被勾選的資料放入arrayList
				for (int i = 0; i < table.getRowCount(); i++) {// 檢查每列有沒有被勾
					// 成份及含量3、單位5、包裝6、廠牌9

					Boolean chked = Boolean.valueOf(table.getValueAt(i, 0).toString());// 判斷每列的第一欄是否被勾

					if (chked) {// 如果那列被勾，那列的第3,5,6,9行的資料會被放入checkedD的陣列
						ifCheck = 1;
						String[] checkedD = { table.getValueAt(i, 3).toString(), table.getValueAt(i, 4).toString(),
								table.getValueAt(i, 5).toString(), table.getValueAt(i, 6).toString(),
								table.getValueAt(i, 7).toString(), table.getValueAt(i, 8).toString(),
								table.getValueAt(i, 9).toString(), table.getValueAt(i, 10).toString(),
								table.getValueAt(i, 11).toString() };
						checkedData.add(checkedD);// 放完checkedD再放入checkedData的陣列

					}
				}
				if (ifCheck == 1) {// 如果有資料被勾就會跳到下一頁
					newTenders newT = new newTenders(clone, checkedData);
					newT.setVisible(true);
					dispose();
				} else {
					JOptionPane.showMessageDialog(null, "未勾選資料");
				}

			}

		});
		newTenderButton.setBounds(304, 403, 131, 32);
		getContentPane().add(newTenderButton);

		// 後續擴充Button
		JButton expandButton = new JButton("後續擴充");
		expandButton.setFont(new Font("標楷體", Font.PLAIN, 15));
		expandButton.setBounds(520, 403, 131, 32);
		expandButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int ifCheck = 0;// 確定有沒有資料被勾選
				ArrayList<String[]> checkedData = new ArrayList<String[]>(); // 將被勾選的資料放入arrayList
				for (int i = 0; i < table.getRowCount(); i++) {// 檢查每列有沒有被勾
					
					Boolean chked = Boolean.valueOf(table.getValueAt(i, 0).toString());// 判斷每列的第一欄是否被勾

					if (chked) {// 如果那列被勾，那列的第3,5,6,9行的資料會被放入checkedD的陣列
						ifCheck = 1;
						String[] checkedD = new String[columnNames.length-1];
						for (int j = 1; j < columnNames.length; j++) {
							checkedD[j-1] = table.getValueAt(i, j).toString() ;
							System.out.println("i:"+i+";j:"+j+" - "+table.getValueAt(i, j).toString());
						}
						checkedData.add(checkedD);// 放完checkedD再放入checkedData的陣列
						
					}
				}
				if (ifCheck == 1) {// 如果有資料被勾就會跳到下一頁
					expandTender newT = new expandTender(clone, checkedData);
					newT.setVisible(true);
					dispose();
				} else {
					JOptionPane.showMessageDialog(null, "未勾選資料");
				}

			}

		});

		getContentPane().add(expandButton);

		JLabel lowSaftyLabel = new JLabel("低於安全期限藥品項目");
		lowSaftyLabel.setFont(new Font("標楷體", Font.PLAIN, 20));
		lowSaftyLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lowSaftyLabel.setBounds(215, 41, 200, 42);
		getContentPane().add(lowSaftyLabel);

		/*JButton backButton = new JButton("返回主選單");
		backButton.setFont(new Font("標楷體", Font.PLAIN, 15));
		backButton.setBounds(90, 403, 131, 32);
		backButton.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {	

	    			Hidding.setVisible(true);
	    			dispose();

	    	}
	    });
		
		System.out.println("到這");
		getContentPane().add(backButton);*/
		
		JLabel lblNewLabel = new JLabel("");
		java.net.URL img = Index.class.getResource("image/MIM.png");
		lblNewLabel.setIcon(new ImageIcon(img));		
		lblNewLabel.setBounds(520, 10, 167, 118);
		getContentPane().add(lblNewLabel);
		
		JButton button = new JButton("回主選單");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
	    		Index ID;
				ID = new Index();
				ID.setVisible(true);
				dispose();
			}
		});
		button.setFont(new Font("標楷體", Font.PLAIN, 15));
		button.setBounds(69, 403, 131, 32);
		getContentPane().add(button);


	}
}
