﻿

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import javax.swing.DefaultCellEditor;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextField;

public class expandTender extends JFrame {

	private JPanel contentPane;
	private JTextField chinN;
	private JTextField chargeP;

	JTable table = new JTable();

	private static ArrayList<String[]> checkedData = new ArrayList<String[]>();
	expandTender clon = this;

	// 連接資料庫
	static final String url = "";
	static final String username = "MIMSystem"; // 用於連我們的DB
	static final String password = "MIMSystem";
	private Connection con;
	private Statement statement;
	private ResultSet rs;
	private ResultSetMetaData rsMetaData;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					expandTender frame = new expandTender(null, checkedData);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public expandTender(deadLineItem deadL, ArrayList<String[]> checkedD) {
		setTitle("產生招標品項表(後續擴充)");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 756, 594);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		final deadLineItem frame = deadL;
		// ArrayList<String[]> dataNew = checkedD;
		checkedData = checkedD;
		JPanel titlePanel = new JPanel();
		titlePanel.setBounds(5, 5, 735, 159);
		contentPane.add(titlePanel);
		titlePanel.setLayout(null);

		// Label Group
		JLabel functionLabel = new JLabel("產生招標品項表(後續擴充)");
		functionLabel.setFont(new Font("標楷體", Font.PLAIN, 20));
		functionLabel.setBounds(177, 47, 276, 32);
		titlePanel.add(functionLabel);

		JLabel chargePLabel = new JLabel("總務室承辦人：");
		chargePLabel.setFont(new Font("標楷體", Font.PLAIN, 15));
		chargePLabel.setBounds(252, 131, 120, 15);
		titlePanel.add(chargePLabel);

		JLabel chiNLabel = new JLabel("中文案名：");
		chiNLabel.setFont(new Font("標楷體", Font.PLAIN, 15));
		chiNLabel.setBounds(10, 126, 96, 25);
		titlePanel.add(chiNLabel);

		// 產生招標品項time

		String df2 = new SimpleDateFormat("yyyy-MM-dd").format(Calendar.getInstance().getTime());// 產生系統日期
		JLabel tenderDateTime = new JLabel("產生招標品項時間：" + df2.format(df2));// 產生招標品項時間的label
		tenderDateTime.setFont(new Font("標楷體", Font.PLAIN, 15));
		tenderDateTime.setBounds(492, 131, 233, 15);
		titlePanel.add(tenderDateTime);

		JLabel lblNewLabel = new JLabel("");
		java.net.URL img = Index.class.getResource("image/MIM.png");
		lblNewLabel.setIcon(new ImageIcon(img));
		lblNewLabel.setBounds(550, 0, 160, 113);
		titlePanel.add(lblNewLabel);

		// textfield
		chinN = new JTextField();
		chinN.setBounds(95, 128, 139, 23);
		titlePanel.add(chinN);
		chinN.setColumns(10);

		// 總務室承辦人text
		chargeP = new JTextField();
		chargeP.setBounds(359, 128, 122, 23);
		titlePanel.add(chargeP);
		chargeP.setColumns(10);

		// 表格Panel
		JPanel contentPanel = new JPanel();
		contentPanel.setBounds(5, 164, 735, 323);
		// Model for Table
		DefaultTableModel model = new DefaultTableModel() {

			/*
			 * public Class<?> getColumnClass(int column) { switch (column) {
			 * case 0: return Boolean.class; /* case 1: return String.class;
			 * case 2: return String.class; case 3: return String.class; case 4:
			 * return String.class; case 5: return String.class; case 6: return
			 * String.class;
			 * 
			 * default: return String.class; } }
			 */
		};

		// 放入title
		String columnNames[] = { "案號", "案號項次", "成份規格含量", "標註用藥品或藥材", "廠牌或同等品", "品質需求", "招標藥品單位", "招標藥品包裝", "預算單價",
				"預估用量", "預估總價", "履約起日", "履約迄日", "履約期限", "標案狀況", "後續擴充期限", "後續擴充模式", "後續擴充金額", "後擴契約起日", "後擴契約迄日",
				"標購方式", "歷次廠商報價", "歷次廠商投標價", "強制結案" };

		for (int i = 0; i < columnNames.length; i++) {
			model.addColumn(columnNames[i]);
		}

		// Data Row
		for (int i = 0; i < checkedData.size(); i++) {
			model.addRow(new Object[0]);// 列
			for (int j = 0; j < checkedData.get(0).length; j++) {
				model.setValueAt(checkedData.get(i)[j], i, j);// 欄
			}
		}
		// System.out.println("ROW:" + checkedData.get(0).length + ";COL:" +
		// columnNames.length);
		contentPane.add(contentPanel);
		contentPanel.setLayout(null);

		// ScrollPane for Table
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 715, 305);
		contentPanel.add(scrollPane);

		// Table

		scrollPane.setViewportView(table);
		table.setModel(model);
		table.setFont(new Font("標楷體", Font.PLAIN, 12));
		table.setRowSelectionAllowed(false);
		table.getTableHeader().setReorderingAllowed(false);// 欄位拖動功能
		table.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
		table.setPreferredScrollableViewportSize(new Dimension(650, 70));

		JPanel buttonPanel = new JPanel();
		buttonPanel.setBounds(5, 486, 735, 69);
		contentPane.add(buttonPanel);
		buttonPanel.setLayout(null);

		// button group
		JButton button = new JButton("預覽後續擴充");
		button.setFont(new Font("標楷體", Font.PLAIN, 15));
		button.setBounds(400, 20, 280, 39);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int empty = 0;// 判斷空格有無填寫
				int noDetect = 0;// 判斷字串裡面有無空白
				final String chNam = chinN.getText();// 中文案名
				final String charPer = chargeP.getText();// 總務室
				final String dateT = df2;// 取得時間

				int countSame = 0;

				// 把Table放入data2
				Object[][] data2 = new Object[table.getRowCount()][table.getColumnCount()];
				for (int i = 0; i < table.getRowCount(); i++) {
					for (int j = 0; j < table.getColumnCount(); j++) {
						data2[i][j] = table.getValueAt(i, j);
					}
				}

				// 判斷欄位是否空白
				try {
					for (int i = 0; i < table.getRowCount(); i++) {
						for (int j = i + 1; j < table.getRowCount(); j++) {
							// System.out.println("test泰國" + i + "太好吃" + j +
							// "太好玩" + countSame);
							if (data2[i][1].toString().equals(data2[j][1].toString())) {
								countSame++;
								// System.out.println("泰國" + i + "太好吃" + j +
								// "太好玩" + countSame);
							}
						}
					}
					if ("".equals(chNam.trim())) {// 判斷中文欄位是否空白
						empty++;
						JOptionPane.showMessageDialog(null, "中文案名為必填欄位", "警告", JOptionPane.WARNING_MESSAGE);

					} else {
						if (chNam != null && !chNam.equals("")) { // 判斷空白

							// 判斷string中空白
							int a;
							a = 0;
							char detect = ' ';
							a = chNam.indexOf(detect);
							if (a > 0) {
								JOptionPane.showMessageDialog(null, "中文案名不可有空白", "警告", JOptionPane.WARNING_MESSAGE);
								noDetect++;

							}
						}

					}

					// //判斷總務室承辦人欄位是否空白
					if ("".equals(charPer.trim())) {
						empty++;
						JOptionPane.showMessageDialog(null, "總務室承辦人為必填欄位", "警告", JOptionPane.WARNING_MESSAGE);

					} else {
						if (charPer != null && !charPer.equals("")) { // 判斷空白

							// 判斷string中空白
							int a;
							a = 0;
							char detect = ' ';
							a = charPer.indexOf(detect);
							if (a > 0) {
								JOptionPane.showMessageDialog(null, "總務室承辦人不可有空白", "警告", JOptionPane.WARNING_MESSAGE);
								noDetect++;
							}
						}
					}

					if (countSame == 0) {
					} else {
						JOptionPane.showMessageDialog(null, "案號項次不可重複", "警告", JOptionPane.WARNING_MESSAGE);
					}

					// 如果沒有空白跳到預覽頁面
					try {
						if (empty == 0 && noDetect == 0 && countSame == 0) {
							previewExpand preview = new previewExpand(clon, chNam, charPer, dateT, data2, columnNames);// data2是表格資料
							preview.setVisible(true);
							dispose();
						}
					} catch (NumberFormatException n) {
						JOptionPane.showMessageDialog(null, "輸入錯誤", "警告", JOptionPane.WARNING_MESSAGE);
						n.printStackTrace();
					}

				} catch (NumberFormatException n) {
					JOptionPane.showMessageDialog(null, "輸入錯誤", "警告", JOptionPane.WARNING_MESSAGE);
					n.printStackTrace();
				}
			}

		});
		buttonPanel.add(button);

		JButton button_1 = new JButton("返回勾選藥品頁面");
		button_1.setFont(new Font("標楷體", Font.PLAIN, 15));
		button_1.setBounds(78, 20, 280, 39);
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(true);
				dispose();
			}
		});
		buttonPanel.add(button_1);
	}
}
