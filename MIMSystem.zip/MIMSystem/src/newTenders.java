﻿

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.swing.SwingConstants;
import javax.swing.DefaultCellEditor;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextField;

public class newTenders extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private static ArrayList<String[]> checkedData = new ArrayList<String[]>();
	newTenders clone = this;

	static final String url = "";
	static final String username = "MIMSystem"; // 用於連我們的DB
	static final String password = "MIMSystem";
	private Connection con;
	private Statement statement;
	private ResultSet rs;
	private ResultSetMetaData rsMetaData;
	JTable table = new JTable();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					newTenders frame = new newTenders(null, checkedData);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public newTenders(deadLineItem deadL, ArrayList<String[]> checkedD) {
		setResizable(false);
		setTitle("產生招標品項表(新約)");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// 確認被勾的欄位
		checkedData = checkedD;
		String[] test;
		for (int i = 0; i < checkedData.size(); i++) {
			test = checkedData.get(i);
			System.out.println(test);
		}

		final deadLineItem frame = deadL;
		setBounds(100, 100, 741, 523);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		// 標題的Panel
		JPanel titlepanel = new JPanel();
		titlepanel.setBounds(5, 10, 720, 148);
		contentPane.add(titlepanel);
		titlepanel.setLayout(null);

		// 標題label
		JLabel newTenLogo = new JLabel("產生招標品項表(新約)");
		newTenLogo.setBounds(205, 47, 211, 24);
		newTenLogo.setHorizontalAlignment(SwingConstants.CENTER);
		newTenLogo.setFont(new Font("標楷體", Font.PLAIN, 20));
		titlepanel.add(newTenLogo);

		// 總務室承辦人label
		JLabel chargePerLabel = new JLabel("總務室承辦人：");
		chargePerLabel.setFont(new Font("標楷體", Font.PLAIN, 15));
		chargePerLabel.setBounds(258, 123, 108, 15);
		titlepanel.add(chargePerLabel);

		// 中文案名label
		JLabel chineseNamLabel = new JLabel("中文案名：");
		chineseNamLabel.setFont(new Font("標楷體", Font.PLAIN, 15));
		chineseNamLabel.setBounds(45, 123, 75, 15);
		titlepanel.add(chineseNamLabel);

		// 中文案名
		textField = new JTextField("1104藥品招標");
		textField.setBounds(132, 121, 96, 21);
		titlepanel.add(textField);
		textField.setColumns(10);

		// 總務室負責人
		textField_1 = new JTextField("大藥進組");
		textField_1.setBounds(376, 121, 96, 21);
		titlepanel.add(textField_1);
		textField_1.setColumns(10);

		// 取系統時間

		String df1 = new SimpleDateFormat("yyyy-MM-dd").format(Calendar.getInstance().getTime());// 產生系統日期
		System.out.println(df1);

		// 產生時間Label
		JLabel dateTenLabel = new JLabel("產生新約時間：" + df1.format(df1));
		dateTenLabel.setFont(new Font("標楷體", Font.PLAIN, 15));
		dateTenLabel.setBounds(507, 123, 203, 15);
		titlepanel.add(dateTenLabel);

		JLabel lblNewLabel = new JLabel("");// 醫院LOGO
		java.net.URL img = Index.class.getResource("image/MIM.png");
		lblNewLabel.setIcon(new ImageIcon(img));
		lblNewLabel.setBounds(550, 0, 160, 113);
		titlepanel.add(lblNewLabel);

		// 表格Panel
		JPanel contentPanel = new JPanel();
		contentPanel.setBounds(5, 156, 720, 278);

		// Model for Table
		DefaultTableModel model = new DefaultTableModel() {
			/*
			 * public Class<?> getColumnClass(int column) { switch (column) {
			 * case 0: return Boolean.class; /* case 1: return String.class;
			 * case 2: return String.class; case 3: return String.class; case 4:
			 * return String.class; case 5: return String.class; case 6: return
			 * String.class;
			 * 
			 * default: return String.class; } }
			 */
		};

		// 欄位名稱
		String columnNames[] = { "案號項次", "成份規格含量", "廠牌或同等品", "標註用藥品或藥材", "品質需求", "招標藥品單位", "招標藥品包裝", "預算單價", "預估用量",
				"預估總價" };

		// 測試用資料
		Object data[][] = { { "1", "123", "天祥", "無", "bag", "abag", "8", "400", "3200", "未決" },
				{ "2", "321", "翔天", "無", "bag", "ab", "7", "300", "2100", "未決" }, };// 測試用資料

		// ComboBox內容設定
		/*
		 * JComboBox countryCombo = new JComboBox(); countryCombo.addItem("未決");
		 * countryCombo.addItem("決");
		 */

		// 放入欄位名稱
		for (int i = 0; i < columnNames.length; i++) {
			model.addColumn(columnNames[i]);
		}

		// Data Row 放入每筆資料
		for (int i = 0; i < checkedData.size(); i++) {
			model.addRow(new Object[0]);// 列
			System.out.println("ROW:" + checkedData.size() + ";COL:" + checkedData.get(0).length);
			for (int j = 0; j < checkedData.get(0).length + 1; j++) {
				if (j == 10)
					break;
				if (j == 0) {
					model.setValueAt("", i, j);// 欄
				} else {
					model.setValueAt(checkedData.get(i)[j - 1], i, j);// 欄
				}

			}
		}
		contentPane.add(contentPanel);
		contentPanel.setLayout(null);

		// ScrollPane for Table
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 700, 247);
		contentPanel.add(scrollPane);

		// Table
		scrollPane.setViewportView(table);
		table.setModel(model);
		table.setFont(new Font("標楷體", Font.PLAIN, 12));
		table.setRowSelectionAllowed(false);
		table.getTableHeader().setReorderingAllowed(false);// 欄位拖動功能
		table.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
		table.setPreferredScrollableViewportSize(new Dimension(650, 70));

		// 於表格設定好後，才能加入ComboBox
		// TableColumn countryColumn =
		// table.getColumnModel().getColumn(columnNames.length - 1);
		// countryColumn.setCellEditor(new DefaultCellEditor(countryCombo));

		// 按鈕Panel
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBounds(5, 432, 720, 53);
		contentPane.add(buttonPanel);
		buttonPanel.setLayout(null);

		// 預覽招標品項表button
		JButton previewButton = new JButton("預覽招標品項表(新約)");
		previewButton.setBounds(396, 10, 234, 33);
		previewButton.setFont(new Font("標楷體", Font.PLAIN, 15));
		buttonPanel.add(previewButton);
		previewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int empty = 0;// 判斷空格有無填寫
				int noDetect = 0;// 判斷字串裡面有無空白
				final String chNam = textField.getText();// 中文案名
				final String charPer = textField_1.getText();// 總務室
				final String dateT = df1;// 取得時間
				int countSame = 0;

				System.out.println("在這裡:" + table.getRowCount() + "," + table.getColumnCount());
				// 把Table放入data2
				Object[][] data2 = new Object[table.getRowCount()][table.getColumnCount()];
				for (int i = 0; i < table.getRowCount(); i++) {
					for (int j = 0; j < table.getColumnCount(); j++) {
						data2[i][j] = table.getValueAt(i, j);
						System.out.println("NEWDATA" + i + "," + "j:" + data2[i][j]);
					}
				}

				// 判斷欄位是否空白
				try {
					for (int i = 0; i < table.getRowCount(); i++) {
						for (int j = i + 1; j < table.getRowCount(); j++) {
							// System.out.println("test泰國" + i + "太好吃" + j +
							// "太好玩" + countSame);
							if (data2[i][0].toString().equals(data2[j][0].toString())) {
								countSame++;
								// System.out.println("泰國" + i + "太好吃" + j +
								// "太好玩" + countSame);
							}
						}
					}
					if (countSame == 0) {
					} else {
						JOptionPane.showMessageDialog(null, "案號項次不可重複", "警告", JOptionPane.WARNING_MESSAGE);
					}
					if ("".equals(chNam.trim())) {// 判斷中文欄位是否空白
						empty++;
						JOptionPane.showMessageDialog(null, "中文案名為必填欄位", "警告", JOptionPane.WARNING_MESSAGE);

					} else {
						if (chNam != null && !chNam.equals("")) { // 判斷空白

							// 判斷string中空白
							int a;
							a = 0;
							char detect = ' ';
							a = chNam.indexOf(detect);
							if (a > 0) {
								JOptionPane.showMessageDialog(null, "中文案名不可有空白", "警告", JOptionPane.WARNING_MESSAGE);
								noDetect++;

							}
						}

					}

					// //判斷總務室承辦人欄位是否空白
					if ("".equals(charPer.trim())) {
						empty++;
						JOptionPane.showMessageDialog(null, "總務室承辦人為必填欄位", "警告", JOptionPane.WARNING_MESSAGE);

					} else {
						if (charPer != null && !charPer.equals("")) { // 判斷空白

							// 判斷string中空白
							int a;
							a = 0;
							char detect = ' ';
							a = charPer.indexOf(detect);
							if (a > 0) {
								JOptionPane.showMessageDialog(null, "總務室承辦人不可有空白", "警告", JOptionPane.WARNING_MESSAGE);
								noDetect++;

							}
						}
					}

					// 如果沒有空白跳到預覽頁面
					try {
						if (empty == 0 && noDetect == 0 && countSame == 0) {
							previewNewTender preview = new previewNewTender(clone, chNam, charPer, dateT, data2,
									columnNames);// data2是表格資料
							preview.setVisible(true);
							dispose();
						}
					} catch (NumberFormatException n) {
						JOptionPane.showMessageDialog(null, "輸入錯誤", "警告", JOptionPane.WARNING_MESSAGE);
						n.printStackTrace();
					}

				} catch (NumberFormatException n) {
					JOptionPane.showMessageDialog(null, "輸入錯誤", "警告", JOptionPane.WARNING_MESSAGE);
					n.printStackTrace();
				}
			}
		});

		JButton backCheckButton = new JButton("返回勾選藥品頁");// 返回勾選藥品頁面button
		backCheckButton.setBounds(53, 10, 234, 33);
		backCheckButton.setFont(new Font("標楷體", Font.PLAIN, 15));
		backCheckButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(true);
				dispose();
			}
		});
		buttonPanel.add(backCheckButton);
	}
}
