﻿
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFDataFormat;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;

public class previewExpand extends JFrame {

	private JPanel contentPane;
	previewExpand clone = this;

	static final String url = "jdbc:mariadb://120.105.161.89/MIMSystem";
	static final String username = "MIMSystem"; // 用於連我們的DB
	static final String password = "MIMSystem";
	private Connection con;
	private Statement statement;
	private ResultSet rs;
	private ResultSetMetaData rsMetaData;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					previewExpand frame = new previewExpand(null, "", "", "", null, null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public previewExpand(expandTender expTed, final String exp_chinNam, final String exp_charPerS,
			final String exp_dateTime, Object exp_data[][], String[] colName) {
		setTitle("預覽產生招標品項表(後續擴充)");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 704, 613);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		final expandTender frame = expTed;
		String[] columnName = colName;

		JPanel titlePanel = new JPanel();
		titlePanel.setBounds(5, 5, 678, 155);
		contentPane.add(titlePanel);
		titlePanel.setLayout(null);

		// Label group
		JLabel functionLabel = new JLabel("預覽產生招標品項表(後續擴充)");
		functionLabel.setFont(new Font("標楷體", Font.PLAIN, 20));
		functionLabel.setBounds(128, 46, 340, 37);
		titlePanel.add(functionLabel);

		JLabel chinLab = new JLabel("中文案名：" + exp_chinNam);
		chinLab.setFont(new Font("標楷體", Font.PLAIN, 15));
		chinLab.setBounds(10, 123, 188, 32);
		titlePanel.add(chinLab);

		JLabel charPLab = new JLabel("總務室承辦人：" + exp_charPerS);
		charPLab.setFont(new Font("標楷體", Font.PLAIN, 15));
		charPLab.setBounds(231, 123, 183, 32);
		titlePanel.add(charPLab);

		JLabel expanDateLab = new JLabel("產生後續擴充日期：" + exp_dateTime);
		expanDateLab.setFont(new Font("標楷體", Font.PLAIN, 15));
		expanDateLab.setBounds(440, 123, 228, 32);
		titlePanel.add(expanDateLab);

		JLabel lblNewLabel = new JLabel("");// 醫院LOGO
		java.net.URL img = Index.class.getResource("image/MIM.png");
		lblNewLabel.setIcon(new ImageIcon(img));
		lblNewLabel.setBounds(508, 10, 160, 113);
		titlePanel.add(lblNewLabel);

		JPanel contentPanel = new JPanel();
		contentPanel.setBounds(5, 158, 678, 351);
		contentPane.add(contentPanel);
		DefaultTableModel model = new DefaultTableModel() {

			/*
			 * public Class<?> getColumnClass(int column) { switch (column) {
			 * case 0: return Boolean.class; /* case 1: return String.class;
			 * case 2: return String.class; case 3: return String.class; case 4:
			 * return String.class; case 5: return String.class; case 6: return
			 * String.class;
			 * 
			 * default: return String.class; } }
			 */
		};

		// title
		for (int i = 0; i < columnName.length; i++) {
			model.addColumn(columnName[i]);
		}

		// Data Row
		for (int i = 0; i < exp_data.length; i++) {
			model.addRow(new Object[0]);
			for (int j = 0; j < exp_data[0].length; j++) {
				model.setValueAt(exp_data[i][j], i, j);
			}
		}

		// 表格的panel
		contentPane.add(contentPanel);
		contentPanel.setLayout(null);

		// ScrollPane for Table
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 637, 311);
		contentPanel.add(scrollPane);

		// Table
		JTable table = new JTable() {
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		scrollPane.setViewportView(table);

		table.setModel(model);
		table.setFont(new Font("標楷體", Font.PLAIN, 12));
		table.setRowSelectionAllowed(false);
		table.getTableHeader().setReorderingAllowed(false);// 欄位拖動功能
		table.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
		table.setPreferredScrollableViewportSize(new Dimension(650, 70));

		// Button Panel
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBounds(5, 510, 678, 59);
		contentPane.add(buttonPanel);
		buttonPanel.setLayout(null);

		// Button Group
		JButton expandButton = new JButton("後續擴充");
		expandButton.setFont(new Font("標楷體", Font.PLAIN, 15));
		expandButton.setBounds(424, 10, 209, 39);
		expandButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				Statement statement;
				int isUpdate = 0;
				int empty = 0;
				final String TNum = "";// 測試 因為產生新約還不確定案號跟管理費模式
				final String FeeType = "";// 測試
				String df = new SimpleDateFormat("yyyyMMddHHmmss").format(Calendar.getInstance().getTime());// 產生系統時間

				try {
					con = DriverManager.getConnection(url, username, password); // 呼叫Connection物件，進行資料庫連線
					System.out.println("資料庫連結成功");
					statement = con.createStatement();
					System.out.println("連接成功");

					// exp_chinNam exp_charPerS
					// 新增資料到資料庫
					isUpdate = statement.executeUpdate("INSERT into Tender(`流水號`, `中文案名`, `總務室承辦人`)VALUES('" + df
							+ "','" + exp_chinNam + "','" + exp_charPerS + "')");

					// 新增表格資料到資料庫
					for (int i = 0; i < table.getRowCount(); i++) {

						String sql = "INSERT into TenderDetail(`流水號`, `案號項次`, `成份規格含量`, `標註用藥品或藥材`, `廠牌或同等品`, `品質需求`, `招標藥品單位`, `招標藥品包裝`, `預算單價`, `預估用量`, `預估總價`, `履約起日`, `履約迄日`, `履約期限`, `標案狀況`, `後續擴充期限`, `後續擴充模式`, `後續擴充金額`, `後擴契約起日`, `後擴契約迄日`, `標購方式`, `歷次廠商報價`, `歷次廠商投標價`, `強制結案`)VALUES('"
								+ df;
						for (int j = 1; j < 24; j++) {
							sql += "','" + table.getValueAt(i, j);
						}
						sql += "' )";
						isUpdate = statement.executeUpdate(sql);
					}
					// Creat Excel檔案
					// 創建工作簿
					XSSFWorkbook wb = new XSSFWorkbook();
					// 創建工作表
					XSSFSheet sheet = wb.createSheet(df + "招標品項表");
					for (int i = 0; i < 3; i++) {
						// 設置列寬
						sheet.setColumnWidth(i, 3000);
					}
					// 創建行
					XSSFRow row = sheet.createRow(0);
					row.setHeightInPoints(30);// 設置行高
					// 創建單元格
					XSSFCell cell = row.createCell(0);
					cell.setCellValue(exp_chinNam);
					// 合併單元格
					sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, columnName.length));
					// 創建行
					XSSFRow row1 = sheet.createRow(1);

					// 標題信息
					// String[] titles = { "案號項次", "成份規格含量", "廠牌或同等品", "品質需求",
					// "招標藥品單位", "招標藥品包裝", "預算單價", "預估用量", "預估總價",
					// "標案狀況" };
					for (int i = 0; i < columnName.length; i++) {
						// 創建單元格
						XSSFCell cell1 = row1.createCell(i);
						cell1.setCellValue(columnName[i]);
					}

					// 模擬數據，實際情況下String[]多為實體bean
					List<String[]> list = new ArrayList<String[]>();
					int count = 0;
					for (int i = 0; i < exp_data.length; i++) {
						String[] d = new String[exp_data[0].length];
						for (int j = 0; j < d.length; j++) {
							d[j] = exp_data[i][j].toString();// 把Object變成一個個string放入data,然後再把data放進list
							// System.out.println("我是i:" + i + "我是j:" + d[j]);
							// System.out.println("我是i:" + i + "我是j:" +
							// exp_data[i][j].toString());
							count++;
						}
						list.add(d);
					}

					// 保留2位小數
					XSSFCellStyle cellStyle = wb.createCellStyle();
					XSSFDataFormat format = wb.createDataFormat();
					cellStyle.setDataFormat(format.getFormat("0.00"));

					// 循環賦值
					for (int i = 0; i < list.size(); i++) {
						// 創建行
						XSSFRow row2 = sheet.createRow(i + 2);
						// 創建單元格
						for (int q = 0; q < columnName.length; q++) {
							XSSFCell cell1 = row2.createCell(q);
							cell1.setCellValue(list.get(i)[q]);
						}

					}

					// 計算公式
					wb.getCreationHelper().createFormulaEvaluator().evaluateAll();

					// 建立excel檔案
					File file = new File("C:/Users/yuqi/Desktop/" + exp_dateTime + "_" + exp_chinNam
							+ " _招標品項表(後續擴充).xls");

					try {
						if (!file.exists()) {
							file.createNewFile();
						}

						FileOutputStream fileOut = new FileOutputStream(file);
						wb.write(fileOut);
						fileOut.close();
					} catch (IOException IO) {
						System.out.println(IO);
					}

					System.out.println("Success");

					// 如果新增成功到資料庫
					if (isUpdate > 0) {
						System.out.println("noUpdate: " + isUpdate);

						int mType = JOptionPane.QUESTION_MESSAGE;
						int oType = JOptionPane.YES_NO_CANCEL_OPTION;
						String[] options = { "需要", "不需要，結束此功能" };
						int opt = JOptionPane.showOptionDialog(null, "需要產生部分欄位檔案嗎?", "後續擴充成功", oType, mType, null,
								options, "接受");

						// 如果點選需要 及跳出選擇部分欄位頁面
						if (opt == JOptionPane.YES_OPTION) {
							try {
								chooseOutputData choose = new chooseOutputData(exp_chinNam, exp_charPerS, exp_dateTime,
										columnName, exp_data);
								System.out.println("成功囉");
								choose.setVisible(true);
								dispose();
							} catch (NumberFormatException n) {
								JOptionPane.showMessageDialog(null, "輸入錯誤", "警告", JOptionPane.WARNING_MESSAGE);
								n.printStackTrace();
							}

						}
						if (opt == JOptionPane.NO_OPTION) {
				    		Index ID;
							ID = new Index();
							ID.setVisible(true);
							dispose();
						}
					} else {

						JOptionPane.showMessageDialog(null, "產生新約失敗 !", "新增失敗", JOptionPane.WARNING_MESSAGE);
						int result = JOptionPane.showConfirmDialog(null, "確定要結束程式嗎?", "確認訊息", JOptionPane.YES_NO_OPTION,
								JOptionPane.WARNING_MESSAGE);
						if (result == JOptionPane.YES_OPTION) {
							System.exit(0);
						}
					}
				} catch (SQLException SQLe) {
					SQLe.printStackTrace();
				}

				// frame.setVisible(true);
				dispose();
			}
		});
		buttonPanel.add(expandButton);

		JButton backButton = new JButton(
				"\u8FD4\u56DE\u7522\u751F\u62DB\u6A19\u54C1\u9805\u8868(\u5F8C\u7E8C\u64F4\u5145)");
		backButton.setFont(new Font("標楷體", Font.PLAIN, 15));
		backButton.setBounds(93, 10, 280, 39);
		backButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				frame.setVisible(true);
				dispose();
			}
		});
		buttonPanel.add(backButton);

	}

}
