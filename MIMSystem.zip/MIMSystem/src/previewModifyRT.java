﻿

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class previewModifyRT extends JFrame {
	private String[] str = { "決標分項", "決標健保碼", "決標健保價", "決標折讓X%", "決標折讓Y%", "決標折讓Y%備註", "決標淨額", "決標日期", "健保調價承諾",
			"廠商統一編號", "履約起日", "藥品唯一碼" };
	private JPanel contentPane;
	private JTable vTableMedicine;
	private DefaultTableModel model;
	private JTextField infield[] = new JTextField[40];
	private String innew;
	private String[] inNew = new String[40];

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					previewModifyRT frame = new previewModifyRT(null, null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public previewModifyRT(modifyRT mRT, final String[] newdata) throws ClassNotFoundException {
		final previewModifyRT clone = this;
		final modifyRT Hidding = mRT;
		setTitle("預覽修改招標結果");
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 900, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		String[] newmd = newdata;

		JLabel pic1 = new JLabel("");
		pic1.setIcon(new ImageIcon("E:\\dl\\JAVA_workspace\\JAVA_workspace\\MIMSystem\\src\\MIM.png"));
		pic1.setHorizontalAlignment(SwingConstants.RIGHT);
		contentPane.add(pic1, BorderLayout.NORTH);

		JPanel panel_1 = new JPanel();
		panel_1.setPreferredSize(new Dimension(1200, 700));
		JScrollPane scrollPane = new JScrollPane(panel_1);
		contentPane.add(scrollPane, BorderLayout.CENTER);
		panel_1.setAutoscrolls(true);
		GridBagLayout gbl_panel_1 = new GridBagLayout();
		gbl_panel_1.columnWidths = new int[] { 0, 0 };
		gbl_panel_1.rowHeights = new int[] { 0, 0, 0 };
		gbl_panel_1.columnWeights = new double[] { 0.0, Double.MIN_VALUE };
		gbl_panel_1.rowWeights = new double[] { 0.0, 0.0, Double.MIN_VALUE };
		panel_1.setLayout(gbl_panel_1);

		scrollPane.setPreferredSize(new Dimension(900, 600));
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		contentPane.add(scrollPane, BorderLayout.CENTER);

		int a = 0;
		for (int i = 0; i < 3; i += 2) {
			for (int j = 0; j < 6; j++) {
				if (a == 12) {
					break;
				}
				JLabel field = new JLabel(str[a]);
				field.setFont(new Font("標楷體", Font.PLAIN, 15));
				GridBagConstraints strr = new GridBagConstraints();
				strr.gridx = i;
				strr.gridy = j;
				strr.gridwidth = 1;
				strr.gridheight = 1;
				strr.weightx = 0;
				strr.weighty = 0;
				strr.fill = GridBagConstraints.BOTH;
				strr.anchor = GridBagConstraints.NORTHWEST;
				panel_1.add(field, strr);

				a++;
			}
		}

		int b = 2;
		for (int i = 1; i < 4; i += 2) {
			for (int j = 0; j < 6; j++) {
				if (b == 14) {
					break;
				}
				infield[b] = new JTextField(newmd[b]);
				infield[b].setFont(new Font("標楷體", Font.PLAIN, 15));
				infield[b].setEditable(false);
				GridBagConstraints strr = new GridBagConstraints();
				strr.gridx = i;
				strr.gridy = j;
				strr.gridwidth = 1;
				strr.gridheight = 1;
				strr.weightx = 10;
				strr.weighty = 10;
				strr.fill = GridBagConstraints.BOTH;
				strr.anchor = GridBagConstraints.NORTHWEST;
				panel_1.add(infield[b], strr);

				b++;
			}
		}

		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);

		

		
		
		JPanel panel_2 = new JPanel();
		contentPane.add(panel_2, BorderLayout.NORTH);
		
		JLabel label = new JLabel("預覽修改招標結果");
		label.setFont(new Font("標楷體", Font.PLAIN, 20));
		panel_2.add(label);

		/*
		 JLabel lblNewLabel = new JLabel("");//LOGO 
		  java.net.URL img = Index.class.getResource("image/MIM.png"); 
		  lblNewLabel.setIcon(new ImageIcon(img)); lblNewLabel.setBounds(520, 10, 167, 118);
		  getContentPane().add(lblNewLabel);
		 */
		
		
		JButton btnBKNew = new JButton("返回修改");
		btnBKNew.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(btnBKNew);
		btnBKNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Hidding.setVisible(true);
				dispose();
			}
		});
		
		JButton btnCRNew = new JButton("確認修改");
		btnCRNew.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(btnCRNew);
		btnCRNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int c = 2;
				for (int i = 1; i < 4; i += 2) {
					for (int j = 0; j < 6; j++) {
						if (c == 14) {
							break;
						}
						GridBagConstraints strr = new GridBagConstraints();
						strr.gridx = i;
						strr.gridy = j;
						strr.gridwidth = 1;
						strr.gridheight = 1;
						strr.weightx = 10;
						strr.weighty = 10;
						System.out.println(c);
						innew = infield[c].getText();
						inNew[c] = innew;
						// strr.fill = GridBagConstraints.BOTH;
						// strr.anchor = GridBagConstraints.NORTHWEST;
						// panel_1.add(field, strr);
						c++;
					}
				}

				Connection conn = null;
				Statement statement;
				ResultSet rs;
				ResultSetMetaData rsMetaData;
				String k = "";
				int empty = 0;
				int noDetect = 0;

				try {
					Class.forName("org.mariadb.jdbc.Driver");
					System.out.println("資料庫連結成功");
					conn = DriverManager.getConnection("jdbc:mariadb://lots.im.nuu.edu.tw/MIMSystem", "MIMSystem",
							"MIMSystem");
					System.out.println("連接成功MySQL");
					statement = conn.createStatement();

					// 檢查sql語法
					/*
					 * String sql = "UPDATE Tender SET `案號` = '" + inNew[1]+
					 * "'WHERE Tender.`流水號` = '" + chooseTN + "'"; String sql2 =
					 * "UPDATE TenderDetail SET `案號項次` = '" + inNew[2] +
					 * "',`標註用藥品或藥材`='" + inNew[3] + "',`標註用藥品或藥材`='" + inNew[4]
					 * + "',`廠牌或同等品` = '" + inNew[5] + "', `品質需求` = '" +
					 * inNew[6] + "', `履約起日`='" + inNew[7] + "', `履約迄日`='" +
					 * inNew[8] + "', `履約期限`='" + inNew[9] + "',`招標藥品單位` = '" +
					 * inNew[10] + "',`招標藥品包裝` = '" + inNew[11] + "',`預算單價` = '"
					 * + inNew[12] + "',`預估用量` = '" + inNew[13] + "', `預估總價`='"
					 * + inNew[14] + "', `標案狀況`='" + inNew[15] + "', `後續擴充期限`='"
					 * + inNew[16] + "', `後續擴充模式`='" + inNew[17] +
					 * "', `後續擴充金額`='" + inNew[18] + "', `後擴契約起日`='" + inNew[19]
					 * + "', `後擴契約迄日`='" + inNew[20] + "', `標購方式`='" + inNew[21]
					 * + "', `歷次廠商報價`='" + inNew[22] + "', `歷次廠商投標價`='" +
					 * inNew[23] + "', `強制結案`='" + inNew[24] +
					 * "'WHERE TenderDetail.`流水號` = '" + chooseTN + "'"; String
					 * sql3 = "UPDATE TenderResult SET `案號項次` = '" + inNew[2] +
					 * "',`決標分項` = '" + inNew[25] + "',`決標健保碼`='" + inNew[26] +
					 * "',`決標折讓X%` = '" + inNew[27] + "', `決標折讓Y%` = '" +
					 * inNew[28] + "', `決標折讓Y%備註`='" + inNew[29] + "', `決標淨額`='"
					 * + inNew[30] + "',`決標日期` = '" + inNew[31] +
					 * "',`健保調價承諾A%` = '" + inNew[32] + "',`廠商統一編號` = '" +
					 * inNew[33] + "',`藥品唯一碼` = '" + inNew[34] +
					 * "'WHERE `流水號` = '" + chooseTN + "'";
					 * System.out.println("Tender:"+sql);
					 * System.out.println("TenderDetail:"+sql2);
					 * System.out.println("TenderResult:"+sql3);
					 */
					// 修改Tender案號
					// statement.executeUpdate("UPDATE Tender SET `案號` = '" +
					// inNew[0]+ "'WHERE Tender.`流水號` = '" + chooseTN + "'");

					// 修改TenderDetail
					/*
					 * statement.executeUpdate(
					 * "UPDATE TenderDetail SET `案號項次` = '" + inNew[1] +
					 * "',`標註用藥品或藥材`='" + inNew[2] + "',`標註用藥品或藥材`='" + inNew[3]
					 * + "',`廠牌或同等品` = '" + inNew[4] + "', `品質需求` = '" +
					 * inNew[5] + "', `履約起日`='" + inNew[6] + "', `履約迄日`='" +
					 * inNew[7] + "', `履約期限`='" + inNew[8] + "',`招標藥品單位` = '" +
					 * inNew[9] + "',`招標藥品包裝` = '" + inNew[10] + "',`預算單價` = '"
					 * + inNew[11] + "',`預估用量` = '" + inNew[12] + "', `預估總價`='"
					 * + inNew[13] + "', `標案狀況`='" + inNew[14] + "', `後續擴充期限`='"
					 * + inNew[15] + "', `後續擴充模式`='" + inNew[16] +
					 * "', `後續擴充金額`='" + inNew[17] + "', `後擴契約起日`='" + inNew[18]
					 * + "', `後擴契約迄日`='" + inNew[19] + "', `標購方式`='" + inNew[20]
					 * + "', `歷次廠商報價`='" + inNew[21] + "', `歷次廠商投標價`='" +
					 * inNew[22] + "', `強制結案`='" + inNew[23] +
					 * "'WHERE TenderDetail.`流水號` = '" + chooseTN + "'");
					 */
					//檢查廠商編號
					rs = statement.executeQuery("SELECT `廠商統一編號` FROM `FirmData` WHERE `廠商統一編號`='" + inNew[11] + "'");// '9
					if (!rs.next()) {
						JOptionPane.showMessageDialog(null, "查無此廠商統一編號 !", "請重新輸入", JOptionPane.INFORMATION_MESSAGE);
						noDetect++;
					}

					// 檢查藥品唯一馬
					rs = statement.executeQuery("SELECT `藥品唯一碼` FROM `Medicine` WHERE `藥品唯一碼` ='" + inNew[13] + "'");// '9
					// 11
					if (!rs.next()) {
						JOptionPane.showMessageDialog(null, "查無此藥品唯一碼 !", "請重新輸入", JOptionPane.INFORMATION_MESSAGE);
						noDetect++;
					}

					if ("".equals(inNew[2].toString().trim())) {// 判斷決標分項是否空白
						empty++;
						JOptionPane.showMessageDialog(null, "決標分項為必填欄位", "警告", JOptionPane.WARNING_MESSAGE);

					} else {
						if (inNew[2].toString() != null && !inNew[2].toString().equals("")) { // 判斷空白

							// 判斷string中空白
							int a;
							a = 0;
							char detect = ' ';
							a = inNew[2].indexOf(detect);
							if (a > 0) {
								JOptionPane.showMessageDialog(null, "決標分項不可有空白", "警告", JOptionPane.WARNING_MESSAGE);
								noDetect++;

							}
						}

					}

					// 判斷決標日
					if ("".equals(inNew[9].toString().trim())) {// 判斷決標日是否空白
						empty++;
						JOptionPane.showMessageDialog(null, "決標日期為必填欄位", "警告", JOptionPane.WARNING_MESSAGE);

					} else {
						if (inNew[9].toString() != null && !inNew[9].toString().equals("")) { // 判斷空白

							// 判斷string中空白
							int a;
							a = 0;
							char detect = ' ';
							a = inNew[9].indexOf(detect);
							if (a > 0) {
								JOptionPane.showMessageDialog(null, "決標日期不可有空白", "警告", JOptionPane.WARNING_MESSAGE);
								noDetect++;

							}
						}

					}

					// 判斷履約起日
					if ("".equals(inNew[12].toString().trim())) {// 判斷履約起日是否空白
						empty++;
						JOptionPane.showMessageDialog(null, "履約起日為必填欄位", "警告", JOptionPane.WARNING_MESSAGE);

					} else {
						if (inNew[12].toString() != null && !inNew[12].toString().equals("")) { // 判斷空白

							// 判斷string中空白
							int a;
							a = 0;
							char detect = ' ';
							a = inNew[12].indexOf(detect);
							if (a > 0) {
								JOptionPane.showMessageDialog(null, "履約起日不可有空白", "警告", JOptionPane.WARNING_MESSAGE);
								noDetect++;

							}
						}

					}
					
					
					// 修改TenderResult
					statement.executeUpdate("UPDATE TenderResult SET `決標分項` = '" + inNew[2] + "',`決標健保碼`='" + inNew[3]
							+ "',`決標健保價` = '" + inNew[4] + "',`決標折讓X%` = '" + inNew[5] + "', `決標折讓Y%` = '" + inNew[6]
							+ "', `決標折讓Y%備註`='" + inNew[7] + "', `決標淨額`='" + inNew[8] + "',`決標日期` = '" + inNew[9]
							+ "',`健保調價承諾A%` = '" + inNew[10] + "',`廠商統一編號` = '" + inNew[11] + "',`履約起日` = '" + inNew[12]
							+ "',`藥品唯一碼` = '" + inNew[13] + "'WHERE `流水號` = '" + newmd[0]
							+ "'AND TenderResult.`案號項次` = '" + newmd[1] + "'");

					statement.close();
					conn.close();

					int result = JOptionPane.showConfirmDialog(null, "修改成功！", "修改招標結果", JOptionPane.DEFAULT_OPTION,
							JOptionPane.PLAIN_MESSAGE);
					if (result == 0) {
			    		Index ID;
						ID = new Index();
						ID.setVisible(true);
						dispose();
					}

				} catch (ClassNotFoundException classNotFound) {// 找不到JDBC
																// Driver
					classNotFound.printStackTrace();
				} catch (SQLException sqlException) {// 資料庫操作發生錯誤
					sqlException.printStackTrace();
				}

			}
		});
	}

}
