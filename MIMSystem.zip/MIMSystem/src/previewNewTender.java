﻿

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFDataFormat;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;

public class previewNewTender extends JFrame {

	private JPanel contentPane;
	previewNewTender clone = this;

	// 資料庫連線
	static final String url = "jdbc:mariadb://120.105.161.89/MIMSystem";
	static final String username = "MIMSystem"; // 用於連我們的DB
	static final String password = "MIMSystem";
	private Connection con;
	private Statement statement;
	private ResultSet rs;
	private ResultSetMetaData rsMetaData;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					previewNewTender frame = new previewNewTender(null, "", "", "", null, null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public previewNewTender(newTenders newTen, final String chinNam, final String charPerS, final String dateTime,
			Object data[][], String[] colName) {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 691, 551);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		// 標頭Panel
		JPanel titalPanel = new JPanel();
		titalPanel.setBounds(5, 5, 660, 151);
		contentPane.add(titalPanel);
		titalPanel.setLayout(null);
		final newTenders frame = newTen;// newTenders
		String[] columnName = colName;

		// 中文案名label
		JLabel chineseNamLabel = new JLabel("中文案名：" + chinNam);
		chineseNamLabel.setFont(new Font("標楷體", Font.PLAIN, 15));
		chineseNamLabel.setBounds(36, 121, 187, 24);
		titalPanel.add(chineseNamLabel);

		// 預覽產生新約label
		JLabel titlelabel = new JLabel("預覽產生招標品項表(新約)");
		titlelabel.setBounds(157, 50, 290, 24);
		titlelabel.setFont(new Font("標楷體", Font.PLAIN, 20));
		titalPanel.add(titlelabel);

		// 總務室承辦人label
		JLabel chargePersonlabel_1 = new JLabel("總務室承辦人：" + charPerS);
		chargePersonlabel_1.setFont(new Font("標楷體", Font.PLAIN, 15));
		chargePersonlabel_1.setBounds(235, 121, 202, 24);
		titalPanel.add(chargePersonlabel_1);

		// 產生新約時間label
		JLabel DateNewTlabel_2 = new JLabel("產生新約時間：" + dateTime);
		DateNewTlabel_2.setFont(new Font("標楷體", Font.PLAIN, 15));
		DateNewTlabel_2.setBounds(447, 126, 203, 15);
		titalPanel.add(DateNewTlabel_2);

		JLabel lblNewLabel = new JLabel("");
		java.net.URL img = Index.class.getResource("image/MIM.png");
		lblNewLabel.setIcon(new ImageIcon(img));
		lblNewLabel.setBounds(483, 0, 167, 116);
		titalPanel.add(lblNewLabel);

		// 放table的panel
		JPanel tablePanel = new JPanel();
		tablePanel.setBounds(5, 166, 660, 274);
		contentPane.add(tablePanel);

		DefaultTableModel model = new DefaultTableModel() {
			/*
			 * public Class<?> getColumnClass(int column) { switch (column) {
			 * case 0: return Boolean.class; /* case 1: return String.class;
			 * case 2: return String.class; case 3: return String.class; case 4:
			 * return String.class; case 5: return String.class; case 6: return
			 * String.class;
			 * 
			 * default: return String.class; } }
			 */
		};

		// 放入title
		for (int i = 0; i < columnName.length; i++) {
			model.addColumn(columnName[i]);
		}

		// Data Row放入資料row
		for (int i = 0; i < data.length; i++) {
			model.addRow(new Object[0]);
			for (int j = 0; j < data[0].length; j++) {
				model.setValueAt(data[i][j], i, j);
			}
		}

		// 表格的panel
		contentPane.add(tablePanel);
		tablePanel.setLayout(null);

		// 設置table
		// ScrollPane for Table
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 640, 254);
		tablePanel.add(scrollPane);

		// Table
		JTable table = new JTable() {
			public boolean isCellEditable(int row, int column) {
				return false;
			}// 不讓表格被編輯
		};
		scrollPane.setViewportView(table);
		table.setModel(model);
		table.setFont(new Font("標楷體", Font.PLAIN, 12));
		table.setRowSelectionAllowed(false);
		table.getTableHeader().setReorderingAllowed(false);// 欄位拖動功能
		table.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
		table.setPreferredScrollableViewportSize(new Dimension(650, 70));

		// button的panel
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBounds(5, 450, 660, 63);
		contentPane.add(buttonPanel);
		buttonPanel.setLayout(null);

		JButton checkNewButton = new JButton("確定新增"); // 確定新增button
		checkNewButton.setFont(new Font("標楷體", Font.PLAIN, 15));
		checkNewButton.setBounds(416, 10, 169, 33);
		checkNewButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				Statement statement;
				int isUpdate = 0;
				int empty = 0;
				String df = new SimpleDateFormat("yyyyMMddHHmmss").format(Calendar.getInstance().getTime());// 流水號
				String tenderNum = df;
				// 產生系統時間
				// final String TNum = "";// 測試 因為產生新約還不確定案號跟管理費模式
				// final String FeeType = "";// 測試
				try {
					con = DriverManager.getConnection(url, username, password); // 呼叫Connection物件，進行資料庫連線
					System.out.println("資料庫連結成功");
					statement = con.createStatement();
					System.out.println("連接成功");

					try {
						System.out.println(chinNam);
						System.out.println(charPerS);
						System.out.println(dateTime);

						// 新增資料到資料庫
						isUpdate = statement.executeUpdate("INSERT into Tender(流水號, 中文案名, 總務室承辦人)VALUES('" + tenderNum
								+ "','" + chinNam + "','" + charPerS + "')");

						// 新增表格資料到資料庫
						for (int i = 0; i < table.getRowCount(); i++) {
							isUpdate = statement.executeUpdate(
									"INSERT into TenderDetail(`流水號`, `案號項次`, `成份規格含量`, `標註用藥品或藥材`, `廠牌或同等品`, `品質需求`, `招標藥品單位`, `招標藥品包裝`, `預算單價`, `預估用量`, `預估總價`)VALUES('"
											+ tenderNum + "','" + table.getValueAt(i, 0) + "','"
											+ table.getValueAt(i, 1) + "','" + table.getValueAt(i, 2) + "','"
											+ table.getValueAt(i, 3) + "' ,'" + table.getValueAt(i, 4) + "','"
											+ table.getValueAt(i, 5) + "','" + table.getValueAt(i, 6) + "','"
											+ table.getValueAt(i, 7) + "','" + table.getValueAt(i, 8) + "','"
											+ table.getValueAt(i, 9) + "' )");
							// System.out.println(table.getValueAt(i, j));
						}

						// Creat Excel檔案
						// 創建工作簿
						XSSFWorkbook wb = new XSSFWorkbook();
						// 創建工作表
						XSSFSheet sheet = wb.createSheet(dateTime + "招標品項表");
						for (int i = 0; i < 3; i++) {
							// 設置列寬
							sheet.setColumnWidth(i, 3000);
						}
						// 創建行
						XSSFRow row = sheet.createRow(0);
						row.setHeightInPoints(30);// 設置行高
						// 創建單元格
						XSSFCell cell = row.createCell(0);
						cell.setCellValue(chinNam);
						// 合併單元格
						sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 9));
						// 創建行
						XSSFRow row1 = sheet.createRow(1);

						// 標題信息
						// String[] titles = { "案號項次", "成份規格含量", "廠牌或同等品",
						// "品質需求", "招標藥品單位", "招標藥品包裝", "預算單價", "預估用量",
						// "預估總價", "標案狀況" };
						for (int i = 0; i < columnName.length; i++) {
							// 創建單元格
							XSSFCell cell1 = row1.createCell(i);
							cell1.setCellValue(columnName[i]);
						}

						// 模擬數據，實際情況下String[]多為實體bean
						List<String[]> list = new ArrayList<String[]>();

						for (int i = 0; i < data.length; i++) {
							String[] d = new String[data[0].length];
							//System.out.println("dddddddd:" + d[i].toString());
							for (int j = 0; j < d.length; j++) {
								d[j] = data[i][j].toString();// 把Object變成一個個string放入data,然後再把data放進list
								System.out.println("我是i:" + i + "我是j:" + d[j]);
								// System.out.println("我是i:" + i + "我是j:" +
								// data[i][j].toString());
							}
							list.add(d);
							// System.out.println("list.add:" + list.add(d));
						}

						// 保留2位小數
						XSSFCellStyle cellStyle = wb.createCellStyle();
						XSSFDataFormat format = wb.createDataFormat();
						cellStyle.setDataFormat(format.getFormat("0.00"));

						// 循環賦值
						for (int i = 0; i < list.size(); i++) {
							// 創建行
							XSSFRow row2 = sheet.createRow(i + 2);
							// 創建單元格
							XSSFCell cell1 = row2.createCell(0);
							cell1.setCellValue(list.get(i)[0]);
							// 創建單元格
							XSSFCell cell2 = row2.createCell(1);
							cell2.setCellValue(list.get(i)[1]);
							// 創建單元格
							XSSFCell cell3 = row2.createCell(2);
							cell3.setCellValue(list.get(i)[2]);
							// 創建單元格
							XSSFCell cell4 = row2.createCell(3);
							cell4.setCellValue(list.get(i)[3]);
							// 創建單元格
							XSSFCell cell5 = row2.createCell(4);
							cell5.setCellValue(list.get(i)[4]);
							// 創建單元格
							XSSFCell cell6 = row2.createCell(5);
							cell6.setCellValue(list.get(i)[5]);
							XSSFCell cell7 = row2.createCell(6);
							cell7.setCellValue(list.get(i)[6]);
							XSSFCell cell8 = row2.createCell(7);
							cell8.setCellValue(list.get(i)[7]);
							XSSFCell cell9 = row2.createCell(8);
							cell9.setCellValue(list.get(i)[8]);
							XSSFCell cell10 = row2.createCell(9);
							cell10.setCellValue(list.get(i)[9]);
						}

						// 計算公式
						wb.getCreationHelper().createFormulaEvaluator().evaluateAll();

						// 建立excel檔案路徑
						File file = new File(
								"C:/Users/yuqi/Desktop/" + dateTime + "_" + chinNam + " 招標品項表(新約).xls");
						try {
							if (!file.exists()) {
								file.createNewFile();
							}

							FileOutputStream fileOut = new FileOutputStream(file);
							wb.write(fileOut);
							fileOut.close();
						} catch (IOException IO) {
							System.out.println(IO);
						}

						System.out.println("Success");
					} catch (SQLException sqlException) {
						sqlException.printStackTrace();
					}

					// 如果新增成功到資料庫
					if (isUpdate > 0) {
						System.out.println("noUpdate: " + isUpdate);

						int mType = JOptionPane.QUESTION_MESSAGE;
						int oType = JOptionPane.YES_NO_CANCEL_OPTION;
						String[] options = { "需要", "不需要，結束此功能" };
						int opt = JOptionPane.showOptionDialog(null, "需要產生部分欄位檔案嗎?", "產生新約成功", oType, mType, null, options,
								"接受");

						// 如果點選需要 及跳出選擇部分欄位頁面
						if (opt == JOptionPane.YES_OPTION) {
							try {
								chooseOutputData choose = new chooseOutputData(chinNam, charPerS, dateTime, columnName,
										data);
								System.out.println("成功囉");
								dispose();
								// choose.setVisible(true);
							} catch (NumberFormatException n) {
								JOptionPane.showMessageDialog(null, "輸入錯誤", "警告", JOptionPane.WARNING_MESSAGE);
								n.printStackTrace();
							}

						}
						if (opt == JOptionPane.NO_OPTION) {
				    		Index ID;
							ID = new Index();
							ID.setVisible(true);
							dispose();
						}
					} else {

						JOptionPane.showMessageDialog(null, "產生新約失敗 !", "新增失敗", JOptionPane.WARNING_MESSAGE);
						int result = JOptionPane.showConfirmDialog(null, "確定要結束程式嗎?", "確認訊息", JOptionPane.YES_NO_OPTION,
								JOptionPane.WARNING_MESSAGE);
						if (result == JOptionPane.YES_OPTION) {
				    		Index ID;
							ID = new Index();
							ID.setVisible(true);
							dispose();
						}
					}
				} catch (SQLException SQLe) {
					SQLe.printStackTrace();
				}
			}
		});
		buttonPanel.add(checkNewButton);

		// 返回鍵
		JButton backButton = new JButton("返回產生招標品項表(新約)");
		backButton.setFont(new Font("標楷體", Font.PLAIN, 15));
		backButton.setBounds(70, 10, 240, 33);
		backButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				frame.setVisible(true);
				dispose();
			}
		});
		buttonPanel.add(backButton);

	}

}
