﻿

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class previewRecord extends JFrame {
	private String[] str = { "決標分項", "決標健保碼", "決標健保價", "決標折讓X%", "決標折讓Y%", "決標折讓Y%備註", "決標淨額", "決標日期", "健保調價承諾",
			"廠商統一編號", "履約起日", "藥品唯一碼" };
	private JPanel contentPane;
	private JTable vTableMedicine;
	private DefaultTableModel model;
	private JTextField infield[] = new JTextField[40];
	private String innew;
	private String[] inNew = new String[40];

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					previewRecord frame = new previewRecord(null, null, null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public previewRecord(recordTenderResult mRT, final String[] newdata, final String[] detailData)
			throws ClassNotFoundException {
		final previewRecord clone = this;
		final recordTenderResult Hidding = mRT;
		setTitle("預覽紀錄招標結果");
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 900, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		String[] newmd = newdata;// TenderResult DATA
		String[] tenderD = detailData;// TenderDetial裡面的資料

		/*
		 * JLabel lblNewLabel = new JLabel("");//LOGO java.net.URL img =
		 * Index.class.getResource("image/MIM.png"); lblNewLabel.setIcon(new
		 * ImageIcon(img)); lblNewLabel.setBounds(520, 10, 167, 118);
		 * getContentPane().add(lblNewLabel);
		 */

		JPanel panel_1 = new JPanel();
		panel_1.setPreferredSize(new Dimension(0, 0));
		JScrollPane scrollPane = new JScrollPane(panel_1);
		contentPane.add(scrollPane, BorderLayout.CENTER);
		panel_1.setAutoscrolls(true);
		GridBagLayout gbl_panel_1 = new GridBagLayout();
		gbl_panel_1.columnWidths = new int[] { 0, 0 };
		gbl_panel_1.rowHeights = new int[] { 0, 0, 0 };
		gbl_panel_1.columnWeights = new double[] { 0.0, Double.MIN_VALUE };
		gbl_panel_1.rowWeights = new double[] { 0.0, 0.0, Double.MIN_VALUE };
		panel_1.setLayout(gbl_panel_1);

		scrollPane.setPreferredSize(new Dimension(0, 0));
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		contentPane.add(scrollPane, BorderLayout.CENTER);

		JPanel titlePanel = new JPanel();
		contentPane.add(titlePanel, BorderLayout.NORTH);
		
		JLabel lblNewLabel = new JLabel("預覽紀錄招標結果");
		lblNewLabel.setFont(new Font("標楷體", Font.PLAIN, 20));
		titlePanel.add(lblNewLabel);
		
		JLabel lblNewLabelLOGO = new JLabel("");// 醫院LOGO
		java.net.URL img = Index.class.getResource("image/MIM.png");
		lblNewLabelLOGO.setHorizontalAlignment(SwingConstants.RIGHT);
		titlePanel.add(lblNewLabelLOGO);
		lblNewLabelLOGO.setIcon(new ImageIcon(img));
		lblNewLabelLOGO.setBounds(900, 10, 160, 113);

		/*
		 * JLabel lblNewLabel = new JLabel("");//醫院LOGO java.net.URL img =
		 * Index.class.getResource("image/MIM.png"); lblNewLabel.setIcon(new
		 * ImageIcon(img)); lblNewLabel.setBounds(520, 10, 167, 118);
		 * titlePanel.add(lblNewLabel);
		 */

		int a = 0;// 放欄位名稱
		for (int i = 0; i < 3; i += 2) {
			for (int j = 0; j < 6; j++) {
				if (a == 12) {
					break;
				}
				JLabel field = new JLabel(str[a]);
				field.setFont(new Font("標楷體", Font.PLAIN, 15));
				GridBagConstraints strr = new GridBagConstraints();
				strr.gridx = i;
				strr.gridy = j;
				strr.gridwidth = 1;
				strr.gridheight = 1;
				strr.weightx = 0;
				strr.weighty = 1;
				strr.fill = GridBagConstraints.BOTH;
				strr.anchor = GridBagConstraints.NORTHWEST;
				panel_1.add(field, strr);

				a++;
			}
		}

		int b = 0;// 放textField
		for (int i = 1; i < 4; i += 2) {
			for (int j = 0; j < 6; j++) {
				if (b == 12) {
					break;
				}
				infield[b] = new JTextField(newmd[b]);
				infield[b].setFont(new Font("標楷體", Font.PLAIN, 15));
				infield[b].setEditable(false);
				GridBagConstraints strr = new GridBagConstraints();
				strr.gridx = i;
				strr.gridy = j;
				strr.gridwidth = 1;
				strr.gridheight = 1;
				strr.weightx = 5;
				strr.weighty = 5;
				strr.fill = GridBagConstraints.BOTH;
				strr.anchor = GridBagConstraints.NORTHWEST;
				panel_1.add(infield[b], strr);

				b++;
			}
		}

		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);

		JButton btnBKNew = new JButton("返回修改");
		btnBKNew.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(btnBKNew);
		btnBKNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				/*
				 * try { SearchMResult smr = new
				 * SearchMResult(clone,selectGroup,selectMedicament,
				 * selectCondition,cansearch); } catch (ClassNotFoundException
				 * e1) { // TODO Auto-generated catch block
				 * e1.printStackTrace(); }
				 */

				Hidding.setVisible(true);
				dispose();

			}
		});

		JButton btnCRNew = new JButton("確認修改");
		btnCRNew.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(btnCRNew);

		btnCRNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int c = 0;
				for (int i = 1; i < 4; i += 2) {
					for (int j = 0; j < 6; j++) {
						if (c == 12) {
							break;
						}

						GridBagConstraints strr = new GridBagConstraints();
						strr.gridx = i;
						strr.gridy = j;
						strr.gridwidth = 1;
						strr.gridheight = 1;
						strr.weightx = 5;
						strr.weighty = 5;
						System.out.println(c);
						innew = infield[c].getText();
						inNew[c] = innew;

						c++;
					}
				}

				Connection conn = null;
				Statement statement;
				ResultSet rs;
				ResultSetMetaData rsMetaData;
				String k = "";
				int empty = 0;
				int noDetect = 0;

				try {
					Class.forName("org.mariadb.jdbc.Driver");
					System.out.println("資料庫連結成功");
					conn = DriverManager.getConnection("jdbc:mariadb://lots.im.nuu.edu.tw/MIMSystem", "MIMSystem",
							"MIMSystem");
					System.out.println("連接成功MySQL");
					statement = conn.createStatement();

					// 檢查廠商統一編號
					// String sql1 = "SELECT `廠商統一編號` FROM `FirmData` WHERE
					// `廠商統一編號`='" + inNew[9] + "'";
					// String sql3 = "SELECT `藥品唯一碼` FROM `Medicine` WHERE
					// `藥品唯一碼` ='" + inNew[11] + "'";
					// System.out.println("泰國泰國" + sql1 + "test2222" + sql3);
					rs = statement.executeQuery("SELECT `廠商統一編號` FROM `FirmData` WHERE `廠商統一編號`='" + inNew[9] + "'");// '9
					// 11R

					// System.out.println("sql1 SELECT `廠商統一編號` FROM `FirmData`
					// WHERE `廠商統一編號`='" + inNew[9] + "'");

					if (!rs.next()) {
						JOptionPane.showMessageDialog(null, "查無此廠商統一編號 !", "請重新輸入", JOptionPane.INFORMATION_MESSAGE);
						noDetect++;
					}

					// 檢查藥品唯一馬
					rs = statement.executeQuery("SELECT `藥品唯一碼` FROM `Medicine` WHERE `藥品唯一碼` ='" + inNew[11] + "'");// '9
					// 11
					if (!rs.next()) {
						JOptionPane.showMessageDialog(null, "查無此藥品唯一碼 !", "請重新輸入", JOptionPane.INFORMATION_MESSAGE);
						noDetect++;
					}

					if ("".equals(inNew[0].toString().trim())) {// 判斷決標分項是否空白
						empty++;
						JOptionPane.showMessageDialog(null, "決標分項為必填欄位", "警告", JOptionPane.WARNING_MESSAGE);

					} else {
						if (inNew[0].toString() != null && !inNew[0].toString().equals("")) { // 判斷空白

							// 判斷string中空白
							int a;
							a = 0;
							char detect = ' ';
							a = inNew[0].indexOf(detect);
							if (a > 0) {
								JOptionPane.showMessageDialog(null, "決標分項不可有空白", "警告", JOptionPane.WARNING_MESSAGE);
								noDetect++;

							}
						}

					}

					// 判斷決標日
					if ("".equals(inNew[7].toString().trim())) {// 判斷決標分項是否空白
						empty++;
						JOptionPane.showMessageDialog(null, "決標日期為必填欄位", "警告", JOptionPane.WARNING_MESSAGE);

					} else {
						if (inNew[7].toString() != null && !inNew[7].toString().equals("")) { // 判斷空白

							// 判斷string中空白
							int a;
							a = 0;
							char detect = ' ';
							a = inNew[7].indexOf(detect);
							if (a > 0) {
								JOptionPane.showMessageDialog(null, "決標日期不可有空白", "警告", JOptionPane.WARNING_MESSAGE);
								noDetect++;

							}
						}

					}

					// 判斷履約起日
					if ("".equals(inNew[10].toString().trim())) {// 判斷決標分項是否空白
						empty++;
						JOptionPane.showMessageDialog(null, "履約起日為必填欄位", "警告", JOptionPane.WARNING_MESSAGE);

					} else {
						if (inNew[10].toString() != null && !inNew[10].toString().equals("")) { // 判斷空白

							// 判斷string中空白
							int a;
							a = 0;
							char detect = ' ';
							a = inNew[10].indexOf(detect);
							if (a > 0) {
								JOptionPane.showMessageDialog(null, "履約起日不可有空白", "警告", JOptionPane.WARNING_MESSAGE);
								noDetect++;

							}
						}

					}
					if (empty == 0 && noDetect == 0) {

						statement.executeUpdate(
								"INSERT INTO `TenderResult` (`流水號`, `案號項次`, `決標分項`, `決標健保碼`, `決標健保價`, `決標折讓X%`, `決標折讓Y%`, `決標折讓Y%備註`, `決標淨額`, `決標日期`, `健保調價承諾A%`, `廠商統一編號`, `履約起日`, `藥品唯一碼`) VALUES('"
										+ tenderD[0] + "','" + tenderD[1] + "','" + inNew[0] + "','" + inNew[1] + "','"
										+ inNew[2] + "','" + inNew[3] + "','" + inNew[4] + "','" + inNew[5] + "' ,'"
										+ inNew[6] + "','" + inNew[7] + "','" + inNew[8] + "','" + inNew[9] + "','"
										+ inNew[10] + "','" + inNew[11] + "')");

						statement.close();
						conn.close();

						int result = JOptionPane.showConfirmDialog(null, "紀錄成功！", "紀錄招標結果", JOptionPane.DEFAULT_OPTION,
								JOptionPane.PLAIN_MESSAGE);
						if (result == 0) {
				    		Index ID;
							ID = new Index();
							ID.setVisible(true);
							dispose();
						}
					}
				} catch (ClassNotFoundException classNotFound) {// 找不到JDBC
																// Driver
					classNotFound.printStackTrace();
				} catch (SQLException sqlException) {// 資料庫操作發生錯誤
					sqlException.printStackTrace();
				}

			}
		});
	}

}
