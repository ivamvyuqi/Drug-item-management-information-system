﻿

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

//import fianlFile.src.Index;

import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.FlowLayout;

public class recordTenderResult extends JFrame {
	private String[] str = { "決標分項", "決標健保碼", "決標健保價", "決標折讓X%", "決標折讓Y%", "決標折讓Y%備註", "決標淨額", "決標日期", "健保調價承諾",
			"廠商統一編號", "履約起日", "藥品唯一碼" };
	private JPanel contentPane;
	private JTable aTableMedicine;
	private DefaultTableModel model;
	private JTextField field[] = new JTextField[40];
	private String getnew;
	private String[] getNew = new String[40];

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					recordTenderResult frame = new recordTenderResult(null, 0, null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public recordTenderResult(final String[] data, final int EST, searchRecordItem sRT) {
		final recordTenderResult clone = this;
		final searchRecordItem Hidding = sRT;
		setTitle("紀錄招標結果");
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 900, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		String[] mdonly = data;

		/*JLabel lblNewLabel = new JLabel("");//LOGO
		java.net.URL img = Index.class.getResource("image/MIM.png");
		lblNewLabel.setIcon(new ImageIcon(img));		
		lblNewLabel.setBounds(520, 10, 167, 118);
		getContentPane().add(lblNewLabel);
		*/

		JPanel titlepanel = new JPanel();
		contentPane.add(titlepanel, BorderLayout.NORTH);
		titlepanel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JLabel label = new JLabel("\u7D00\u9304\u62DB\u6A19\u7D50\u679C");
		label.setFont(new Font("標楷體", Font.PLAIN, 20));
		titlepanel.add(label);

		
		JLabel lblNewLabel = new JLabel("");// 醫院LOGO
		java.net.URL img = Index.class.getResource("image/MIM.png");
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		titlepanel.add(lblNewLabel);
		lblNewLabel.setIcon(new ImageIcon(img));
		lblNewLabel.setBounds(900, 10, 160, 113);
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setPreferredSize(new Dimension(0, 0));
		JScrollPane scrollPane = new JScrollPane(panel_1);
		contentPane.add(scrollPane, BorderLayout.CENTER);
		panel_1.setAutoscrolls(true);
		GridBagLayout gbl_panel_1 = new GridBagLayout();
		gbl_panel_1.columnWidths = new int[] { 0, 0 };
		gbl_panel_1.rowHeights = new int[] { 0, 0, 0 };
		gbl_panel_1.columnWeights = new double[] { 0.0, Double.MIN_VALUE };
		gbl_panel_1.rowWeights = new double[] { 0.0, 0.0, Double.MIN_VALUE };
		panel_1.setLayout(gbl_panel_1);

		scrollPane.setPreferredSize(new Dimension(0, 0));
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		contentPane.add(scrollPane, BorderLayout.CENTER);

		int a = 0; // 第一欄跟第三欄位名稱
		for (int i = 0; i < 3; i += 2) {// 跑欄位名稱 跑兩欄
			for (int j = 0; j < 6; j++) {// 第一欄21個
				if (a == 12) {// 欄位數
					break;
				}
				JLabel field = new JLabel(str[a]);// 欄位名稱
				field.setFont(new Font("標楷體", Font.PLAIN, 15));
				GridBagConstraints strr = new GridBagConstraints();
				strr.gridx = i;
				strr.gridy = j;
				strr.gridwidth = 1;
				strr.gridheight = 1;
				strr.weightx = 0;
				strr.weighty = 1;
				strr.fill = GridBagConstraints.BOTH;
				strr.anchor = GridBagConstraints.NORTHWEST;
				panel_1.add(field, strr);
				System.out.println("str:" + str[a] + ";a:" + a);
				a++;
			}
		}

		int b = 0; // 第二欄跟第四欄是data資料
		for (int i = 1; i < 4; i += 2) {
			for (int j = 0; j < 6; j++) {
				if (b == 12) {
					break;
				}
				System.out.println(b);
				field[b] = new JTextField();

				field[b].setFont(new Font("標楷體", Font.PLAIN, 15));
				GridBagConstraints strr = new GridBagConstraints();
				strr.gridx = i;
				strr.gridy = j;
				strr.gridwidth = 1;
				strr.gridheight = 1;
				strr.weightx = 5;
				strr.weighty = 5;
				strr.fill = GridBagConstraints.BOTH;
				strr.anchor = GridBagConstraints.NORTHWEST;
				panel_1.add(field[b], strr);
				b++;

			}
		}

		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);

		JButton btnBKReSearch = new JButton("返回查詢結果");
		btnBKReSearch.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(btnBKReSearch);
		btnBKReSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Hidding.setVisible(true);
				dispose();
			}
		});
		
		JButton btnFace = new JButton("顯示預覽畫面");
		btnFace.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(btnFace);
		btnFace.addActionListener(new ActionListener() {// 顯示預覽畫面 把改完的資料放入新的陣列裡面
			public void actionPerformed(ActionEvent e) {
				int c = 0;
				for (int i = 1; i < 4; i += 2) {
					for (int j = 0; j < 6; j++) {
						if (c == 12) {
							break;
						}
						
						GridBagConstraints strr = new GridBagConstraints();
						strr.gridx = i;
						strr.gridy = j;
						strr.gridwidth = 1;
						strr.gridheight = 1;
						strr.weightx = 5;
						strr.weighty = 5;
						System.out.println(c);
						getnew = field[c].getText();
						getNew[c] = getnew;
						c++;
					}
				}

				//getNew[0] = mdonly[0];

				try {
					
					previewRecord nvm = new previewRecord(clone, getNew, mdonly);
					nvm.setVisible(true);
					dispose();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
	}	

}