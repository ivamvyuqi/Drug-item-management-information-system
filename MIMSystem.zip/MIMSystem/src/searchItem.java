﻿

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextField;

public class searchItem extends JFrame {
	private String[] tenResult = { "案號項次", "決標分項", "決標健保碼", "決標健保價", "決標折讓X%", "決標折讓Y%", "決標折讓Y%備註", "決標淨額", "決標日期",
			"健保調價承諾", "廠商統一編號", "藥品唯一碼" };// 少履約期限

	private JPanel contentPane;
	private JTextField textMedicine;
	static String selectItem;
	static String inputItem;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					searchItem frame = new searchItem(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public searchItem(Index index) throws ClassNotFoundException {
		setResizable(false);
		final searchItem clone = this;
		final Index Hidding = index;
		setTitle("查詢招標結果");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		/*JLabel lblNewLabel = new JLabel("");//LOGO
		java.net.URL img = Index.class.getResource("image/MIM.png");
		lblNewLabel.setIcon(new ImageIcon(img));		
		lblNewLabel.setBounds(520, 10, 167, 118);
		getContentPane().add(lblNewLabel);*/

		JPanel panel_1 = new JPanel();
		contentPane.add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(null);

		JComboBox cbMedicine = new JComboBox(tenResult);// 查詢下拉式選單
		cbMedicine.setFont(new Font("標楷體", Font.PLAIN, 15));
		cbMedicine.setBounds(156, 158, 271, 21);
		panel_1.add(cbMedicine);

		textMedicine = new JTextField();
		textMedicine.setBounds(437, 158, 289, 21);
		textMedicine.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel_1.add(textMedicine);
		textMedicine.setColumns(10);

		JLabel lblNewLabel = new JLabel("輸入查詢條件：");// 查詢條件
		lblNewLabel.setFont(new Font("標楷體", Font.PLAIN, 20));
		lblNewLabel.setBounds(156, 82, 140, 32);
		panel_1.add(lblNewLabel);

		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);

		JButton btnback = new JButton("回主畫面"); // 回主畫面的Button
		btnback.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(btnback);
		btnback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Hidding.setVisible(true);
    			dispose();
			}

		});

		JButton btnSearch = new JButton("查詢"); // 查詢Button
		btnSearch.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(btnSearch);
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selectItem = cbMedicine.getSelectedItem().toString();
				inputItem = textMedicine.getText().trim();

				try {
					searchResult nsrm = new searchResult(clone, selectItem, inputItem);
					nsrm.setVisible(true);
					dispose();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
	}
}
