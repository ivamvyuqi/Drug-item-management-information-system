﻿

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.EventListener;
import java.util.EventObject;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.CellEditorListener;
import javax.swing.event.EventListenerList;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import java.awt.Component;
import java.awt.Dimension;

public class searchResult extends JFrame implements ActionListener {
	private final boolean DEBUG = false;
	private JButton btnModifyRT[];
	private JPanel contentPane;
	private JPanel panel_1;
	private JTable tableMedicine;
	private DefaultTableModel model;
	private String sI;
	private String iI;
	private Object[][] data = new Object[1][];
	static int numberOfColumns = 0;
	private int numberOfRows = 0;
	private String[] tenderNum;
	static String[] columnNames = new String[1];
	int ae = 0; // 紀錄選取第幾筆
	String asTenderN;
	static modifyRT[] nam = new modifyRT[1];
	static int EST = 0;
	static int testn = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					searchResult frame = new searchResult(null, "", "");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public searchResult(searchItem searchI, String searchRI, String inputRI) throws ClassNotFoundException {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		final searchResult clone = this;
		final searchItem searchRecordT = searchI;

		setTitle("查詢招標結果");
		setBounds(100, 100, 900, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		sI = searchRI;
		iI = inputRI;

		JLabel pic1 = new JLabel("");
		pic1.setIcon(new ImageIcon("E:\\dl\\JAVA_workspace\\JAVA_workspace\\MIMSystem\\src\\MIM.png"));
		pic1.setHorizontalAlignment(SwingConstants.RIGHT);
		contentPane.add(pic1, BorderLayout.NORTH);

		panel_1 = new JPanel();
		panel_1.setLayout(new BorderLayout());
		getContentPane().add(panel_1);

		Connection conn = null;
		Statement statement;
		ResultSet rs;
		ResultSetMetaData rsMetaData;
		String k = "";
		int order = 0;

		try {
			Class.forName("org.mariadb.jdbc.Driver");
			System.out.println("資料庫連結成功");
			conn = DriverManager.getConnection("jdbc:mariadb://lots.im.nuu.edu.tw/MIMSystem", "MIMSystem", "MIMSystem");
			System.out.println("連接成功MySQL");
			statement = conn.createStatement();

			String sql = "SELECT `TenderResult`.`流水號`,`TenderResult`.`案號項次`,`TenderResult`.`決標分項`,`TenderResult`.`決標健保碼`,`TenderResult`.`決標健保價`,`TenderResult`.`決標折讓X%`,`TenderResult`.`決標折讓Y%`,`TenderResult`.`決標折讓Y%備註`,`TenderResult`.`決標淨額`,`TenderResult`.`決標日期`,`TenderResult`.`健保調價承諾A%`,`TenderResult`.`廠商統一編號`,`TenderResult`.`履約起日`,`TenderResult`.`藥品唯一碼`"
					+ " FROM `TenderResult`, `Tender`,`TenderDetail`" + "WHERE TenderResult.`" + searchRI + "` LIKE '%" + inputRI
					+ "%' AND TenderResult.`流水號` = Tender.`流水號` AND TenderResult.`案號項次` = TenderDetail.`案號項次` ";// 欄位資料
			System.out.print("取欄位名稱:" + sql);

			// DB取欄位名稱
			rs = statement.executeQuery(
					"SELECT `TenderResult`.`流水號`,`TenderResult`.`案號項次`,`TenderResult`.`決標分項`,`TenderResult`.`決標健保碼`,`TenderResult`.`決標健保價`,`TenderResult`.`決標折讓X%`,`TenderResult`.`決標折讓Y%`,`TenderResult`.`決標折讓Y%備註`,`TenderResult`.`決標淨額`,`TenderResult`.`決標日期`,`TenderResult`.`健保調價承諾A%`,`TenderResult`.`廠商統一編號`,`TenderResult`.`履約起日`,`TenderResult`.`藥品唯一碼`"
							+ " FROM `TenderResult`, `Tender`,`TenderDetail`" + "WHERE TenderResult.`" + searchRI + "` LIKE '%"
							+ inputRI
							+ "%' AND TenderResult.`流水號` = Tender.`流水號` AND TenderResult.`案號項次` = TenderDetail.`案號項次` ");// 欄位資料

			rsMetaData = rs.getMetaData();
			numberOfColumns = rsMetaData.getColumnCount();
			columnNames = new String[numberOfColumns + 1];

			for (int i = 1; i <= numberOfColumns; i++) {
				System.out.printf("%s\t", rsMetaData.getColumnName(i));
				columnNames[i - 1] = rsMetaData.getColumnName(i);
			}

			boolean nodata = true;
			while (rs.next()) {
				nodata = false;
				for (int i = 1; i <= numberOfColumns; i++) {
					System.out.printf("%s\t", rs.getObject(i));
				}
				numberOfRows++;
			}

			btnModifyRT = new JButton[numberOfRows];

			// DB取欄位資料
			data = new Object[numberOfRows][numberOfColumns + 1];

			String sql3 = "SELECT `TenderResult`.`流水號`,`TenderResult`.`案號項次`,`TenderResult`.`決標分項`,`TenderResult`.`決標健保碼`,`TenderResult`.`決標健保價`,`TenderResult`.`決標折讓X%`,`TenderResult`.`決標折讓Y%`,`TenderResult`.`決標折讓Y%備註`,`TenderResult`.`決標淨額`,`TenderResult`.`決標日期`,`TenderResult`.`健保調價承諾A%`,`TenderResult`.`廠商統一編號`,`TenderResult`.`履約起日`,`TenderResult`.`藥品唯一碼`"
					+ " FROM `TenderResult`, `Tender`,`TenderDetail`" + "WHERE TenderResult.`" + searchRI + "` LIKE '%" + inputRI
					+ "%' AND TenderResult.`流水號` = Tender.`流水號` AND TenderResult.`案號項次` = TenderDetail.`案號項次` ";// 欄位資料

			System.out.println("取資料:" + sql3);
			rs = statement.executeQuery(
					"SELECT `TenderResult`.`流水號`,`TenderResult`.`案號項次`,`TenderResult`.`決標分項`,`TenderResult`.`決標健保碼`,`TenderResult`.`決標健保價`,`TenderResult`.`決標折讓X%`,`TenderResult`.`決標折讓Y%`,`TenderResult`.`決標折讓Y%備註`,`TenderResult`.`決標淨額`,`TenderResult`.`決標日期`,`TenderResult`.`健保調價承諾A%`,`TenderResult`.`廠商統一編號`,`TenderResult`.`履約起日`,`TenderResult`.`藥品唯一碼`"
							+ " FROM `TenderResult`, `Tender`,`TenderDetail`" + "WHERE TenderResult.`" + searchRI + "` LIKE '%"
							+ inputRI
							+ "%' AND TenderResult.`流水號` = Tender.`流水號` AND TenderResult.`案號項次` = TenderDetail.`案號項次` ");// 欄位資料

			while (rs.next()) {
				for (int i = 1; i <= numberOfColumns; i++) {
					if (rs.getObject(i) == null) {
						data[order][i - 1] = "";
					} else {
						data[order][i - 1] = rs.getObject(i);
					}

				}
				order++;
			}
			System.out.println("筆數:" + order);

			// DB取流水號
			/*
			 * tenderNum = new String[order]; int x = 1; String sql2 =
			 * "SELECT TenderResult.`流水號` FROM `Tender`,`TenderDetail`,`TenderResult`"
			 * + "WHERE TenderResult.`" + searchRI + "` LIKE '%" + inputRI +
			 * "%' AND Tender.`流水號` = TenderDetail.`流水號` AND TenderDetail.`流水號` = TenderResult.`流水號` AND TenderDetail.`案號項次` = TenderResult.`案號項次`"
			 * ; System.out.println("取流水號:" + sql2); rs =
			 * statement.executeQuery(
			 * "SELECT TenderResult.`流水號` FROM `Tender`,`TenderDetail`,`TenderResult`"
			 * + "WHERE TenderResult.`" + searchRI + "` LIKE '%" + inputRI +
			 * "%' AND Tender.`流水號` = TenderDetail.`流水號` AND TenderDetail.`流水號` = TenderResult.`流水號` AND TenderDetail.`案號項次` = TenderResult.`案號項次`"
			 * );// 欄位資料
			 * 
			 * while (rs.next()) { if (rs.getObject(1) == null) tenderNum[x - 1]
			 * = ""; tenderNum[x - 1] = rs.getObject(1).toString();
			 * System.out.println("SQL流水號" + (x - 1) + ":" +
			 * rs.getObject(1).toString()); System.out.println("流水號" + (x - 1) +
			 * ":" + tenderNum[x - 1]); x++; }
			 */
			if (order == 0) {
				JOptionPane.showMessageDialog(null, "查無此招標結果 !請重新查詢!'", "查詢失敗", JOptionPane.WARNING_MESSAGE);
			}
			statement.close();
			conn.close();// 資料庫關閉

			// new jtest(numberOfRows,numberOfColumns);
		} catch (ClassNotFoundException classNotFound) {// 找不到JDBC Driver
			classNotFound.printStackTrace();
		} catch (SQLException sqlException) {// 資料庫操作發生錯誤
			sqlException.printStackTrace();
		}

		// Table(columnNames, data);

		MyTableModel myTableModel = new MyTableModel(columnNames, data);
		myTableModel.fireTableDataChanged();
		if (DEBUG) {
			for (int i = 0; i < numberOfRows; i++) {
				for (int j = 0; j < numberOfColumns; j++) {
					System.out.println(myTableModel.getValueAt(i, j) + "  ");
				}
			}
		}

		// 修改紐
		for (int i = 0; i < data.length; i++) {
			btnModifyRT[i] = new JButton("修改" + i);
			data[i][numberOfColumns] = btnModifyRT[i];
		}
		//// numberOfRows=0;
		System.out.println(data.length);
		tableMedicine = new JTable(myTableModel);
		tableMedicine.setRowSelectionAllowed(false);
		tableMedicine.getTableHeader().setReorderingAllowed(false);// 欄位拖動功能
		tableMedicine.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
		tableMedicine.setPreferredScrollableViewportSize(new Dimension(650, 70));

		// ScrollPane
		JScrollPane scrollPane = new JScrollPane(tableMedicine);
		tableMedicine.setDefaultRenderer(JButton.class, new JButtonRenderer());

		panel_1.add(scrollPane, BorderLayout.CENTER);
		final TableCellButton tableCellButton = new TableCellButton();
		tableMedicine.setDefaultEditor(JButton.class, tableCellButton);
		tableCellButton.addActionListener(this);

		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);

		// 重新查詢紐
		JButton btnReSearch = new JButton("重新查詢");
		btnReSearch.setFont(new Font("標楷體", Font.PLAIN, 15));
		panel.add(btnReSearch);
		btnReSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				searchRecordT.setVisible(true);
				dispose();

			}
		});
		
		JPanel panel_2 = new JPanel();
		contentPane.add(panel_2, BorderLayout.NORTH);
		
		JLabel label = new JLabel("查詢結果");
		label.setFont(new Font("標楷體", Font.PLAIN, 20));
		panel_2.add(label);
		
		/*JLabel lblNewLabel = new JLabel("");//LOGO
		java.net.URL img = Index.class.getResource("image/MIM.png");
		lblNewLabel.setIcon(new ImageIcon(img));		
		lblNewLabel.setBounds(520, 10, 167, 118);
		getContentPane().add(lblNewLabel);*/

		

	}

	public void actionPerformed(ActionEvent actEvent) {// 當我按下這一筆的button到下一頁之後,如果要跳回來才不會出錯,也就是把這頁隱藏
		System.out.println(actEvent);// print出來那筆
		ae = Integer.parseInt(actEvent.getActionCommand().substring(2));// 按鈕上的row數字
		//asTenderN = tenderNum[ae];
		System.out.println("第" + ae + "筆流水號");
		String[] d = new String[numberOfColumns];
		for (int i = 0; i < numberOfColumns; i++) {
			d[i] = data[ae][i].toString();// 那筆所有欄位資料
			System.out.println("我的DATA" + i + ":" + d[i]);
		}
		// testn++;
		switch ("SearchOrder") {// 解決按鈕切換的問題
		case "SearchOrder": {
			searchResult clone = this;
			if (nam[0] != null) {

				nam = new modifyRT[2];
				nam[1] = new modifyRT(d, EST, clone);
				nam[0].setVisible(false);
				nam[1].setVisible(true);
				dispose();
				break;
			}
			nam = new modifyRT[1];
			nam[0] = new modifyRT(d, EST, clone);
			nam[0].setVisible(true);
			dispose();
			break;
		}
		default:
			break;
		}
	}

	class MyTableModel extends AbstractTableModel {
		String[] columnNames;
		Object[][] data;

		public void removeTableModelListener(TableModelListener l) {
			l.tableChanged(null);
		}

		public MyTableModel(String[] columnNames, Object[][] data) {
			this.columnNames = columnNames;
			this.data = data;
		}

		public int getColumnCount() {
			return columnNames.length;
		}

		public int getRowCount() {
			return data.length;
		}

		public String getColumnName(int col) {
			return columnNames[col];
		}

		public Object getValueAt(int row, int col) {
			return data[row][col];
		}

		public Class getColumnClass(int c) {
			return getValueAt(0, c).getClass();
			// Object value=this.getValueAt(0,c);
			// return (value==null?Object.class:value.getClass());

		}

		@Override
		public boolean isCellEditable(int rowIndex, int columnIndex) {
			return getColumnClass(columnIndex) == JButton.class;
		}

	}
}

/*class TableCellButton extends JButton implements TableCellEditor {
	private EventListenerList cellEditorListeners = new EventListenerList();

	public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
		JButton button = (JButton) value;
		setText(button.getText());
		putClientProperty("row", new Integer(row));
		return this;
	}

	public void addCellEditorListener(CellEditorListener l) {
		cellEditorListeners.add(CellEditorListener.class, l);
	}

	protected void fireEditingCanceled() {
		EventListener[] listeners = cellEditorListeners.getListeners(CellEditorListener.class);
		for (int i = 0; i < listeners.length; ++i) {
			CellEditorListener l = (CellEditorListener) listeners[i];
			l.editingCanceled(changeEvent);
		}
	}

	protected void fireEditingStopped() {
		EventListener[] listeners = cellEditorListeners.getListeners(CellEditorListener.class);
		for (int i = 0; i < listeners.length; ++i) {
			CellEditorListener l = (CellEditorListener) listeners[i];
			l.editingStopped(changeEvent);
		}
	}

	public void cancelCellEditing() {
		fireEditingCanceled();
	}

	public Object getCellEditorValue() {
		return null;
	}

	public boolean isCellEditable(EventObject anEvent) {
		if (anEvent instanceof MouseEvent) {
			MouseEvent e = (MouseEvent) anEvent;
			if (e.getID() == MouseEvent.MOUSE_PRESSED) {
				MouseEvent newEvent = new MouseEvent(this, MouseEvent.MOUSE_PRESSED, e.getWhen(), e.getModifiers(), 0,
						0, e.getClickCount(), e.isPopupTrigger());
				Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(newEvent);
				return true;
			}
		}
		return false;
	}

	public void removeCellEditorListener(CellEditorListener l) {
		cellEditorListeners.remove(CellEditorListener.class, l);
	}

	public boolean shouldSelectCell(EventObject anEvent) {
		return false;
	}

	public boolean stopCellEditing() {
		fireEditingStopped();
		return true;
	}
}

class JButtonRenderer extends JButton implements TableCellRenderer {
	public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
			int row, int column) {
		JButton button = (JButton) value;
		setText(button.getText());
		return this;
	}
}
*/