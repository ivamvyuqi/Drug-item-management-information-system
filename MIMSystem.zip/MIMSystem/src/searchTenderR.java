﻿

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

//import fianlFile.src.Index;

import javax.swing.JLabel;
import javax.naming.directory.SearchResult;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextField;

public class searchTenderR extends JFrame {
	private JPanel contentPane;
	static String numItem;
	static String chineseItem;
	private JTextField textTenderNum;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					searchTenderR frame = new searchTenderR(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public searchTenderR(Index index) throws ClassNotFoundException {
		setResizable(false);
		final searchTenderR clone = this;
		final Index Hidding = index;
		setTitle("紀錄招標結果");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		/*JLabel lblNewLabel = new JLabel("");//LOGO
		java.net.URL img = Index.class.getResource("image/MIM.png");
		lblNewLabel.setIcon(new ImageIcon(img));		
		lblNewLabel.setBounds(520, 10, 167, 118);
		getContentPane().add(lblNewLabel);*/
		

		JPanel panel_1 = new JPanel();
		contentPane.add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(null);

		JLabel lblNewLabel = new JLabel("輸入查詢條件：");
		lblNewLabel.setFont(new Font("標楷體", Font.PLAIN, 20));
		lblNewLabel.setBounds(145, 81, 140, 32);
		panel_1.add(lblNewLabel);
		
		textTenderNum = new JTextField();
		textTenderNum.setFont(new Font("標楷體", Font.PLAIN, 15));
		textTenderNum.setBounds(290, 146, 289, 21);
		panel_1.add(textTenderNum);
		textTenderNum.setColumns(10);
		
		JLabel label_1 = new JLabel("\u6848\u865F\uFF1A");
		label_1.setFont(new Font("標楷體", Font.PLAIN, 15));
		label_1.setBounds(155, 147, 109, 18);
		panel_1.add(label_1);
		
		JLabel label_2 = new JLabel("\u7D00\u9304\u62DB\u6A19\u7D50\u679C");
		label_2.setFont(new Font("標楷體", Font.PLAIN, 20));
		label_2.setBounds(259, 23, 253, 32);
		panel_1.add(label_2);

		JPanel buttonpanel = new JPanel();
		contentPane.add(buttonpanel, BorderLayout.SOUTH);

		JButton button = new JButton("回主畫面");
		button.setFont(new Font("標楷體", Font.PLAIN, 15));
		buttonpanel.add(button);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Hidding.setVisible(true);
    			dispose();
			}

		});

		JButton btnSearch = new JButton("查詢");
		btnSearch.setFont(new Font("標楷體", Font.PLAIN, 15));
		buttonpanel.add(btnSearch);
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//chineseItem = textChinereTN.getText().trim();
				numItem = textTenderNum.getText().trim();

				try {
					searchRecordItem nsrm = new searchRecordItem(clone, numItem);
					nsrm.setVisible(true);
					dispose();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
	}
}
